<?php

use GlpiPlugin\Fssync\Install;

function plugin_fssync_install(): bool
{
    return Install::install(new Migration(PLUGIN_FSSYNC_VERSION));
}

function plugin_fssync_uninstall(): bool
{
    return Install::uninstall(new Migration(PLUGIN_FSSYNC_VERSION));
}
