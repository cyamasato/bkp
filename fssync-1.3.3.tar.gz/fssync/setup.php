<?php

/**
 * Freshservice Sync (fssync) — sincroniza computadores do GLPI com assets do Freshservice.
 */

use Glpi\Plugin\Hooks;
use GlpiPlugin\Fssync\ComputerTab;
use GlpiPlugin\Fssync\Config;
use GlpiPlugin\Fssync\ItemHooks;
use GlpiPlugin\Fssync\Menu;
use GlpiPlugin\Fssync\Profile;
use GlpiPlugin\Fssync\Rights;

define('PLUGIN_FSSYNC_VERSION', '1.3.3');
define('PLUGIN_FSSYNC_MIN_GLPI', '11.0.0');
define('PLUGIN_FSSYNC_MAX_GLPI', '11.0.99');

function plugin_init_fssync(): void
{
    /** @var array $PLUGIN_HOOKS */
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS[Hooks::CSRF_COMPLIANT]['fssync'] = true;
    // O GLPI criptografa com GLPIKey as chaves de configuração listadas aqui.
    $PLUGIN_HOOKS[Hooks::SECURED_CONFIGS]['fssync'] = Config::SECURED_KEYS;

    if (!Plugin::isPluginActive('fssync')) {
        return;
    }

    Plugin::registerClass(Profile::class, ['addtabon' => \Profile::class]);
    Plugin::registerClass(ComputerTab::class, ['addtabon' => Computer::class]);

    if (Rights::canView()) {
        $PLUGIN_HOOKS[Hooks::MENU_TOADD]['fssync'] = ['tools' => Menu::class];
    }
    if (Rights::canConfigure()) {
        // Engrenagem do plugin em Configurar > Plug-ins.
        $PLUGIN_HOOKS[Hooks::CONFIG_PAGE]['fssync'] = 'front/config.form.php';
    }

    // Os hooks só enfileiram o computador; o envio é feito pela ação automática.
    foreach ([Hooks::ITEM_ADD, Hooks::ITEM_UPDATE, Hooks::ITEM_RESTORE] as $hook) {
        $PLUGIN_HOOKS[$hook]['fssync'][Computer::class] = [ItemHooks::class, 'computerChanged'];
    }
    foreach ([Hooks::ITEM_DELETE, Hooks::ITEM_PURGE] as $hook) {
        $PLUGIN_HOOKS[$hook]['fssync'][Computer::class] = [ItemHooks::class, 'computerRemoved'];
    }
    $children = [Item_DeviceProcessor::class, Item_DeviceMemory::class, Item_DeviceHardDrive::class, Item_OperatingSystem::class];
    foreach ([Hooks::ITEM_ADD, Hooks::ITEM_UPDATE, Hooks::ITEM_DELETE, Hooks::ITEM_RESTORE, Hooks::ITEM_PURGE] as $hook) {
        foreach ($children as $child) {
            $PLUGIN_HOOKS[$hook]['fssync'][$child] = [ItemHooks::class, 'childChanged'];
        }
    }
}

function plugin_version_fssync(): array
{
    return [
        'name'         => 'Freshservice Sync',
        'version'      => PLUGIN_FSSYNC_VERSION,
        'author'       => 'Assistec',
        'license'      => 'GPL-3.0-or-later',
        'homepage'     => '',
        'requirements' => [
            'glpi' => [
                'min' => PLUGIN_FSSYNC_MIN_GLPI,
                'max' => PLUGIN_FSSYNC_MAX_GLPI,
            ],
        ],
    ];
}
