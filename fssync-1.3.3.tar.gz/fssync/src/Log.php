<?php

namespace GlpiPlugin\Fssync;

use CommonDBTM;
use DBmysql;
use Session;

/**
 * Histórico do que o plugin enviou ou tentou enviar ao Freshservice.
 */
class Log extends CommonDBTM
{
    public const SOURCE_CRON   = 'cron';
    public const SOURCE_MANUAL = 'manual';

    public const OP_CREATE  = 'create';
    public const OP_UPDATE  = 'update';
    public const OP_LINK    = 'link';
    public const OP_RETIRE  = 'retire';
    public const OP_DELETE  = 'delete';
    public const OP_SKIP    = 'skip';
    /** Modo "só atualizar": nenhum asset com o número de série do computador (D-39). */
    public const OP_NO_ASSET = 'no_asset';
    /** A fila foi esvaziada pela tela da Fila (D-42); grava com computers_id = 0. */
    public const OP_QUEUE_CLEARED = 'queue_clear';
    public const OP_DRY_RUN = 'dry_run';
    public const OP_BLOCKED = 'blocked';
    public const OP_ERROR   = 'error';

    /** O corpo guardado é cortado acima disto, para uma resposta enorme não inchar a tabela. */
    private const MAX_BODY_BYTES = 60000;

    public static $rightname = Rights::NAME;

    public static function getTypeName($nb = 0)
    {
        return _n('Sync log', 'Sync logs', $nb, 'fssync');
    }

    /**
     * @param ?array{method: string, url: string, request: ?array, status: int, response: mixed, duration_ms: int} $exchange
     *        a chamada HTTP relacionada (FreshserviceClient::lastExchange); nunca contém a API key
     */
    public static function write(
        string $operation,
        int $computerId,
        string $env,
        string $source,
        string $message,
        ?array $exchange = null,
        ?array $payload = null,
    ): void {
        /** @var DBmysql $DB */
        global $DB;

        $request = $exchange['request'] ?? $payload;

        $DB->insert(self::getTable(), [
            'date'         => $_SESSION['glpi_currenttime'] ?? date('Y-m-d H:i:s'),
            'computers_id' => $computerId,
            'fs_env'       => $env,
            'source'       => $source,
            'operation'    => $operation,
            'http_status'  => $exchange === null || $exchange['status'] === 0 ? null : $exchange['status'],
            'duration_ms'  => $exchange['duration_ms'] ?? null,
            'request'      => self::encode($exchange === null ? $request : ['method' => $exchange['method'], 'url' => $exchange['url'], 'body' => $request]),
            'response'     => self::encode($exchange['response'] ?? null),
            'message'      => $message,
            'users_id'     => $source === self::SOURCE_MANUAL ? (int) Session::getLoginUserID() : 0,
        ]);
    }

    /** Operação do registro mais recente do computador no ambiente, ou null se não houver. */
    public static function lastOperation(int $computerId, string $env): ?string
    {
        /** @var DBmysql $DB */
        global $DB;

        $row = $DB->request([
            'SELECT' => 'operation',
            'FROM'   => self::getTable(),
            'WHERE'  => ['computers_id' => $computerId, 'fs_env' => $env],
            'ORDER'  => 'id DESC',
            'LIMIT'  => 1,
        ])->current();

        return $row ? (string) $row['operation'] : null;
    }

    private static function encode(mixed $data): ?string
    {
        if ($data === null) {
            return null;
        }
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION | JSON_PARTIAL_OUTPUT_ON_ERROR);

        return mb_strcut((string) $json, 0, self::MAX_BODY_BYTES);
    }
}
