<?php

namespace GlpiPlugin\Fssync\Api;

/**
 * Envio de uma requisição HTTP. Existe para o FreshserviceClient ser testável
 * sem rede: em produção usa-se o GuzzleTransport.
 */
interface HttpTransport
{
    /**
     * @param array<string, string> $headers
     *
     * @throws TransportException quando não há resposta (rede, DNS, tempo esgotado)
     */
    public function send(string $method, string $url, array $headers, ?string $body): HttpResponse;
}
