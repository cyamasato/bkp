<?php

namespace GlpiPlugin\Fssync\Api;

use GlpiPlugin\Fssync\Mapping\Field;
use GlpiPlugin\Fssync\Mapping\Settings;
use Psr\SimpleCache\CacheInterface;

/**
 * Tipos de ativo, produtos e campos do Freshservice, com cache.
 *
 * As telas de configuração precisam dessas listas a cada exibição, e buscá-las
 * custa várias chamadas (as listagens são paginadas). O cache dura uma hora e
 * pode ser renovado pelo botão "Atualizar listas do Freshservice".
 */
final class Catalog
{
    private const TTL_SECONDS = 3600;

    private FieldCatalog $fields;

    public function __construct(
        private readonly FreshserviceClient $client,
        private readonly CacheInterface $cache,
        private readonly string $env,
    ) {
        $this->fields = new FieldCatalog($client);
    }

    /**
     * @throws \GlpiPlugin\Fssync\BlockedException quando o ambiente não tem domínio ou API key
     */
    public static function forEnv(string $env): self
    {
        /** @var CacheInterface $GLPI_CACHE */
        global $GLPI_CACHE;

        return new self(ClientFactory::forEnv($env), $GLPI_CACHE, $env);
    }

    /**
     * @return array<int, array{id: int, name: string, path: string, visible: bool}> por ID, em ordem de caminho
     */
    public function assetTypes(): array
    {
        return $this->remember('asset_types', function (): array {
            $raw = array_column($this->client->listAssetTypes(), null, 'id');

            $types = [];
            foreach ($raw as $id => $type) {
                $path   = [$type['name']];
                $parent = $type['parent_asset_type_id'] ?? null;
                // O limite evita laço infinito se a API devolver uma hierarquia circular.
                for ($depth = 0; $parent !== null && isset($raw[$parent]) && $depth < 10; $depth++) {
                    array_unshift($path, $raw[$parent]['name']);
                    $parent = $raw[$parent]['parent_asset_type_id'] ?? null;
                }
                $types[(int) $id] = [
                    'id'      => (int) $id,
                    'name'    => (string) $type['name'],
                    'path'    => implode(' > ', $path),
                    'visible' => (bool) ($type['visible'] ?? true),
                ];
            }
            uasort($types, static fn(array $a, array $b): int => strcasecmp($a['path'], $b['path']));

            return $types;
        });
    }

    /**
     * @return array<int, array{id: int, name: string, asset_type_id: int}> por ID, em ordem de nome
     */
    public function products(): array
    {
        return $this->remember('products', function (): array {
            $products = [];
            foreach ($this->client->listProducts() as $product) {
                $products[(int) $product['id']] = [
                    'id'            => (int) $product['id'],
                    'name'          => (string) $product['name'],
                    'asset_type_id' => (int) ($product['asset_type_id'] ?? 0),
                ];
            }
            uasort($products, static fn(array $a, array $b): int => strcasecmp($a['name'], $b['name']));

            return $products;
        });
    }

    /**
     * @return array<string, array{name: string, label: string, required: bool, choices: ?list<string>}> por nome
     */
    public function typeFields(int $assetTypeId): array
    {
        return $this->remember('fields_' . $assetTypeId, fn(): array => $this->fields->typeFields($assetTypeId));
    }

    /**
     * @return array<string, array{name: string, label: string, required: bool, choices: ?list<string>}> por campo lógico
     */
    public function suggestMapping(int $assetTypeId): array
    {
        return FieldCatalog::suggest($this->typeFields($assetTypeId));
    }

    /**
     * Campo de estado de um tipo de ativo: o do de-para de campos, se houver;
     * senão, o descoberto pela API (RF-14).
     *
     * @return ?array{name: string, choices: ?list<string>} null quando o tipo não tem o campo
     */
    public function stateField(int $assetTypeId, Settings $settings): ?array
    {
        $field = $settings->fields[$assetTypeId][Field::STATE] ?? $this->suggestMapping($assetTypeId)[Field::STATE] ?? null;

        return $field === null ? null : ['name' => $field['name'], 'choices' => $field['choices']];
    }

    /**
     * Opções da lista fechada de um campo lógico (estado, SO) no tipo de ativo dado.
     *
     * @return list<string> vazio quando o campo não existe ou não é lista fechada
     */
    public function choices(int $assetTypeId, string $logicalField): array
    {
        return $this->suggestMapping($assetTypeId)[$logicalField]['choices'] ?? [];
    }

    /** Descarta o que está em cache para o ambiente (não precisa de domínio nem de API key). */
    public static function clearEnv(string $env): void
    {
        /** @var CacheInterface $GLPI_CACHE */
        global $GLPI_CACHE;

        $prefix = 'fssync_catalog_' . $env . '_';
        $index  = $GLPI_CACHE->get($prefix . 'index', []);
        foreach (is_array($index) ? $index : [] as $name) {
            $GLPI_CACHE->delete($prefix . $name);
        }
        $GLPI_CACHE->delete($prefix . 'index');
    }

    /**
     * @template T
     *
     * @param callable(): T $load
     *
     * @return T
     */
    private function remember(string $name, callable $load): mixed
    {
        $cached = $this->cache->get($this->key($name));
        if (is_array($cached)) {
            return $cached;
        }

        $value = $load();
        $this->cache->set($this->key($name), $value, self::TTL_SECONDS);

        $index = $this->cache->get($this->key('index'), []);
        $index = is_array($index) ? $index : [];
        if (!in_array($name, $index, true)) {
            $index[] = $name;
            $this->cache->set($this->key('index'), $index, self::TTL_SECONDS * 24);
        }

        return $value;
    }

    private function key(string $name): string
    {
        return 'fssync_catalog_' . $this->env . '_' . $name;
    }

    /**
     * Campos lógicos que podem ser mapeados, na ordem da tela.
     *
     * @return list<string>
     */
    public static function logicalFields(): array
    {
        return array_keys(Field::USUAL_BASE_NAMES);
    }
}
