<?php

namespace GlpiPlugin\Fssync\Api;

/** HTTP 429: limite de requisições atingido. */
final class RateLimitException extends ApiException
{
    /** Espera usada quando a resposta não traz Retry-After. */
    public const DEFAULT_RETRY_AFTER = 60;

    public function __construct(string $message, public readonly int $retryAfter)
    {
        parent::__construct($message, 429);
    }
}
