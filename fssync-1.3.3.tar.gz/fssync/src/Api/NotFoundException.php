<?php

namespace GlpiPlugin\Fssync\Api;

/** HTTP 404: o recurso (normalmente o asset vinculado) não existe mais. */
final class NotFoundException extends ApiException {}
