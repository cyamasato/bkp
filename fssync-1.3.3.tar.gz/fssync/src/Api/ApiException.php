<?php

namespace GlpiPlugin\Fssync\Api;

use RuntimeException;
use Throwable;

/**
 * O Freshservice respondeu com erro (ou não respondeu). As subclasses dizem o
 * que fazer: bloquear, refazer o vínculo, esperar ou tentar de novo.
 */
class ApiException extends RuntimeException
{
    public function __construct(string $message, public readonly int $status = 0, ?Throwable $previous = null)
    {
        parent::__construct($message, $status, $previous);
    }
}
