<?php

namespace GlpiPlugin\Fssync\Api;

/** HTTP 401 ou 403: API key inválida ou sem permissão para o recurso. */
final class AuthException extends ApiException {}
