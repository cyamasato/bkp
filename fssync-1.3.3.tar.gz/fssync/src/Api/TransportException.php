<?php

namespace GlpiPlugin\Fssync\Api;

/** Não houve resposta: rede, DNS, proxy ou tempo esgotado. */
final class TransportException extends ApiException {}
