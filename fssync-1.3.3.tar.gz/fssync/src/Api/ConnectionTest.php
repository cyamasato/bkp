<?php

namespace GlpiPlugin\Fssync\Api;

/**
 * "Testar conexão": verifica, uma a uma, as permissões de que o plugin precisa.
 *
 * Chave inválida e falta de permissão devolvem o mesmo 403, por isso cada
 * recurso é consultado separadamente. Nenhum asset é criado nem alterado.
 */
final class ConnectionTest
{
    /**
     * @param bool $probeWrites verifica também criar e editar assets, com requisições
     *                          que a API recusa por validação (ver docs/decisoes.md, D-27)
     *
     * @return list<array{check: string, ok: bool, detail: string}>
     *         `check` é um identificador estável; o texto exibido vem de label()
     */
    public static function run(FreshserviceClient $client, bool $probeWrites = true): array
    {
        $results = [];
        $add     = static function (string $check, bool $ok, string $detail = '') use (&$results): void {
            $results[] = ['check' => $check, 'ok' => $ok, 'detail' => $detail];
        };

        try {
            $me = $client->me();
            $add('api_key', true, trim(($me['first_name'] ?? '') . ' ' . ($me['last_name'] ?? '')));
        } catch (TransportException $e) {
            // Sem rede não adianta testar o resto.
            $add('network', false, $e->getMessage());

            return $results;
        } catch (ApiException $e) {
            $add('api_key', false, $e->getMessage());

            return $results;
        }

        foreach (['asset_types', 'products', 'assets', 'requesters', 'agents'] as $resource) {
            try {
                $client->probeRead($resource);
                $add('read_' . $resource, true);
            } catch (ApiException $e) {
                $add('read_' . $resource, false, $e->getMessage());
            }
        }

        if ($probeWrites) {
            foreach (['create_assets' => $client->canCreateAssets(...), 'update_assets' => $client->canUpdateAssets(...)] as $check => $probe) {
                try {
                    $allowed = $probe();
                    $add($check, $allowed, $allowed ? '' : 'HTTP 403');
                } catch (ApiException $e) {
                    $add($check, false, $e->getMessage());
                }
            }
        }

        $remaining = $client->rateLimitRemaining();
        if ($remaining !== null) {
            $add('rate_limit', true, (string) $remaining);
        }

        return $results;
    }

    /** Texto de cada verificação, para a tela e para o console. */
    public static function label(string $check): string
    {
        return match ($check) {
            'network'          => __('Network access to Freshservice', 'fssync'),
            'api_key'          => __('API key accepted', 'fssync'),
            'read_asset_types' => __('Read asset types', 'fssync'),
            'read_products'    => __('Read products', 'fssync'),
            'read_assets'      => __('Read assets', 'fssync'),
            'read_requesters'  => __('Read requesters', 'fssync'),
            'read_agents'      => __('Read agents', 'fssync'),
            'create_assets'    => __('Create assets', 'fssync'),
            'update_assets'    => __('Edit assets', 'fssync'),
            'rate_limit'       => __('Requests left in this minute', 'fssync'),
            default            => $check,
        };
    }
}
