<?php

namespace GlpiPlugin\Fssync\Api;

use GlpiPlugin\Fssync\BlockedException;
use GlpiPlugin\Fssync\Config;

/**
 * Monta o cliente do Freshservice a partir da configuração do plugin.
 */
final class ClientFactory
{
    /**
     * @throws BlockedException quando o ambiente não tem domínio ou API key
     */
    public static function forEnv(string $env): FreshserviceClient
    {
        $domain = Config::domain($env);
        $apiKey = Config::apiKey($env);
        if ($domain === '' || $apiKey === '') {
            throw new BlockedException(sprintf(
                __('The "%s" environment has no Freshservice domain or API key configured.', 'fssync'),
                $env
            ));
        }

        return new FreshserviceClient($domain, $apiKey, new GuzzleTransport());
    }
}
