<?php

namespace GlpiPlugin\Fssync\Api;

/** HTTP 400: o Freshservice recusou os dados enviados. */
final class ValidationException extends ApiException
{
    /**
     * @param list<array{field: string, message: string, code: string}> $errors os erros por campo da resposta
     */
    public function __construct(string $message, int $status = 400, public readonly array $errors = [])
    {
        parent::__construct($message, $status);
    }

    /**
     * O Freshservice recusou o valor do campo por já existir em outro asset,
     * como o número de série de um asset que está na lixeira (D-47).
     */
    public function isNotUnique(string $field): bool
    {
        foreach ($this->errors as $error) {
            if ($error['field'] === $field && str_contains(strtolower($error['message']), 'unique')) {
                return true;
            }
        }

        return false;
    }
}
