<?php

namespace GlpiPlugin\Fssync\Api;

use JsonException;

/**
 * Cliente da API v2 do Freshservice. Só conhece HTTP e JSON: as regras de
 * sincronização ficam no SyncService.
 *
 * Contrato e comportamentos observados: docs/freshservice-api.md.
 */
final class FreshserviceClient
{
    private const PAGE_SIZE = 100;
    /** Trava de segurança ao seguir páginas (100 páginas de 100 itens). */
    private const MAX_PAGES = 100;
    /** Tamanho máximo de uma resposta guardada para log. */
    private const LOGGED_BODY_LIMIT = 20000;

    private string $baseUrl;

    /**
     * @var ?array{method: string, url: string, request: ?array, status: int, response: mixed, duration_ms: int}
     */
    private ?array $lastExchange = null;

    private ?int $rateLimitRemaining = null;

    public function __construct(string $domain, private readonly string $apiKey, private readonly HttpTransport $transport)
    {
        $this->baseUrl = self::normalizeBaseUrl($domain);
    }

    /**
     * Aceita "empresa.freshservice.com", "https://empresa.freshservice.com/" ou a
     * URL completa da API; devolve sempre a base ".../api/v2".
     */
    public static function normalizeBaseUrl(string $domain): string
    {
        $url = trim($domain);
        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }
        $url = preg_replace('#/api/v2/?$#i', '', rtrim($url, '/'));

        return rtrim($url, '/') . '/api/v2';
    }

    // ------------------------------------------------------------------ assets

    /**
     * @return list<array<string, mixed>> assets com esse número de série, com `type_fields`
     */
    public function findAssetsBySerial(string $serial): array
    {
        $filter = sprintf("\"serial_number:'%s'\"", str_replace(['\\', "'"], ['\\\\', "\\'"], $serial));

        return $this->request('GET', '/assets', ['filter' => $filter, 'include' => 'type_fields'])['assets'] ?? [];
    }

    /**
     * Assets da lixeira com esse número de série. A busca comum não os vê, mas
     * o Freshservice exige serial único também contra eles (D-47).
     *
     * @return list<array<string, mixed>>
     */
    public function findTrashedAssetsBySerial(string $serial): array
    {
        $filter = sprintf("\"serial_number:'%s'\"", str_replace(['\\', "'"], ['\\\\', "\\'"], $serial));
        try {
            return $this->request('GET', '/assets', ['filter' => $filter, 'trashed' => 'true', 'include' => 'type_fields'])['assets'] ?? [];
        } catch (ValidationException) {
            // Se a API não aceitar `filter` junto com `trashed`, percorre a lixeira inteira.
        }

        $wanted = strtolower(trim($serial));

        return array_values(array_filter(
            $this->listAll('/assets', 'assets', ['trashed' => 'true', 'include' => 'type_fields']),
            static function (array $asset) use ($wanted): bool {
                foreach ((array) ($asset['type_fields'] ?? []) as $name => $value) {
                    if (str_starts_with((string) $name, 'serial_number_') && strtolower(trim((string) $value)) === $wanted) {
                        return true;
                    }
                }

                return false;
            }
        ));
    }

    /** Tira o asset da lixeira. */
    public function restoreAsset(int $displayId): void
    {
        $this->request('PUT', "/assets/$displayId/restore");
    }

    /**
     * @return array<string, mixed>
     */
    public function getAsset(int $displayId): array
    {
        return $this->request('GET', "/assets/$displayId", ['include' => 'type_fields'])['asset'] ?? [];
    }

    /**
     * @param array<string, mixed> $body
     *
     * @return array<string, mixed> o asset criado
     */
    public function createAsset(array $body): array
    {
        return $this->request('POST', '/assets', [], $body)['asset'] ?? [];
    }

    /**
     * Atualização parcial: só os campos enviados mudam.
     *
     * @param array<string, mixed> $body
     *
     * @return array<string, mixed> o asset atualizado
     */
    public function updateAsset(int $displayId, array $body): array
    {
        return $this->request('PUT', "/assets/$displayId", [], $body)['asset'] ?? [];
    }

    public function deleteAsset(int $displayId): void
    {
        $this->request('DELETE', "/assets/$displayId");
    }

    // ----------------------------------------------------------------- pessoas

    /**
     * @return ?array<string, mixed>
     */
    public function findRequesterByEmail(string $email): ?array
    {
        return $this->request('GET', '/requesters', ['email' => $email])['requesters'][0] ?? null;
    }

    /**
     * @return ?array<string, mixed>
     *
     * @throws AuthException quando a API key não tem permissão de leitura de agentes
     */
    public function findAgentByEmail(string $email): ?array
    {
        return $this->request('GET', '/agents', ['email' => $email])['agents'][0] ?? null;
    }

    /**
     * @return array<string, mixed>
     *
     * @throws NotFoundException quando o ID não é de um solicitante
     */
    public function getRequester(int $id): array
    {
        return $this->request('GET', "/requesters/$id")['requester'] ?? [];
    }

    /**
     * @return array<string, mixed>
     *
     * @throws NotFoundException quando o ID não é de um agente
     * @throws AuthException     quando a API key não tem permissão de leitura de agentes
     */
    public function getAgent(int $id): array
    {
        return $this->request('GET', "/agents/$id")['agent'] ?? [];
    }

    /**
     * @return array<string, mixed> o agente dono da API key
     */
    public function me(): array
    {
        return $this->request('GET', '/agents/me')['agent'] ?? [];
    }

    // ---------------------------------------------------------------- catálogo

    /**
     * @return list<array<string, mixed>>
     */
    public function listAssetTypes(): array
    {
        return $this->listAll('/asset_types', 'asset_types');
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listProducts(): array
    {
        return $this->listAll('/products', 'products');
    }

    /**
     * @return list<array{field_header: string, fields: list<array<string, mixed>>}> grupos de campos do tipo
     */
    public function getAssetTypeFields(int $assetTypeId): array
    {
        return $this->request('GET', "/asset_types/$assetTypeId/fields")['asset_type_fields'] ?? [];
    }

    /**
     * @return array<string, mixed>
     *
     * @throws NotFoundException quando o tipo de ativo não existe
     */
    public function getAssetType(int $assetTypeId): array
    {
        return $this->request('GET', "/asset_types/$assetTypeId")['asset_type'] ?? [];
    }

    /**
     * @return array<string, mixed>
     *
     * @throws NotFoundException quando o produto não existe
     */
    public function getProduct(int $productId): array
    {
        return $this->request('GET', "/products/$productId")['product'] ?? [];
    }

    // ------------------------------------------------------------- permissões

    /**
     * Lê um único item de uma listagem, só para saber se a API key tem acesso.
     *
     * @param string $resource 'asset_types', 'products', 'requesters', 'agents' ou 'assets'
     *
     * @throws ApiException
     */
    public function probeRead(string $resource): void
    {
        $this->request('GET', '/' . $resource, ['per_page' => 1]);
    }

    /**
     * A API key pode criar assets? Envia um corpo vazio, que a API recusa na
     * validação (400) sem criar nada; sem permissão, a recusa vem antes (403).
     *
     * @throws ApiException para qualquer resposta diferente dessas duas
     */
    public function canCreateAssets(): bool
    {
        try {
            $this->request('POST', '/assets', [], []);
        } catch (ValidationException) {
            return true;
        } catch (AuthException) {
            return false;
        }

        // Um corpo vazio nunca deveria ser aceito.
        throw new ApiException('The API accepted an empty asset.', $this->lastExchange['status'] ?? 0);
    }

    /**
     * A API key pode editar assets? Tenta alterar o asset 0, que não existe:
     * com permissão a resposta é 404 (ou 400); sem permissão, 403.
     *
     * @throws ApiException para qualquer outra resposta
     */
    public function canUpdateAssets(): bool
    {
        try {
            $this->request('PUT', '/assets/0', [], []);
        } catch (NotFoundException | ValidationException) {
            return true;
        } catch (AuthException) {
            return false;
        }

        throw new ApiException('The API accepted an update to a non-existent asset.', $this->lastExchange['status'] ?? 0);
    }

    // -------------------------------------------------------------- diagnóstico

    /**
     * A última chamada feita, para o log. Nunca contém a API key.
     *
     * @return ?array{method: string, url: string, request: ?array, status: int, response: mixed, duration_ms: int}
     */
    public function lastExchange(): ?array
    {
        return $this->lastExchange;
    }

    /** Créditos restantes na janela de rate limit, segundo a última resposta. */
    public function rateLimitRemaining(): ?int
    {
        return $this->rateLimitRemaining;
    }

    // ----------------------------------------------------------------- interno

    /**
     * @param array<string, scalar> $query parâmetros além da paginação
     *
     * @return list<array<string, mixed>>
     */
    private function listAll(string $path, string $key, array $query = []): array
    {
        $items = [];
        for ($page = 1; $page <= self::MAX_PAGES; $page++) {
            $data  = $this->request('GET', $path, $query + ['per_page' => self::PAGE_SIZE, 'page' => $page], null, $response);
            $items = array_merge($items, $data[$key] ?? []);
            if (!str_contains((string) $response->header('Link'), 'rel="next"')) {
                break;
            }
        }

        return $items;
    }

    /**
     * @param array<string, scalar> $query
     * @param ?array<string, mixed> $body
     *
     * @return array<string, mixed> o JSON da resposta (vazio quando não há corpo)
     *
     * @throws ApiException
     */
    private function request(string $method, string $path, array $query = [], ?array $body = null, ?HttpResponse &$response = null): array
    {
        $url = $this->baseUrl . $path . ($query === [] ? '' : '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986));
        $headers = [
            'Authorization' => 'Basic ' . base64_encode($this->apiKey . ':X'),
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        ];
        // PRESERVE_ZERO_FRACTION: 16.0 vai como 16.0, não como o inteiro 16.
        // Um corpo vazio precisa ir como objeto ({}), não como lista ([]).
        $payload = $body === null
            ? null
            : json_encode($body === [] ? new \stdClass() : $body, JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR);

        $this->lastExchange = ['method' => $method, 'url' => $url, 'request' => $body, 'status' => 0, 'response' => null, 'duration_ms' => 0];
        $started = microtime(true);
        try {
            $response = $this->transport->send($method, $url, $headers, $payload);
        } catch (TransportException $e) {
            $this->lastExchange['duration_ms'] = (int) round((microtime(true) - $started) * 1000);
            $this->lastExchange['response']    = $e->getMessage();
            throw $e;
        }

        $decoded = self::decode($response->body);
        $this->lastExchange['duration_ms'] = (int) round((microtime(true) - $started) * 1000);
        $this->lastExchange['status']      = $response->status;
        $this->lastExchange['response']    = $decoded ?? mb_strcut($response->body, 0, self::LOGGED_BODY_LIMIT);

        $remaining = $response->header('X-RateLimit-Remaining');
        if ($remaining !== null && is_numeric($remaining)) {
            $this->rateLimitRemaining = (int) $remaining;
        }

        if ($response->status >= 200 && $response->status < 300) {
            return $decoded ?? [];
        }

        throw self::toException($response, $decoded);
    }

    /**
     * @return ?array<string, mixed>
     */
    private static function decode(string $body): ?array
    {
        if (trim($body) === '') {
            return null;
        }
        try {
            $decoded = json_decode($body, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            return null;
        }

        return is_array($decoded) ? $decoded : null;
    }

    /**
     * @param ?array<string, mixed> $decoded
     */
    private static function toException(HttpResponse $response, ?array $decoded): ApiException
    {
        $status  = $response->status;
        $message = "HTTP $status" . self::describe($decoded);

        return match (true) {
            $status === 400                   => new ValidationException($message, $status, self::fieldErrors($decoded)),
            $status === 401, $status === 403  => new AuthException($message, $status),
            $status === 404                   => new NotFoundException($message, $status),
            $status === 429                   => new RateLimitException($message, self::retryAfter($response)),
            default                           => new ApiException($message, $status),
        };
    }

    /**
     * @param ?array<string, mixed> $decoded
     */
    private static function describe(?array $decoded): string
    {
        if ($decoded === null) {
            return '';
        }
        $text = (string) ($decoded['description'] ?? $decoded['message'] ?? '');
        $details = [];
        foreach ($decoded['errors'] ?? [] as $error) {
            if (is_array($error)) {
                $details[] = trim(($error['field'] ?? '') . ': ' . ($error['message'] ?? ''), ': ');
            }
        }
        if ($details !== []) {
            $text .= ' (' . implode('; ', $details) . ')';
        }

        return $text === '' ? '' : ': ' . $text;
    }

    /**
     * @param ?array<string, mixed> $decoded
     *
     * @return list<array{field: string, message: string, code: string}>
     */
    private static function fieldErrors(?array $decoded): array
    {
        $errors = [];
        foreach ($decoded['errors'] ?? [] as $error) {
            if (is_array($error)) {
                $errors[] = [
                    'field'   => (string) ($error['field'] ?? ''),
                    'message' => (string) ($error['message'] ?? ''),
                    'code'    => (string) ($error['code'] ?? ''),
                ];
            }
        }

        return $errors;
    }

    private static function retryAfter(HttpResponse $response): int
    {
        $value = $response->header('Retry-After');

        return $value !== null && ctype_digit(trim($value)) ? max(1, (int) $value) : RateLimitException::DEFAULT_RETRY_AFTER;
    }
}
