<?php

namespace GlpiPlugin\Fssync\Api;

use GuzzleHttp\Exception\GuzzleException;
use Toolbox;

/**
 * Transporte de produção: o cliente HTTP do GLPI, que aplica o proxy
 * configurado em Configurar > Geral > Proxy.
 */
final class GuzzleTransport implements HttpTransport
{
    private const TIMEOUT_SECONDS = 30;

    public function send(string $method, string $url, array $headers, ?string $body): HttpResponse
    {
        $client = Toolbox::getGuzzleClient([
            'http_errors' => false,
            'timeout'     => self::TIMEOUT_SECONDS,
        ]);

        try {
            $response = $client->request($method, $url, ['headers' => $headers] + ($body === null ? [] : ['body' => $body]));
        } catch (GuzzleException $e) {
            // A mensagem do Guzzle traz a URL, nunca o cabeçalho Authorization.
            throw new TransportException($e->getMessage(), 0, $e);
        }

        $flat = [];
        foreach ($response->getHeaders() as $name => $values) {
            $flat[$name] = implode(', ', $values);
        }

        return new HttpResponse($response->getStatusCode(), $flat, (string) $response->getBody());
    }
}
