<?php

namespace GlpiPlugin\Fssync\Api;

use GlpiPlugin\Fssync\Mapping\Field;

/**
 * Descobre, pela API, os campos reais de um tipo de ativo. Os nomes levam o
 * sufixo _<id do tipo que define o campo>, por isso nunca são fixos no código.
 */
final class FieldCatalog
{
    public function __construct(private readonly FreshserviceClient $client) {}

    /**
     * Os `type_fields` do tipo, incluindo os herdados dos tipos ancestrais.
     *
     * @return array<string, array{name: string, label: string, required: bool, choices: ?list<string>}> por nome
     */
    public function typeFields(int $assetTypeId): array
    {
        $fields = [];
        foreach ($this->client->getAssetTypeFields($assetTypeId) as $group) {
            foreach ($group['fields'] ?? [] as $field) {
                // Campos comuns a todo asset (name, user_id...) não têm tipo dono e não vão em type_fields.
                if (empty($field['asset_type_id'])) {
                    continue;
                }
                $fields[$field['name']] = [
                    'name'     => (string) $field['name'],
                    'label'    => (string) ($field['label'] ?? $field['name']),
                    'required' => (bool) ($field['required'] ?? false),
                    'choices'  => self::choices($field['choices'] ?? null),
                ];
            }
        }

        return $fields;
    }

    /**
     * Sugestão de de-para: para cada campo lógico, o campo real cujo nome é o
     * nome-base usual seguido do sufixo numérico.
     *
     * @return array<string, array{name: string, label: string, required: bool, choices: ?list<string>}> por campo lógico
     */
    public function suggestMapping(int $assetTypeId): array
    {
        return self::suggest($this->typeFields($assetTypeId));
    }

    /**
     * @param array<string, array{name: string, label: string, required: bool, choices: ?list<string>}> $available por nome
     *
     * @return array<string, array{name: string, label: string, required: bool, choices: ?list<string>}> por campo lógico
     */
    public static function suggest(array $available): array
    {
        $suggested = [];
        foreach (Field::USUAL_BASE_NAMES as $logical => $base) {
            foreach ($available as $name => $field) {
                if (preg_match('/^' . preg_quote($base, '/') . '_\d+$/', $name)) {
                    $suggested[$logical] = $field;
                    break;
                }
            }
        }

        return $suggested;
    }

    /**
     * As opções de um dropdown vêm como [[rótulo, valor], ...]; o que se envia é o rótulo.
     * Listas aninhadas (campos dependentes) não são tratadas como lista fechada.
     *
     * @return ?list<string>
     */
    private static function choices(mixed $raw): ?array
    {
        if (!is_array($raw) || $raw === []) {
            return null;
        }
        $labels = [];
        foreach ($raw as $choice) {
            if (!is_array($choice) || count($choice) !== 2 || !is_scalar($choice[0])) {
                return null;
            }
            $labels[] = (string) $choice[0];
        }

        return $labels;
    }
}
