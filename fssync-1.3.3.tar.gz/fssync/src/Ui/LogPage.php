<?php

namespace GlpiPlugin\Fssync\Ui;

use DBmysql;
use GlpiPlugin\Fssync\Config;
use GlpiPlugin\Fssync\Log;

/**
 * Listagem pesquisável dos logs de sincronização.
 */
final class LogPage
{
    public const PAGE_SIZE = 50;

    public const OPERATIONS = [
        Log::OP_CREATE, Log::OP_UPDATE, Log::OP_LINK, Log::OP_RETIRE, Log::OP_DELETE,
        Log::OP_DRY_RUN, Log::OP_SKIP, Log::OP_NO_ASSET, Log::OP_BLOCKED, Log::OP_ERROR, Log::OP_QUEUE_CLEARED,
    ];

    /**
     * @param array<string, mixed> $query parâmetros da URL: q, operation, source, env, from, to, computers_id, start
     *
     * @return array<string, mixed> dados do template
     */
    public static function view(array $query): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $filters = [
            'q'            => trim((string) ($query['q'] ?? '')),
            'operation'    => in_array($query['operation'] ?? '', self::OPERATIONS, true) ? $query['operation'] : '',
            'source'       => in_array($query['source'] ?? '', [Log::SOURCE_CRON, Log::SOURCE_MANUAL], true) ? $query['source'] : '',
            'env'          => in_array($query['env'] ?? '', [Config::ENV_PROD, Config::ENV_TEST], true) ? $query['env'] : '',
            'from'         => self::date($query['from'] ?? ''),
            'to'           => self::date($query['to'] ?? ''),
            'computers_id' => max(0, (int) ($query['computers_id'] ?? 0)),
        ];
        $start = max(0, (int) ($query['start'] ?? 0));

        $where = [];
        foreach (['operation', 'source'] as $column) {
            if ($filters[$column] !== '') {
                $where['log.' . $column] = $filters[$column];
            }
        }
        if ($filters['env'] !== '') {
            $where['log.fs_env'] = $filters['env'];
        }
        if ($filters['computers_id'] > 0) {
            $where['log.computers_id'] = $filters['computers_id'];
        }
        if ($filters['from'] !== '') {
            $where[] = ['log.date' => ['>=', $filters['from'] . ' 00:00:00']];
        }
        if ($filters['to'] !== '') {
            $where[] = ['log.date' => ['<=', $filters['to'] . ' 23:59:59']];
        }
        if ($filters['q'] !== '') {
            $like    = ['LIKE', '%' . $filters['q'] . '%'];
            $where[] = ['OR' => ['log.message' => $like, 'computer.name' => $like, 'computer.serial' => $like]];
        }

        $base = [
            'FROM'      => Log::getTable() . ' AS log',
            'LEFT JOIN' => [
                'glpi_computers AS computer' => ['ON' => ['computer' => 'id', 'log' => 'computers_id']],
                'glpi_users AS actor'        => ['ON' => ['actor' => 'id', 'log' => 'users_id']],
            ],
            'WHERE'     => $where,
        ];

        $total = (int) $DB->request(['SELECT' => ['COUNT' => 'log.id AS total']] + $base)->current()['total'];
        $rows  = [];
        $found = $DB->request([
            'SELECT' => ['log.*', 'computer.name AS computer_name', 'actor.name AS actor_name'],
            'ORDER'  => 'log.id DESC',
            'START'  => $start,
            'LIMIT'  => self::PAGE_SIZE,
        ] + $base);
        foreach ($found as $row) {
            $row['request']  = self::pretty($row['request']);
            $row['response'] = self::pretty($row['response']);
            $rows[] = $row;
        }

        return [
            'filters'    => $filters,
            'operations' => self::OPERATIONS,
            'rows'       => $rows,
            'total'      => $total,
            'start'      => $start,
            'page_size'  => self::PAGE_SIZE,
            'query'      => http_build_query(array_filter($filters, static fn(mixed $v): bool => $v !== '' && $v !== 0)),
        ];
    }

    private static function date(mixed $value): string
    {
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $value) ? (string) $value : '';
    }

    /** JSON guardado em uma linha -> JSON indentado, para leitura. */
    private static function pretty(?string $json): ?string
    {
        if ($json === null || $json === '') {
            return null;
        }
        $decoded = json_decode($json, true);

        return $decoded === null
            ? $json
            : json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
    }
}
