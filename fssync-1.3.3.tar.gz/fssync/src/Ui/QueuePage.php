<?php

namespace GlpiPlugin\Fssync\Ui;

use DBmysql;
use GlpiPlugin\Fssync\Config;
use GlpiPlugin\Fssync\Log;
use GlpiPlugin\Fssync\Queue;

/**
 * Listagem pesquisável da fila, com as ações de reprocessar e de limpar.
 */
final class QueuePage
{
    public const PAGE_SIZE = 50;

    public const STATUSES = [Queue::STATUS_PENDING, Queue::STATUS_PROCESSING, Queue::STATUS_BLOCKED, Queue::STATUS_FAILED];

    /**
     * Reprocessa um item (ou todos os bloqueados e com falha) e volta para a lista.
     *
     * @param array<string, mixed> $post
     */
    public static function handle(array $post): never
    {
        if (($post['action'] ?? '') === 'clear') {
            // O direito (Configurar) é checado em front/queue.php.
            $count = Queue::clear();
            if ($count === 0) {
                Page::success(__('The queue is already empty.', 'fssync'));
            } else {
                $message = sprintf(_n('%d item removed from the queue.', '%d items removed from the queue.', $count, 'fssync'), $count);
                Log::write(Log::OP_QUEUE_CLEARED, 0, Config::activeEnv(), Log::SOURCE_MANUAL, $message);
                Page::success($message . ' ' . __('Computers return to the queue when they are changed or inventoried, while their entity is synchronized.', 'fssync'));
            }
        } elseif (($post['action'] ?? '') === 'reprocess_all') {
            Queue::reopen();
            Page::success(__('Blocked and failed items were returned to the queue.', 'fssync'));
        } elseif (($post['action'] ?? '') === 'reprocess' && (int) ($post['computers_id'] ?? 0) > 0) {
            Queue::reopen((int) $post['computers_id']);
            Page::success(__('Item returned to the queue.', 'fssync'));
        }

        Page::redirect('queue.php');
    }

    /**
     * @param array<string, mixed> $query parâmetros da URL: q, status, start
     *
     * @return array<string, mixed> dados do template
     */
    public static function view(array $query): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $filters = [
            'q'      => trim((string) ($query['q'] ?? '')),
            'status' => in_array($query['status'] ?? '', self::STATUSES, true) ? $query['status'] : '',
        ];
        $start = max(0, (int) ($query['start'] ?? 0));

        $where = [];
        if ($filters['status'] !== '') {
            $where['queue.status'] = $filters['status'];
        }
        if ($filters['q'] !== '') {
            $like    = ['LIKE', '%' . $filters['q'] . '%'];
            $where[] = ['OR' => ['queue.last_error' => $like, 'computer.name' => $like, 'computer.serial' => $like]];
        }

        $base = [
            'FROM'      => Queue::getTable() . ' AS queue',
            'LEFT JOIN' => ['glpi_computers AS computer' => ['ON' => ['computer' => 'id', 'queue' => 'computers_id']]],
            'WHERE'     => $where,
        ];

        $total = (int) $DB->request(['SELECT' => ['COUNT' => 'queue.id AS total']] + $base)->current()['total'];
        $rows  = [];
        $found = $DB->request([
            'SELECT' => ['queue.*', 'computer.name AS computer_name', 'computer.serial AS computer_serial'],
            'ORDER'  => ['queue.date_mod', 'queue.id'],
            'START'  => $start,
            'LIMIT'  => self::PAGE_SIZE,
        ] + $base);
        foreach ($found as $row) {
            $row['position'] = Queue::position($row);
            $rows[] = $row;
        }

        return [
            'filters'   => $filters,
            'statuses'  => self::STATUSES,
            'rows'      => $rows,
            'total'     => $total,
            'start'     => $start,
            'page_size' => self::PAGE_SIZE,
            'query'     => http_build_query(array_filter($filters)),
            'stuck'     => countElementsInTable(Queue::getTable(), ['status' => [Queue::STATUS_BLOCKED, Queue::STATUS_FAILED]]),
            // A fila inteira, sem o filtro da busca: é o que o "Limpar fila" remove.
            'queued'    => countElementsInTable(Queue::getTable()),
        ];
    }
}
