<?php

namespace GlpiPlugin\Fssync\Ui;

use Computer;
use DBmysql;
use GlpiPlugin\Fssync\Api\ApiException;
use GlpiPlugin\Fssync\BlockedException;
use GlpiPlugin\Fssync\Config;
use GlpiPlugin\Fssync\Log;
use GlpiPlugin\Fssync\Mapping;
use GlpiPlugin\Fssync\Mapping\ComputerSnapshot;
use GlpiPlugin\Fssync\Mapping\ComputerUser;
use GlpiPlugin\Fssync\Mapping\MappingCheck;
use GlpiPlugin\Fssync\Mapping\PayloadBuilder;
use GlpiPlugin\Fssync\Mapping\SnapshotForm;
use GlpiPlugin\Fssync\Mapping\SnapshotLoader;
use GlpiPlugin\Fssync\Mapping\UpdatePlan;
use GlpiPlugin\Fssync\Queue;
use GlpiPlugin\Fssync\Sync\SyncService;
use GlpiPlugin\Fssync\Sync\Tester;
use User;

/**
 * Página "Testar sincronização": pré-visualizar, validar e executar para um
 * computador real ou fictício.
 */
final class TestPage
{
    public const MODE_REAL       = 'real';
    public const MODE_FICTITIOUS = 'fictitious';

    public const STEP_PREVIEW  = 'preview';
    public const STEP_VALIDATE = 'validate';
    public const STEP_EXECUTE  = 'execute';
    public const STEP_DELETE   = 'delete';

    /**
     * @param array<string, mixed> $input o formulário enviado (vazio na primeira exibição)
     *
     * @return array<string, mixed> dados do template
     */
    public static function view(array $input): array
    {
        /** @var DBmysql $DB */
        global $DB;

        // O computador fictício existe para criar assets: no modo "só atualizar" não se aplica.
        $updateOnly = Config::isUpdateOnly();
        $mode       = !$updateOnly && ($input['mode'] ?? '') === self::MODE_FICTITIOUS ? self::MODE_FICTITIOUS : self::MODE_REAL;
        $step = in_array($input['step'] ?? '', [self::STEP_PREVIEW, self::STEP_VALIDATE, self::STEP_EXECUTE, self::STEP_DELETE], true) ? $input['step'] : null;

        $types = $states = [];
        foreach ($DB->request(['SELECT' => ['id', 'name'], 'FROM' => 'glpi_computertypes', 'ORDER' => 'name']) as $row) {
            $types[(int) $row['id']] = (string) $row['name'];
        }
        foreach ($DB->request(['SELECT' => ['id', 'completename'], 'FROM' => 'glpi_states', 'ORDER' => 'completename']) as $row) {
            $states[(int) $row['id']] = (string) $row['completename'];
        }

        $settings   = Mapping::settings();
        $fictitious = ((array) ($input['f'] ?? [])) + SnapshotForm::defaults();
        if (!isset($input['f']['type_id'])) {
            // O computador de referência é um notebook: prefere um tipo com esse nome que já
            // tenha de-para; senão, o primeiro tipo com de-para, para o exemplo funcionar de saída.
            $mapped   = array_intersect_key($types, $settings->types);
            $notebook = array_filter($mapped, static fn(string $name): bool => (bool) preg_match('/note|lap/i', $name));
            $fictitious['type_id'] = array_key_first($notebook) ?? array_key_first($mapped) ?? array_key_first($types) ?? 0;
        }

        $computersId = (int) ($input['computers_id'] ?? 0);
        $data = [
            'update_only'  => $updateOnly,
            'mode'         => $mode,
            'step'         => $step,
            'computers_id' => $computersId,
            'f'            => $fictitious,
            'types'        => $types,
            'states'       => $states,
            // Busca por nome ou número de série (computador) e por nome (usuário), com os dropdowns do GLPI.
            'computer_dropdown' => Computer::dropdown([
                'name'        => 'computers_id',
                'value'       => $computersId,
                'displaywith' => ['serial'],
                'display'     => false,
                'width'       => '100%',
            ]),
            'user_dropdown' => User::dropdown([
                'name'    => 'f[user_id]',
                'value'   => (int) $fictitious['user_id'],
                'right'   => 'all',
                'display' => false,
                'width'   => '100%',
            ]),
            'error'        => null,
            'preview'      => null,
            'validation'   => null,
            'execution'    => null,
        ];
        if ($step === null) {
            return $data;
        }

        $computer = $mode === self::MODE_REAL
            ? SnapshotLoader::load($data['computers_id'])
            : SnapshotForm::toSnapshot($fictitious);
        if ($computer === null) {
            $data['error'] = __('Choose a computer.', 'fssync');

            return $data;
        }

        $fields = Config::updateFields();
        $user   = SyncService::computerUser($computer, $settings);
        if ($updateOnly) {
            $data['preview'] = [
                'rows'      => UpdatePlan::preview($computer, $settings, $fields, self::describeUser($computer, $user), $user->origin()),
                'computer'  => $computer->name,
                'json'      => null,
                'error'     => $fields === [] ? __('No field is selected for update. Choose them in Configuration > Synchronization.', 'fssync') : null,
                'defaulted' => null,
            ];
        } else {
            // Sem consultar a API: o padrão só entra aqui para tipo sem de-para (D-43).
            $resolved        = MappingCheck::resolve($settings, $computer->typeId, null, null);
            $explained       = PayloadBuilder::explain($computer, $resolved['settings']);
            $data['preview'] = $explained + [
                'user'        => self::describeUser($computer, $user),
                'user_origin' => $user->origin(),
                'computer'    => $computer->name,
                'json'        => $explained['payload'] === null ? null : self::json($explained['payload']),
                'defaulted'   => $resolved['defaulted'],
            ];
        }

        try {
            if ($step === self::STEP_VALIDATE) {
                $tester     = Tester::fromConfig();
                $validation = $updateOnly ? $tester->validateUpdate($computer, $fields) : $tester->validate($computer);
                $data['validation'] = $validation + [
                    'json'      => $validation['body'] === null ? null : self::json($validation['body']),
                    'asset_url' => $validation['display_id'] === null ? '' : Config::assetUrl(Config::activeEnv(), $validation['display_id']),
                ];
            } elseif ($step === self::STEP_EXECUTE) {
                $data['execution'] = self::execute($mode, $computer);
            } elseif ($step === self::STEP_DELETE) {
                $data['execution'] = self::delete($mode, $computer);
            }
        } catch (BlockedException $e) {
            $data['error'] = $e->getMessage();
        }

        return $data;
    }

    /**
     * @return array<string, mixed>
     *
     * @throws BlockedException
     */
    private static function execute(string $mode, ComputerSnapshot $computer): array
    {
        if (Config::isDryRun()) {
            throw new BlockedException(__('Dry-run is on. Turn it off in the configuration to send from this page.', 'fssync'));
        }

        $service = $mode === self::MODE_REAL ? SyncService::fromConfig(Log::SOURCE_MANUAL) : Tester::fromConfig();
        try {
            if ($service instanceof SyncService) {
                $result = $service->sync($computer->id, force: true);
                // O que a fila ia fazer acabou de ser feito.
                Queue::forget($computer->id);
                $outcome = ['operation' => $result->operation, 'display_id' => $result->displayId, 'message' => $result->message];
            } else {
                $outcome = $service->executeFictitious($computer);
            }
        } catch (ApiException $e) {
            return self::outcome(false, $e->getMessage(), null, $service);
        }

        return self::outcome(true, $outcome['message'], $outcome['display_id'], $service);
    }

    /**
     * @return array<string, mixed>
     *
     * @throws BlockedException
     */
    private static function delete(string $mode, ComputerSnapshot $computer): array
    {
        if ($mode !== self::MODE_FICTITIOUS) {
            throw new BlockedException(__('Only assets created from a fictitious computer can be deleted here.', 'fssync'));
        }

        $tester = Tester::fromConfig();
        try {
            $deleted = $tester->deleteTestAsset($computer->serial);
        } catch (ApiException $e) {
            return self::outcome(false, $e->getMessage(), null, $tester);
        }

        return self::outcome(true, $deleted['message'], null, $tester);
    }

    /**
     * @return array<string, mixed>
     */
    private static function outcome(bool $ok, string $message, ?int $displayId, SyncService|Tester $service): array
    {
        $exchange = $service->lastExchange();

        return [
            'ok'             => $ok,
            'message'        => $message,
            'display_id'     => $displayId,
            'asset_url'      => $displayId === null ? '' : Config::assetUrl(Config::activeEnv(), $displayId),
            'http_status'    => $exchange['status'] ?? null,
            'duration_ms'    => $exchange['duration_ms'] ?? null,
            'request'        => $exchange === null ? null : $exchange['method'] . ' ' . $exchange['url'],
            'response'       => $exchange === null ? null : self::json($exchange['response']),
            'rate_remaining' => $service->rateLimitRemaining(),
        ];
    }

    private static function json(mixed $data): string
    {
        return (string) json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
    }

    /**
     * De onde veio o usuário e o e-mail procurado, para a linha "Usado por" da
     * pré-visualização: o nome alternativo ou o nome do usuário do GLPI.
     */
    private static function describeUser(ComputerSnapshot $computer, ComputerUser $user): string
    {
        if ($user->isNone()) {
            return '';
        }
        $from = $user->label;
        if ($user->source === ComputerUser::SOURCE_USER) {
            $glpiUser = new User();
            $from     = $glpiUser->getFromDB($computer->userId) ? $glpiUser->getFriendlyName() : $user->label;
        }

        return $user->email === '' ? sprintf('%s (%s)', $from, $user->problem) : sprintf('%s <%s>', $from, $user->email);
    }
}
