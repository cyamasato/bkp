<?php

namespace GlpiPlugin\Fssync\Ui;

use Glpi\Application\View\TemplateRenderer;
use GlpiPlugin\Fssync\Config;
use GlpiPlugin\Fssync\Menu;
use GlpiPlugin\Fssync\Rights;
use Html;
use Session;

/**
 * O que todas as páginas do plugin têm em comum: cabeçalho do GLPI, barra de
 * navegação do plugin e mensagens.
 */
final class Page
{
    public const STATUS = 'status';
    public const QUEUE  = 'queue';
    public const LOGS   = 'logs';
    public const TEST   = 'test';
    public const CONFIG = 'config';

    /**
     * @param array<string, mixed> $params
     */
    public static function render(string $active, string $template, array $params = []): void
    {
        Html::header(Menu::getMenuName(), '', 'tools', Menu::class);

        TemplateRenderer::getInstance()->display('@fssync/' . $template, $params + [
            'active'        => $active,
            'base'          => self::baseUrl(),
            'can_test'      => Rights::canTest(),
            'can_configure' => Rights::canConfigure(),
            'dry_run'       => Config::isDryRun(),
            'env'           => Config::activeEnv(),
        ]);

        Html::footer();
    }

    /** Caminho das páginas do plugin, já com a pasta do GLPI quando ele não está na raiz do site. */
    public static function baseUrl(): string
    {
        /** @var array<string, mixed> $CFG_GLPI */
        global $CFG_GLPI;

        return ($CFG_GLPI['root_doc'] ?? '') . '/plugins/fssync/front';
    }

    public static function success(string $message): void
    {
        Session::addMessageAfterRedirect(htmlescape($message), false, INFO);
    }

    public static function error(string $message): void
    {
        Session::addMessageAfterRedirect(htmlescape($message), false, ERROR);
    }

    /** Volta para a página anterior (padrão POST -> redirecionamento -> GET). */
    public static function redirect(string $page): never
    {
        Html::redirect(self::baseUrl() . '/' . $page);
    }
}
