<?php

namespace GlpiPlugin\Fssync\Ui;

use DBmysql;
use GlpiPlugin\Fssync\Api\ApiException;
use GlpiPlugin\Fssync\Api\Catalog;
use GlpiPlugin\Fssync\Api\ClientFactory;
use GlpiPlugin\Fssync\Api\ConnectionTest;
use GlpiPlugin\Fssync\BlockedException;
use GlpiPlugin\Fssync\Config;
use GlpiPlugin\Fssync\Mapping;
use GlpiPlugin\Fssync\Mapping\ComputerUser;
use GlpiPlugin\Fssync\Mapping\DescriptionTemplate;
use GlpiPlugin\Fssync\Mapping\Field;
use GlpiPlugin\Fssync\Mapping\MappingCheck;
use GlpiPlugin\Fssync\Mapping\Settings;
use GlpiPlugin\Fssync\Mapping\UpdatePlan;
use GlpiPlugin\Fssync\Queue;

/**
 * Tela de configuração: uma aba por assunto, cada uma com o seu formulário.
 */
final class ConfigPage
{
    public const TABS = ['connection', 'sync', 'users', 'types', 'states', 'models', 'os'];

    /** Abas que só fazem sentido no modo completo (o "só atualizar" não monta o asset inteiro). */
    private const FULL_MODE_TABS = ['types', 'models', 'os'];

    private const ENVS = [Config::ENV_PROD, Config::ENV_TEST];

    private const SESSION_CONNECTION_TEST = 'plugin_fssync_connection_test';

    // ------------------------------------------------------------------ ações

    /**
     * Executa a ação do formulário enviado e volta para a aba de origem.
     *
     * @param array<string, mixed> $post
     */
    public static function handle(array $post): never
    {
        $action = (string) ($post['action'] ?? '');
        $tab    = in_array($post['tab'] ?? '', self::TABS, true) ? $post['tab'] : self::TABS[0];

        try {
            match ($action) {
                'save_connection' => self::saveConnection($post),
                'test_connection' => self::testConnection($post),
                'refresh_catalog' => self::refreshCatalog(),
                'save_sync'       => self::saveSync($post),
                'initial_load'    => self::initialLoad(),
                'save_users'      => self::saveUsers($post),
                'save_types'      => self::saveTypes($post),
                'save_fields'     => self::saveFields($post),
                'save_states'     => self::saveStates($post),
                'save_models'     => self::saveModels($post),
                'save_os'         => self::saveOs($post),
                default           => Page::error(__('Unknown action.', 'fssync')),
            };
        } catch (BlockedException | ApiException $e) {
            Page::error($e->getMessage());
        }

        Page::redirect('config.form.php?tab=' . $tab);
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function saveConnection(array $post): void
    {
        $values = [
            'active_env'   => ($post['active_env'] ?? '') === Config::ENV_PROD ? Config::ENV_PROD : Config::ENV_TEST,
            'workspace_id' => preg_replace('/\D/', '', (string) ($post['workspace_id'] ?? '')),
        ];
        foreach (self::ENVS as $env) {
            $values[$env . '_domain'] = trim((string) ($post[$env . '_domain'] ?? ''));
            // Campo em branco mantém a chave atual: o formulário nunca devolve a chave salva.
            if (trim((string) ($post[$env . '_api_key'] ?? '')) !== '') {
                $values[$env . '_api_key'] = trim((string) $post[$env . '_api_key']);
            } elseif (!empty($post[$env . '_api_key_clear'])) {
                $values[$env . '_api_key'] = '';
            }
            Catalog::clearEnv($env);
        }
        Config::set($values);
        Queue::reopen();
        Page::success(__('Connection settings saved.', 'fssync'));
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function testConnection(array $post): void
    {
        $env = ($post['env'] ?? '') === Config::ENV_PROD ? Config::ENV_PROD : Config::ENV_TEST;

        $_SESSION[self::SESSION_CONNECTION_TEST] = [
            'env'     => $env,
            'results' => ConnectionTest::run(ClientFactory::forEnv($env)),
        ];
    }

    private static function refreshCatalog(): void
    {
        foreach (self::ENVS as $env) {
            Catalog::clearEnv($env);
        }
        Page::success(__('Freshservice lists will be fetched again.', 'fssync'));
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function saveSync(array $post): void
    {
        $entities = array_values(array_unique(array_map(intval(...), (array) ($post['entities'] ?? []))));
        $fields   = array_values(array_intersect(UpdatePlan::FIELDS, (array) ($post['update_fields'] ?? [])));

        $values = [
            'dry_run'               => empty($post['dry_run']) ? 0 : 1,
            'sync_mode'             => ($post['sync_mode'] ?? '') === Config::MODE_FULL ? Config::MODE_FULL : Config::MODE_UPDATE,
            'update_fields'         => json_encode($fields),
            'entities'              => json_encode($entities),
            'user_not_found_policy' => in_array($post['user_not_found_policy'] ?? '', [Config::USER_POLICY_BLOCK, Config::USER_POLICY_DEFAULT], true)
                ? $post['user_not_found_policy']
                : Config::USER_POLICY_SKIP,
            'default_fs_user_id'    => preg_replace('/\D/', '', (string) ($post['default_fs_user_id'] ?? '')),
            'batch_size'            => max(1, min(500, (int) ($post['batch_size'] ?? 20))),
            'max_attempts'          => max(1, min(50, (int) ($post['max_attempts'] ?? 8))),
        ];
        // As opções do modo completo só vêm no formulário quando a tela estava nesse modo;
        // sem elas, o que está salvo fica como está.
        if (!empty($post['full_options'])) {
            $values += [
                'delete_policy'         => ($post['delete_policy'] ?? '') === Config::DELETE_POLICY_DELETE ? Config::DELETE_POLICY_DELETE : Config::DELETE_POLICY_STATE,
                'retired_state'         => trim((string) ($post['retired_state'] ?? '')) ?: Config::DEFAULTS['retired_state'],
                'description_template'  => trim((string) ($post['description_template'] ?? '')),
                'disk_round_commercial' => empty($post['disk_round_commercial']) ? 0 : 1,
                'cpu_unit'              => ($post['cpu_unit'] ?? '') === Settings::CPU_GHZ ? Settings::CPU_GHZ : Settings::CPU_MHZ,
            ];
        }
        Config::set($values);
        Queue::reopen();
        Page::success(__('Synchronization settings saved.', 'fssync'));
    }

    private static function initialLoad(): void
    {
        $count = Queue::enqueueAll(Config::entities());
        if ($count === 0) {
            Page::error(__('No computer was queued: select the synchronized entities first.', 'fssync'));

            return;
        }
        Page::success(sprintf(__('%d computers queued. They are sent in batches by the automatic action.', 'fssync'), $count));
    }

    /**
     * De-para de domínio do nome alternativo do usuário (D-45).
     *
     * @param array<string, mixed> $post
     */
    private static function saveUsers(array $post): void
    {
        $rows = [];
        foreach ((array) ($post['domains'] ?? []) as $row) {
            $domain = strtoupper(trim((string) ($row['name'] ?? '')));
            $value  = strtolower(ltrim(trim((string) ($row['value'] ?? '')), '@'));
            if ($domain !== '' && $value !== '') {
                $rows[$domain] = [$domain, $value];
            }
        }
        Mapping::replaceKind(Mapping::KIND_USER_DOMAIN, array_values($rows));
        Queue::reopen();
        Page::success(__('User domain mapping saved.', 'fssync'));
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function saveTypes(array $post): void
    {
        $rows = [];
        foreach ((array) ($post['types'] ?? []) as $glpiTypeId => $choice) {
            $assetTypeId = (int) ($choice['asset_type_id'] ?? 0);
            if ($assetTypeId > 0) {
                $rows[] = [(string) (int) $glpiTypeId, (string) $assetTypeId, ['product_id' => (int) ($choice['product_id'] ?? 0)]];
            }
        }
        Mapping::replaceKind(Mapping::KIND_TYPE, $rows);

        // Padrão para tipo sem de-para ou com de-para inexistente (D-43): tipo e produto vão juntos.
        $defaultType    = (int) ($post['default']['asset_type_id'] ?? 0);
        $defaultProduct = $defaultType > 0 ? (int) ($post['default']['product_id'] ?? 0) : 0;
        if ($defaultType > 0 && $defaultProduct <= 0) {
            Page::error(__('The default asset type needs a product; the default was not saved.', 'fssync'));
            $defaultType = 0;
        }
        Config::set(['default_asset_type_id' => $defaultType ?: '', 'default_product_id' => $defaultProduct ?: '']);

        // Campos de tipos de ativo que saíram do de-para não servem mais (por exemplo, os do mock).
        $used   = array_map(intval(...), array_unique(array_merge(array_column($rows, 1), $defaultType > 0 ? [$defaultType] : [])));
        $mapped = array_keys(Mapping::settings()->fields);
        foreach (array_diff($mapped, $used) as $assetTypeId) {
            Mapping::replaceKind(Mapping::KIND_FIELD, [], $assetTypeId . ':');
        }

        // Tipo de ativo novo na lista: grava logo a sugestão de campos, que a tela permite ajustar.
        // Um ID que não existe no Freshservice ativo não tem campos a sugerir; a tela o aponta.
        $catalog  = Catalog::forEnv(Config::activeEnv());
        $existing = $catalog->assetTypes();
        foreach ($used as $assetTypeId) {
            if (!in_array($assetTypeId, $mapped, true) && isset($existing[$assetTypeId])) {
                $suggestion = array_map(static fn(array $field): string => $field['name'], $catalog->suggestMapping((int) $assetTypeId));
                self::storeFields((int) $assetTypeId, $suggestion, $catalog);
            }
        }
        Queue::reopen();
        Page::success(__('Computer type mapping saved.', 'fssync'));
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function saveFields(array $post): void
    {
        $catalog = Catalog::forEnv(Config::activeEnv());
        foreach ((array) ($post['fields'] ?? []) as $assetTypeId => $byLogical) {
            self::storeFields((int) $assetTypeId, (array) $byLogical, $catalog);
        }
        Queue::reopen();
        Page::success(__('Field mapping saved.', 'fssync'));
    }

    /**
     * @param array<string, string> $byLogical nome real do campo, por campo lógico; nomes que não existem no tipo são ignorados
     */
    private static function storeFields(int $assetTypeId, array $byLogical, Catalog $catalog): void
    {
        $available = $catalog->typeFields($assetTypeId);

        $rows = [];
        foreach ($byLogical as $logical => $name) {
            if (isset(Field::USUAL_BASE_NAMES[$logical], $available[$name])) {
                $rows[] = [Mapping::fieldKey($assetTypeId, (string) $logical), (string) $name, ['choices' => $available[$name]['choices']]];
            }
        }
        Mapping::replaceKind(Mapping::KIND_FIELD, $rows, $assetTypeId . ':');
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function saveStates(array $post): void
    {
        $rows = [];
        foreach ((array) ($post['states'] ?? []) as $stateId => $label) {
            if (trim((string) $label) !== '') {
                $rows[] = [(string) (int) $stateId, trim((string) $label)];
            }
        }
        Mapping::replaceKind(Mapping::KIND_STATE, $rows);
        Queue::reopen();
        Page::success(__('Status mapping saved.', 'fssync'));
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function saveModels(array $post): void
    {
        $rows = [];
        foreach ((array) ($post['models'] ?? []) as $row) {
            $name  = trim((string) ($row['name'] ?? ''));
            $alias = trim((string) ($row['alias'] ?? ''));
            if ($name !== '' && $alias !== '') {
                $rows[$name] = [$name, $alias, ['commercial' => trim((string) ($row['commercial'] ?? '')) ?: $alias]];
            }
        }
        Mapping::replaceKind(Mapping::KIND_MODEL, array_values($rows));
        Page::success(__('Model aliases saved.', 'fssync'));
    }

    /**
     * @param array<string, mixed> $post
     */
    private static function saveOs(array $post): void
    {
        $rows = [];
        foreach ((array) ($post['os'] ?? []) as $row) {
            $name  = trim((string) ($row['name'] ?? ''));
            $value = trim((string) ($row['value'] ?? ''));
            if ($name !== '' && $value !== '') {
                $rows[$name] = [$name, $value];
            }
        }
        Mapping::replaceKind(Mapping::KIND_OS, array_values($rows));
        Queue::reopen();
        Page::success(__('Operating system mapping saved.', 'fssync'));
    }

    // ----------------------------------------------------------------- exibição

    /**
     * @return array<string, mixed> dados do template para a aba pedida
     */
    public static function view(string $tab): array
    {
        $tabs = self::tabs();
        // Uma aba do modo completo pedida no modo "só atualizar" leva à aba onde se troca o modo.
        $tab  = in_array($tab, $tabs, true) ? $tab : (in_array($tab, self::TABS, true) ? 'sync' : $tabs[0]);
        $data = ['tab' => $tab, 'tabs' => $tabs, 'catalog_error' => null];

        return $data + match ($tab) {
            'connection' => self::viewConnection(),
            'sync'       => self::viewSync(),
            'users'      => self::viewUsers(),
            'types'      => self::viewTypes(),
            'states'     => self::viewStates(),
            'models'     => self::viewModels(),
            'os'         => self::viewOs(),
        };
    }

    /**
     * @return list<string> abas visíveis no modo atual
     */
    public static function tabs(): array
    {
        return Config::isUpdateOnly() ? array_values(array_diff(self::TABS, self::FULL_MODE_TABS)) : self::TABS;
    }

    /**
     * @return array<string, mixed>
     */
    private static function viewConnection(): array
    {
        $envs = [];
        foreach (self::ENVS as $env) {
            $envs[$env] = ['domain' => Config::domain($env), 'has_key' => Config::hasApiKey($env)];
        }
        $test = $_SESSION[self::SESSION_CONNECTION_TEST] ?? null;
        unset($_SESSION[self::SESSION_CONNECTION_TEST]);

        return [
            'envs'            => $envs,
            'active_env'      => Config::activeEnv(),
            'workspace_id'    => Config::get('workspace_id'),
            'connection_test' => $test,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private static function viewSync(): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $entities = [];
        foreach ($DB->request(['SELECT' => ['id', 'completename'], 'FROM' => 'glpi_entities', 'ORDER' => 'completename']) as $row) {
            $entities[(int) $row['id']] = (string) $row['completename'];
        }
        $selected   = Config::entities();
        $updateOnly = Config::isUpdateOnly();

        // As opções de estado só servem ao card de lixeira, que é do modo completo.
        [$catalog, $error] = $updateOnly ? [null, null] : self::catalog();
        $states = [];
        if ($catalog !== null) {
            try {
                foreach (self::existingMappedTypes($catalog, Mapping::settings()) as $assetTypeId) {
                    $states = array_values(array_unique(array_merge($states, $catalog->choices($assetTypeId, Field::STATE))));
                }
            } catch (ApiException $e) {
                $error = $e->getMessage();
            }
        }

        return [
            'catalog_error'       => $error,
            'update_only'         => $updateOnly,
            'update_fields'       => Config::updateFields(),
            'update_field_labels' => [UpdatePlan::USER => __('Used by', 'fssync'), UpdatePlan::STATE => __('State', 'fssync')],
            'entities'            => $entities,
            'selected'            => $selected,
            'values'              => array_map(Config::get(...), array_combine(array_keys(Config::DEFAULTS), array_keys(Config::DEFAULTS))),
            // O valor salvo continua na lista mesmo que o Freshservice não o devolva mais.
            'state_choices'       => $states === [] ? [] : array_values(array_unique(array_merge($states, [Config::get('retired_state')]))),
            'variables'           => DescriptionTemplate::VARIABLES,
            'computer_count'      => $selected === [] ? 0 : countElementsInTable('glpi_computers', ['entities_id' => $selected, 'is_template' => 0, 'is_deleted' => 0]),
        ];
    }

    /**
     * Domínios encontrados no nome alternativo do usuário dos computadores, com o de-para salvo.
     *
     * @return array<string, mixed>
     */
    private static function viewUsers(): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $saved = Mapping::settings()->userDomains;
        $rows  = [];
        $noContact = $noDomain = 0;
        $inUse = $DB->request([
            'SELECT'  => ['contact', 'COUNT' => 'id AS total'],
            'FROM'    => 'glpi_computers',
            'WHERE'   => ['is_template' => 0, 'is_deleted' => 0],
            'GROUPBY' => 'contact',
        ]);
        foreach ($inUse as $row) {
            [$login, $domain] = ComputerUser::split((string) $row['contact']);
            if ($login === '' && $domain === '') {
                $noContact += (int) $row['total'];
                continue;
            }
            if ($domain === '') {
                $noDomain += (int) $row['total'];
                continue;
            }
            $key        = strtoupper($domain);
            $rows[$key] = [
                'name'     => $key,
                'count'    => ($rows[$key]['count'] ?? 0) + (int) $row['total'],
                'value'    => $saved[$key] ?? '',
                'is_email' => str_contains($domain, '.'),
            ];
        }
        // De-paras salvos para domínios que hoje não estão em nenhum computador continuam na lista.
        foreach ($saved as $domain => $value) {
            $rows[$domain] ??= ['name' => $domain, 'count' => 0, 'value' => $value, 'is_email' => str_contains($domain, '.')];
        }
        ksort($rows);

        return ['domain_rows' => array_values($rows), 'no_contact' => $noContact, 'no_domain' => $noDomain];
    }

    /**
     * @return array<string, mixed>
     */
    private static function viewTypes(): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $glpiTypes = [0 => __('(no type)', 'fssync')];
        foreach ($DB->request(['SELECT' => ['id', 'name'], 'FROM' => 'glpi_computertypes', 'ORDER' => 'name']) as $row) {
            $glpiTypes[(int) $row['id']] = (string) $row['name'];
        }

        $settings = Mapping::settings();
        [$catalog, $error] = self::catalog();

        $assetTypes = $products = $fieldSections = $problems = [];
        if ($catalog !== null) {
            try {
                $allTypes    = $catalog->assetTypes();
                $allProducts = $catalog->products();
                $used        = array_merge(array_column($settings->types, 'asset_type_id'), array_filter([$settings->defaultType['asset_type_id'] ?? null]));
                foreach ($allTypes as $id => $type) {
                    // Tipos ocultos no Freshservice só aparecem se já estiverem em uso.
                    if ($type['visible'] || in_array($id, $used, true)) {
                        $assetTypes[$id] = $type['path'];
                    }
                }
                foreach ($allProducts as $id => $product) {
                    $products[$id] = $product['name'] . ' — ' . ($allTypes[$product['asset_type_id']]['name'] ?? '#' . $product['asset_type_id']);
                }
                // IDs salvos que não existem nesta instância (gravados com outro perfil, ou apagados lá).
                foreach (array_keys($settings->types) as $glpiTypeId) {
                    $items = [];
                    foreach (MappingCheck::missing($settings, $glpiTypeId, $allTypes, $allProducts) as $what => $id) {
                        $label = sprintf(__('#%d (does not exist in this Freshservice)', 'fssync'), $id);
                        if ($what === MappingCheck::ASSET_TYPE) {
                            $assetTypes[$id] = $label;
                            $items[]         = sprintf(__('asset type #%d', 'fssync'), $id);
                        } else {
                            $products[$id] = $label;
                            $items[]       = sprintf(__('product #%d', 'fssync'), $id);
                        }
                    }
                    if ($items !== []) {
                        $problems[] = ['type' => $glpiTypes[$glpiTypeId] ?? '#' . $glpiTypeId, 'items' => implode(', ', $items)];
                    }
                }
                // O próprio padrão também pode apontar para um ID que não existe (D-43).
                $default = $settings->defaultType;
                if ($default !== null && (!isset($allTypes[$default['asset_type_id']]) || !isset($allProducts[$default['product_id']]))) {
                    $problems[] = ['type' => __('Default', 'fssync'), 'items' => sprintf(__('asset type #%1$d / product #%2$d', 'fssync'), $default['asset_type_id'], $default['product_id']), 'default' => true];
                }
                foreach (self::existingMappedTypes($catalog, $settings) as $assetTypeId) {
                    $available = $catalog->typeFields((int) $assetTypeId);
                    $fieldSections[] = [
                        'asset_type_id' => (int) $assetTypeId,
                        'name'          => $allTypes[$assetTypeId]['path'] ?? '#' . $assetTypeId,
                        'available'     => array_map(static fn(array $f): string => $f['label'] . ' (' . $f['name'] . ')', $available),
                        'saved'         => array_map(static fn(array $f): string => $f['name'], $settings->fields[$assetTypeId] ?? []),
                    ];
                }
            } catch (ApiException $e) {
                $error = $e->getMessage();
            }
        }

        // O que está salvo continua selecionável mesmo sem acesso ao Freshservice:
        // assim, salvar a tela com a API fora do ar não apaga o de-para.
        foreach (array_merge($settings->types, array_filter([$settings->defaultType])) as $saved) {
            $assetTypes[$saved['asset_type_id']] ??= '#' . $saved['asset_type_id'];
            if ($saved['product_id'] > 0) {
                $products[$saved['product_id']] ??= '#' . $saved['product_id'];
            }
        }

        return [
            'catalog_error'    => $error,
            'mapping_problems' => $problems,
            'glpi_types'       => $glpiTypes,
            'type_mapping'     => $settings->types,
            'default_type'     => $settings->defaultType,
            'asset_types'      => $assetTypes,
            'products'         => $products,
            'field_sections'   => $fieldSections,
            'logical_fields'   => Catalog::logicalFields(),
            'required'         => Field::REQUIRED,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private static function viewStates(): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $glpiStates = [Settings::NO_STATE => __('(no status)', 'fssync')];
        foreach ($DB->request(['SELECT' => ['id', 'completename'], 'FROM' => 'glpi_states', 'ORDER' => 'completename']) as $row) {
            $glpiStates[(int) $row['id']] = (string) $row['completename'];
        }

        $settings   = Mapping::settings();
        $updateOnly = Config::isUpdateOnly();
        [$catalog, $error] = self::catalog();
        $choices = [];
        if ($catalog !== null) {
            try {
                // No modo "só atualizar" não há de-para de tipo: as opções vêm dos tipos
                // raiz, onde o Freshservice define o estado que os tipos filhos herdam (D-38).
                $sources = $updateOnly ? self::rootTypes($catalog) : self::existingMappedTypes($catalog, $settings);
                foreach ($sources as $assetTypeId) {
                    $choices = array_values(array_unique(array_merge($choices, $catalog->choices($assetTypeId, Field::STATE))));
                }
            } catch (ApiException $e) {
                $error = $e->getMessage();
            }
        }

        return [
            'catalog_error' => $error,
            'glpi_states'   => $glpiStates,
            'state_mapping' => $settings->states,
            'state_choices' => array_values(array_unique(array_merge($choices, array_values($settings->states)))),
            'has_types'     => $updateOnly || $settings->types !== [],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private static function viewModels(): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $saved = Mapping::settings()->models;
        $rows  = [];
        $inUse = $DB->request([
            'SELECT'     => ['model.name', 'COUNT' => 'c.id AS total'],
            'FROM'       => 'glpi_computers AS c',
            'INNER JOIN' => ['glpi_computermodels AS model' => ['ON' => ['model' => 'id', 'c' => 'computermodels_id']]],
            'WHERE'      => ['c.is_template' => 0, 'c.is_deleted' => 0],
            'GROUPBY'    => 'model.name',
            'ORDER'      => 'model.name',
        ]);
        foreach ($inUse as $row) {
            $rows[$row['name']] = ['name' => $row['name'], 'count' => (int) $row['total']] + ($saved[$row['name']] ?? ['alias' => '', 'commercial' => '']);
        }
        // Apelidos salvos para modelos que hoje não estão em nenhum computador continuam na lista.
        foreach ($saved as $name => $alias) {
            $rows[$name] ??= ['name' => $name, 'count' => 0] + $alias;
        }

        return ['model_rows' => array_values($rows)];
    }

    /**
     * @return array<string, mixed>
     */
    private static function viewOs(): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $settings = Mapping::settings();
        [$catalog, $error] = self::catalog();
        $choices = [];
        if ($catalog !== null) {
            try {
                foreach (self::existingMappedTypes($catalog, $settings) as $assetTypeId) {
                    $choices = array_values(array_unique(array_merge($choices, $catalog->choices($assetTypeId, Field::OS))));
                }
            } catch (ApiException $e) {
                $error = $e->getMessage();
            }
        }

        $rows  = [];
        $inUse = $DB->request([
            'SELECT'     => ['os.name AS name', 'edition.name AS edition', 'COUNT' => 'item.id AS total'],
            'FROM'       => 'glpi_items_operatingsystems AS item',
            'INNER JOIN' => ['glpi_operatingsystems AS os' => ['ON' => ['os' => 'id', 'item' => 'operatingsystems_id']]],
            'LEFT JOIN'  => ['glpi_operatingsystemeditions AS edition' => ['ON' => ['edition' => 'id', 'item' => 'operatingsystemeditions_id']]],
            'WHERE'      => ['item.itemtype' => 'Computer', 'item.is_deleted' => 0],
            'GROUPBY'    => ['os.name', 'edition.name'],
            'ORDER'      => 'os.name',
        ]);
        foreach ($inUse as $row) {
            $name = trim($row['name'] . ' ' . $row['edition']);
            $rows[$name] = [
                'name'    => $name,
                'count'   => ($rows[$name]['count'] ?? 0) + (int) $row['total'],
                'value'   => $settings->os[$name] ?? '',
                // Sem de-para, o nome do GLPI só serve se já estiver na lista do Freshservice.
                'in_list' => $choices === [] || in_array($name, $choices, true),
            ];
        }
        foreach ($settings->os as $name => $value) {
            $rows[$name] ??= ['name' => $name, 'count' => 0, 'value' => $value, 'in_list' => in_array($name, $choices, true)];
        }

        return [
            'catalog_error' => $error,
            'os_rows'       => array_values($rows),
            'os_choices'    => array_values(array_unique(array_merge($choices, array_values($settings->os)))),
            'has_types'     => $settings->types !== [],
        ];
    }

    /**
     * Tipos de ativo do de-para que existem no Freshservice ativo. Um ID que
     * não existe fica de fora: pedir os campos dele daria 404 e esconderia as
     * opções dos outros tipos.
     *
     * @return list<int>
     *
     * @throws ApiException
     */
    private static function existingMappedTypes(Catalog $catalog, Settings $settings): array
    {
        $existing = $catalog->assetTypes();

        return array_values(array_filter(
            array_unique(array_merge(array_column($settings->types, 'asset_type_id'), array_filter([$settings->defaultType['asset_type_id'] ?? null]))),
            static fn(int $id): bool => isset($existing[$id])
        ));
    }

    /**
     * Tipos de ativo sem pai (Hardware, Software...).
     *
     * @return list<int>
     *
     * @throws ApiException
     */
    private static function rootTypes(Catalog $catalog): array
    {
        $roots = [];
        foreach ($catalog->assetTypes() as $id => $type) {
            if (!str_contains($type['path'], ' > ')) {
                $roots[] = (int) $id;
            }
        }

        return $roots;
    }

    /**
     * @return array{?Catalog, ?string} o catálogo do ambiente ativo, ou a explicação de por que não está disponível
     */
    private static function catalog(): array
    {
        try {
            return [Catalog::forEnv(Config::activeEnv()), null];
        } catch (BlockedException $e) {
            return [null, $e->getMessage()];
        }
    }
}
