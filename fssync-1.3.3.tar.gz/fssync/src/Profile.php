<?php

namespace GlpiPlugin\Fssync;

use CommonGLPI;
use Html;
use Session;

/**
 * Aba "Freshservice Sync" na edição de perfil, com a matriz dos três níveis de direito.
 */
final class Profile extends \Profile
{
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if ($item instanceof \Profile && $item->getID() > 0) {
            return self::createTabEntry(Menu::getMenuName(), 0, null, Menu::getIcon());
        }

        return '';
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        if (!$item instanceof \Profile) {
            return false;
        }

        $canedit = Session::haveRightsOr(\Profile::$rightname, [CREATE, UPDATE, PURGE]);

        if ($canedit) {
            echo "<form method='post' action='" . htmlescape(\Profile::getFormURL()) . "'>";
        }

        $item->displayRightsChoiceMatrix(
            [
                [
                    'label'  => Menu::getMenuName(),
                    'field'  => Rights::NAME,
                    'rights' => Rights::labels(),
                ],
            ],
            [
                'canedit' => $canedit,
                'title'   => Menu::getMenuName(),
            ]
        );

        if ($canedit) {
            echo "<div class='text-center'>";
            echo Html::hidden('id', ['value' => $item->getID()]);
            echo Html::submit(_sx('button', 'Save'), ['name' => 'update', 'class' => 'btn btn-primary']);
            echo '</div>';
            Html::closeForm();
        }

        return true;
    }
}
