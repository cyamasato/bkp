<?php

namespace GlpiPlugin\Fssync;

use Session;

/**
 * Direito de perfil do plugin, em três níveis. Cada nível inclui o anterior:
 * quem configura também testa, e quem testa também vê.
 */
final class Rights
{
    public const NAME = 'plugin_fssync';

    /** Ver logs, fila e a aba do computador. */
    public const VIEW = READ;
    /** Usar a página de teste e o botão "Sincronizar agora". */
    public const TEST = 2048;
    /** Alterar a configuração. */
    public const CONFIGURE = UPDATE;

    public const ALL = self::VIEW | self::TEST | self::CONFIGURE;

    public static function canView(): bool
    {
        return Session::haveRightsOr(self::NAME, [self::VIEW, self::TEST, self::CONFIGURE]);
    }

    public static function canTest(): bool
    {
        return Session::haveRightsOr(self::NAME, [self::TEST, self::CONFIGURE]);
    }

    public static function canConfigure(): bool
    {
        return (bool) Session::haveRight(self::NAME, self::CONFIGURE);
    }

    /** Interrompe a requisição com "acesso negado" se o usuário não tiver o nível de leitura. */
    public static function checkView(): void
    {
        Session::checkRightsOr(self::NAME, [self::VIEW, self::TEST, self::CONFIGURE]);
    }

    public static function checkTest(): void
    {
        Session::checkRightsOr(self::NAME, [self::TEST, self::CONFIGURE]);
    }

    public static function checkConfigure(): void
    {
        Session::checkRight(self::NAME, self::CONFIGURE);
    }

    /** @return array<int, string> rótulo de cada nível, para a matriz de direitos do perfil */
    public static function labels(): array
    {
        return [
            self::VIEW      => __('View logs and queue', 'fssync'),
            self::TEST      => __('Test and sync manually', 'fssync'),
            self::CONFIGURE => __('Configure', 'fssync'),
        ];
    }
}
