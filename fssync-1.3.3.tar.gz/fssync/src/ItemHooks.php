<?php

namespace GlpiPlugin\Fssync;

use CommonDBTM;
use Computer;
use DBmysql;
use Throwable;
use Toolbox;

/**
 * Reage aos eventos do GLPI. Aqui nunca se chama o Freshservice: só se grava
 * o ID do computador na fila, e nenhum erro pode atrapalhar o salvamento no GLPI.
 *
 * Um inventário dispara dezenas de eventos do mesmo computador; todos caem na
 * mesma linha da fila (chave única), então o custo é uma gravação curta por evento.
 */
final class ItemHooks
{
    /** Computador criado, alterado ou restaurado da lixeira. */
    public static function computerChanged(CommonDBTM $item): void
    {
        self::guard(static function () use ($item): void {
            if (self::isSynced($item->fields)) {
                Queue::enqueue((int) $item->getID(), Queue::ACTION_SYNC);
            }
        });
    }

    /** Computador enviado para a lixeira ou purgado. */
    public static function computerRemoved(CommonDBTM $item): void
    {
        self::guard(static function () use ($item): void {
            if (Config::isUpdateOnly()) {
                // No modo "só atualizar", remover no GLPI não muda o Freshservice (D-40).
                Queue::forget((int) $item->getID());

                return;
            }
            if (self::isSynced($item->fields)) {
                Queue::enqueue((int) $item->getID(), Queue::ACTION_RETIRE);
            }
        });
    }

    /** Processador, memória, disco ou sistema operacional mudou: enfileira o computador pai. */
    public static function childChanged(CommonDBTM $item): void
    {
        self::guard(static function () use ($item): void {
            if (($item->fields['itemtype'] ?? '') !== Computer::class) {
                return;
            }
            $computerId = (int) ($item->fields['items_id'] ?? 0);
            if ($computerId <= 0) {
                return;
            }

            /** @var DBmysql $DB */
            global $DB;
            $computer = $DB->request([
                'SELECT' => ['entities_id', 'is_template'],
                'FROM'   => Computer::getTable(),
                'WHERE'  => ['id' => $computerId],
            ])->current();
            // Sem o computador, este evento faz parte de um purge: o próprio purge já enfileira.
            if ($computer && self::isSynced($computer)) {
                Queue::enqueue($computerId, Queue::ACTION_SYNC);
            }
        });
    }

    /**
     * @param array<string, mixed> $computer campos do computador
     */
    private static function isSynced(array $computer): bool
    {
        return !($computer['is_template'] ?? false)
            && in_array((int) ($computer['entities_id'] ?? -1), Config::entities(), true);
    }

    private static function guard(callable $work): void
    {
        try {
            $work();
        } catch (Throwable $e) {
            Toolbox::logInFile('fssync', sprintf("Falha ao enfileirar: %s (%s:%d)\n", $e->getMessage(), $e->getFile(), $e->getLine()));
        }
    }
}
