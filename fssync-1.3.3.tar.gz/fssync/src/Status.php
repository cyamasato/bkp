<?php

namespace GlpiPlugin\Fssync;

use CronTask;
use GlpiPlugin\Fssync\Mapping\UpdatePlan;

/**
 * Resumo do estado do plugin, exibido na página de status.
 */
final class Status
{
    /**
     * @return array{
     *     version: string,
     *     env: string,
     *     dry_run: bool,
     *     update_only: bool,
     *     update_fields: string,
     *     queue: array{pending: int, blocked: int, failed: int},
     *     links: int,
     *     cron: array{id: int, enabled: bool, lastrun: ?string}|null
     * }
     */
    public static function summary(): array
    {
        $env   = Config::activeEnv();
        $queue = [];
        foreach (['pending', 'blocked', 'failed'] as $status) {
            $queue[$status] = countElementsInTable(Queue::getTable(), ['status' => $status]);
        }

        $cron = null;
        $task = new CronTask();
        if ($task->getFromDBbyName(Cron::class, Cron::TASK)) {
            $cron = [
                'id'      => (int) $task->getID(),
                'enabled' => (int) $task->fields['state'] !== CronTask::STATE_DISABLE,
                'lastrun' => $task->fields['lastrun'],
            ];
        }

        $labels = [UpdatePlan::USER => __('Used by', 'fssync'), UpdatePlan::STATE => __('State', 'fssync')];

        return [
            'version'       => PLUGIN_FSSYNC_VERSION,
            'env'           => $env,
            'dry_run'       => Config::isDryRun(),
            'update_only'   => Config::isUpdateOnly(),
            'update_fields' => implode(', ', array_map(static fn(string $field): string => $labels[$field], Config::updateFields())),
            'queue'         => $queue,
            'links'         => countElementsInTable(Link::getTable(), ['fs_env' => $env]),
            'cron'          => $cron,
        ];
    }
}
