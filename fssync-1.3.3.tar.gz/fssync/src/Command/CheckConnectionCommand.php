<?php

namespace GlpiPlugin\Fssync\Command;

use Glpi\Console\AbstractCommand;
use GlpiPlugin\Fssync\Api\ClientFactory;
use GlpiPlugin\Fssync\Api\ConnectionTest;
use GlpiPlugin\Fssync\BlockedException;
use GlpiPlugin\Fssync\Config;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Testa, pela linha de comando, a conexão do servidor com o Freshservice:
 * rede (pelo proxy configurado no GLPI), API key e permissões.
 *
 *   php bin/console plugins:fssync:check [--env=prod|test] [--write-probes]
 *
 * Feito para a implantação: roda dentro do container de produção, de onde o
 * plugin realmente vai sair para a internet.
 */
final class CheckConnectionCommand extends AbstractCommand
{
    protected function configure(): void
    {
        parent::configure();

        $this->setName('plugins:fssync:check');
        $this->setDescription(__('Check the connection to Freshservice', 'fssync'));
        $this->addOption('env', null, InputOption::VALUE_REQUIRED, __('Environment to check (prod or test); default: the active one', 'fssync'));
        $this->addOption('write-probes', null, InputOption::VALUE_NONE, __('Also check the permission to create and edit assets (nothing is written)', 'fssync'));
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $env = match ($input->getOption('env')) {
            null                                => Config::activeEnv(),
            Config::ENV_PROD, Config::ENV_TEST  => $input->getOption('env'),
            default                             => null,
        };
        if ($env === null) {
            $output->writeln('<error>' . __('Unknown environment. Use prod or test.', 'fssync') . '</error>');

            return Command::INVALID;
        }

        try {
            $client = ClientFactory::forEnv($env);
        } catch (BlockedException $e) {
            $output->writeln('<comment>' . $e->getMessage() . '</comment>');

            return Command::FAILURE;
        }

        $output->writeln(sprintf('%s: %s', __('Environment', 'fssync'), $env));
        $failed = false;
        foreach (ConnectionTest::run($client, (bool) $input->getOption('write-probes')) as $result) {
            $failed = $failed || !$result['ok'];
            $output->writeln(sprintf(
                '  %s %s%s',
                $result['ok'] ? '<info>[ok]</info>' : '<error>[' . __('failed', 'fssync') . ']</error>',
                ConnectionTest::label($result['check']),
                $result['detail'] === '' ? '' : ': ' . $result['detail']
            ));
        }

        return $failed ? Command::FAILURE : Command::SUCCESS;
    }
}
