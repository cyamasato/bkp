<?php

namespace GlpiPlugin\Fssync\Command;

use Glpi\Console\AbstractCommand;
use GlpiPlugin\Fssync\Cron;
use GlpiPlugin\Fssync\Sync\QueueProcessor;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Processa a fila pela linha de comando, sem depender da frequência da ação automática:
 *   php bin/console plugins:fssync:process [--limit=N]
 */
final class ProcessQueueCommand extends AbstractCommand
{
    protected function configure(): void
    {
        parent::configure();

        $this->setName('plugins:fssync:process');
        $this->setDescription(__('Send queued computers to Freshservice', 'fssync'));
        $this->addOption('limit', 'l', InputOption::VALUE_REQUIRED, __('Maximum number of computers to process', 'fssync'));
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $limit   = $input->getOption('limit');
        $summary = QueueProcessor::run($limit === null ? null : max(1, (int) $limit));

        $output->writeln(Cron::describe($summary));

        return $summary['failed'] > 0 ? Command::FAILURE : Command::SUCCESS;
    }
}
