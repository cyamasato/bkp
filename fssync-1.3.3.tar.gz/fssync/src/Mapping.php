<?php

namespace GlpiPlugin\Fssync;

use CommonDBTM;
use DBmysql;
use GlpiPlugin\Fssync\Mapping\Settings;

/**
 * De-paras editáveis: tipo, status, apelido de modelo, SO, campos e domínio de usuário.
 */
class Mapping extends CommonDBTM
{
    /** ComputerType do GLPI => tipo de ativo (fs_value) e produto (extra.product_id). */
    public const KIND_TYPE  = 'computertype';
    /** State do GLPI (0 = sem status) => rótulo do estado do asset. */
    public const KIND_STATE = 'state';
    /** Nome do ComputerModel => apelido (fs_value) e nome comercial (extra.commercial). */
    public const KIND_MODEL = 'model_alias';
    /** Nome do SO no GLPI => opção da lista do Freshservice. */
    public const KIND_OS    = 'os';
    /** "<id do tipo de ativo>:<campo lógico>" => nome real do type_field (extra.choices se for lista fechada). */
    public const KIND_FIELD = 'field';
    /** Domínio do nome alternativo do usuário (maiúsculas) => domínio de e-mail (D-45). */
    public const KIND_USER_DOMAIN = 'user_domain';

    public static $rightname = Rights::NAME;

    public static function getTypeName($nb = 0)
    {
        return _n('Mapping', 'Mappings', $nb, 'fssync');
    }

    /**
     * Grava (ou substitui) um de-para. Como isso muda o payload, a revisão da
     * configuração sobe e os computadores passam a ser reenviados.
     *
     * @param array<string, mixed> $extra
     */
    public static function put(string $kind, string $glpiKey, string $fsValue, array $extra = []): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->updateOrInsert(
            self::getTable(),
            ['fs_value' => $fsValue, 'extra' => $extra === [] ? null : json_encode($extra, JSON_UNESCAPED_UNICODE)],
            ['kind' => $kind, 'glpi_key' => $glpiKey]
        );
        Config::bumpRevision();
    }

    /**
     * Substitui todos os de-paras de um tipo de uma vez (é o que a tela de configuração salva).
     *
     * @param list<array{0: string, 1: string, 2?: array<string, mixed>}> $rows [chave no GLPI, valor no Freshservice, extra]
     * @param ?string $keyPrefix quando informado, só substitui as chaves com esse prefixo
     */
    public static function replaceKind(string $kind, array $rows, ?string $keyPrefix = null): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->delete(self::getTable(), ['kind' => $kind] + ($keyPrefix === null ? [] : ['glpi_key' => ['LIKE', $keyPrefix . '%']]));
        foreach ($rows as $row) {
            $extra = $row[2] ?? [];
            $DB->insert(self::getTable(), [
                'kind'     => $kind,
                'glpi_key' => $row[0],
                'fs_value' => $row[1],
                'extra'    => $extra === [] ? null : json_encode($extra, JSON_UNESCAPED_UNICODE),
            ]);
        }
        Config::bumpRevision();
    }

    /**
     * @return array<string, array{fs_value: string, extra: array<string, mixed>}> de-paras de um tipo, por chave do GLPI
     */
    public static function ofKind(string $kind): array
    {
        /** @var DBmysql $DB */
        global $DB;

        $rows = [];
        foreach ($DB->request(['FROM' => self::getTable(), 'WHERE' => ['kind' => $kind], 'ORDER' => 'glpi_key']) as $row) {
            $rows[$row['glpi_key']] = ['fs_value' => (string) $row['fs_value'], 'extra' => json_decode((string) $row['extra'], true) ?: []];
        }

        return $rows;
    }

    public static function fieldKey(int $assetTypeId, string $logicalField): string
    {
        return $assetTypeId . ':' . $logicalField;
    }

    /**
     * Junta os de-paras e as opções de mapeamento no objeto que o PayloadBuilder usa.
     */
    public static function settings(): Settings
    {
        /** @var DBmysql $DB */
        global $DB;

        $types = $states = $models = $os = $fields = $userDomains = [];
        foreach ($DB->request(['FROM' => self::getTable()]) as $row) {
            $extra = json_decode((string) $row['extra'], true) ?: [];
            switch ($row['kind']) {
                case self::KIND_TYPE:
                    $types[(int) $row['glpi_key']] = [
                        'asset_type_id' => (int) $row['fs_value'],
                        'product_id'    => (int) ($extra['product_id'] ?? 0),
                    ];
                    break;
                case self::KIND_STATE:
                    $states[(int) $row['glpi_key']] = $row['fs_value'];
                    break;
                case self::KIND_MODEL:
                    $models[$row['glpi_key']] = [
                        'alias'      => $row['fs_value'],
                        'commercial' => (string) ($extra['commercial'] ?? $row['fs_value']),
                    ];
                    break;
                case self::KIND_OS:
                    $os[$row['glpi_key']] = $row['fs_value'];
                    break;
                case self::KIND_FIELD:
                    [$assetTypeId, $logical] = explode(':', $row['glpi_key'], 2) + [1 => ''];
                    $fields[(int) $assetTypeId][$logical] = [
                        'name'    => $row['fs_value'],
                        'choices' => isset($extra['choices']) && is_array($extra['choices']) ? array_values($extra['choices']) : null,
                    ];
                    break;
                case self::KIND_USER_DOMAIN:
                    $userDomains[strtoupper($row['glpi_key'])] = $row['fs_value'];
                    break;
            }
        }

        return new Settings(
            types: $types,
            states: $states,
            models: $models,
            os: $os,
            fields: $fields,
            descriptionTemplate: Config::get('description_template'),
            roundDisk: Config::get('disk_round_commercial') !== '0',
            cpuUnit: Config::get('cpu_unit') === Settings::CPU_GHZ ? Settings::CPU_GHZ : Settings::CPU_MHZ,
            revision: Config::int('config_revision'),
            defaultType: Config::int('default_asset_type_id') > 0 && Config::int('default_product_id') > 0
                ? ['asset_type_id' => Config::int('default_asset_type_id'), 'product_id' => Config::int('default_product_id')]
                : null,
            userDomains: $userDomains,
        );
    }
}
