<?php

namespace GlpiPlugin\Fssync;

use DBConnection;
use DBmysql;
use Migration;
use ProfileRight;

/**
 * Instalação e desinstalação. A instalação pode ser repetida (plugin:install --force):
 * só cria o que falta e nunca apaga dados nem configuração existentes.
 */
final class Install
{
    public static function install(Migration $migration): bool
    {
        /** @var DBmysql $DB */
        global $DB;

        // Até a 1.2 o cache de usuários era por usuário do GLPI; agora é por e-mail (D-45).
        // É só cache: a tabela é recriada e se refaz na próxima sincronização.
        if ($DB->tableExists(UserCache::getTable()) && $DB->fieldExists(UserCache::getTable(), 'users_id')) {
            $DB->doQuery('DROP TABLE ' . $DB->quoteName(UserCache::getTable()));
        }

        foreach (self::schema() as $table => $sql) {
            if (!$DB->tableExists($table)) {
                $DB->doQuery($sql);
            }
        }

        $migration->addConfig(Config::DEFAULTS, Config::CONTEXT);
        // Perfis que já administram o GLPI (direito de configuração) recebem os três níveis.
        $migration->addRight(Rights::NAME, Rights::ALL, ['config' => READ | UPDATE]);
        $migration->addCrontask(Cron::class, Cron::TASK, Cron::FREQUENCY);
        $migration->executeMigration();

        ProfileRight::cleanAllPossibleRights();

        return true;
    }

    public static function uninstall(Migration $migration): bool
    {
        /** @var DBmysql $DB */
        global $DB;

        foreach (array_keys(self::schema()) as $table) {
            $migration->dropTable($table);
        }
        $migration->executeMigration();

        $DB->delete('glpi_configs', ['context' => Config::CONTEXT]);
        ProfileRight::deleteProfileRights([Rights::NAME]);
        // As CronTasks do plugin são removidas pelo próprio GLPI depois deste hook.

        return true;
    }

    /**
     * @return array<string, string> nome da tabela => CREATE TABLE
     */
    private static function schema(): array
    {
        $sign    = DBConnection::getDefaultPrimaryKeySignOption();
        $options = sprintf(
            'ENGINE=InnoDB DEFAULT CHARSET=%s COLLATE=%s ROW_FORMAT=DYNAMIC',
            DBConnection::getDefaultCharset(),
            DBConnection::getDefaultCollation()
        );

        // Os IDs do Freshservice têm 11 dígitos: sempre BIGINT.
        return [
            Queue::getTable() => "CREATE TABLE `" . Queue::getTable() . "` (
                `id` int {$sign} NOT NULL AUTO_INCREMENT,
                `computers_id` int {$sign} NOT NULL DEFAULT '0',
                `action` varchar(20) NOT NULL DEFAULT 'sync',
                `status` varchar(20) NOT NULL DEFAULT 'pending',
                `attempts` int NOT NULL DEFAULT '0',
                `next_attempt_at` timestamp NULL DEFAULT NULL,
                `last_error` text,
                `date_creation` timestamp NULL DEFAULT NULL,
                `date_mod` timestamp NULL DEFAULT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `computers_id` (`computers_id`),
                KEY `status_next_attempt_at` (`status`, `next_attempt_at`)
            ) {$options}",

            Link::getTable() => "CREATE TABLE `" . Link::getTable() . "` (
                `id` int {$sign} NOT NULL AUTO_INCREMENT,
                `computers_id` int {$sign} NOT NULL DEFAULT '0',
                `fs_env` varchar(10) NOT NULL DEFAULT 'test',
                `fs_asset_id` bigint unsigned NOT NULL DEFAULT '0',
                `fs_display_id` bigint unsigned NOT NULL DEFAULT '0',
                `payload_hash` char(64) DEFAULT NULL,
                `last_fs_user_id` bigint unsigned DEFAULT NULL,
                `last_sync_at` timestamp NULL DEFAULT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `computer_env` (`computers_id`, `fs_env`),
                KEY `asset_env` (`fs_display_id`, `fs_env`)
            ) {$options}",

            UserCache::getTable() => "CREATE TABLE `" . UserCache::getTable() . "` (
                `id` int {$sign} NOT NULL AUTO_INCREMENT,
                `email` varchar(255) NOT NULL DEFAULT '',
                `fs_env` varchar(10) NOT NULL DEFAULT 'test',
                `fs_user_id` bigint unsigned DEFAULT NULL,
                `fs_kind` varchar(20) NOT NULL DEFAULT 'none',
                `fs_name` varchar(255) DEFAULT NULL,
                `checked_at` timestamp NULL DEFAULT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `email_env` (`email`, `fs_env`)
            ) {$options}",

            Log::getTable() => "CREATE TABLE `" . Log::getTable() . "` (
                `id` int {$sign} NOT NULL AUTO_INCREMENT,
                `date` timestamp NULL DEFAULT NULL,
                `computers_id` int {$sign} NOT NULL DEFAULT '0',
                `fs_env` varchar(10) NOT NULL DEFAULT 'test',
                `source` varchar(10) NOT NULL DEFAULT 'cron',
                `operation` varchar(20) NOT NULL DEFAULT '',
                `http_status` smallint DEFAULT NULL,
                `duration_ms` int DEFAULT NULL,
                `request` longtext,
                `response` longtext,
                `message` text,
                `users_id` int {$sign} NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`),
                KEY `date` (`date`),
                KEY `computers_id` (`computers_id`),
                KEY `operation` (`operation`)
            ) {$options}",

            Mapping::getTable() => "CREATE TABLE `" . Mapping::getTable() . "` (
                `id` int {$sign} NOT NULL AUTO_INCREMENT,
                `kind` varchar(30) NOT NULL DEFAULT '',
                `glpi_key` varchar(255) NOT NULL DEFAULT '',
                `fs_value` varchar(255) NOT NULL DEFAULT '',
                `extra` text,
                PRIMARY KEY (`id`),
                UNIQUE KEY `kind_key` (`kind`, `glpi_key`)
            ) {$options}",
        ];
    }
}
