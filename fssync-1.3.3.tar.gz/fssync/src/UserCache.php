<?php

namespace GlpiPlugin\Fssync;

use CommonDBTM;
use DBmysql;
use GlpiPlugin\Fssync\Sync\UserCacheStore;

/**
 * Cache da resolução e-mail -> solicitante ou agente do Freshservice.
 */
class UserCache extends CommonDBTM implements UserCacheStore
{
    public static $rightname = Rights::NAME;

    /** O nome da tabela não segue o da classe: `User` confundiria com o usuário do GLPI. */
    public static function getTable($classname = null)
    {
        return 'glpi_plugin_fssync_users';
    }

    public static function getTypeName($nb = 0)
    {
        return _n('Freshservice user', 'Freshservice users', $nb, 'fssync');
    }

    public function recall(string $email, string $env): ?array
    {
        /** @var DBmysql $DB */
        global $DB;

        $row = $DB->request([
            'FROM'  => self::getTable(),
            'WHERE' => ['email' => $email, 'fs_env' => $env],
            'LIMIT' => 1,
        ])->current();
        if (!$row) {
            return null;
        }

        return [
            'fs_user_id' => $row['fs_user_id'] === null ? null : (int) $row['fs_user_id'],
            'fs_kind'    => (string) $row['fs_kind'],
            'fs_name'    => (string) $row['fs_name'],
            'checked_at' => (int) strtotime((string) $row['checked_at']),
        ];
    }

    public function remember(string $email, string $env, ?int $fsUserId, string $kind, string $name, int $checkedAt): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->updateOrInsert(
            self::getTable(),
            [
                'fs_user_id' => $fsUserId,
                'fs_kind'    => $kind,
                'fs_name'    => $name,
                'checked_at' => date('Y-m-d H:i:s', $checkedAt),
            ],
            ['email' => $email, 'fs_env' => $env]
        );
    }
}
