<?php

namespace GlpiPlugin\Fssync;

use CommonGLPI;

/**
 * Entrada do plugin no menu Ferramentas.
 */
final class Menu extends CommonGLPI
{
    public static function getMenuName()
    {
        return __('Freshservice Sync', 'fssync');
    }

    public static function getIcon()
    {
        return 'ti ti-refresh';
    }

    public static function canView(): bool
    {
        return Rights::canView();
    }

    public static function getSearchURL($full = true)
    {
        return ($full ? \Plugin::getWebDir('fssync') : '/plugins/fssync') . '/front/status.php';
    }
}
