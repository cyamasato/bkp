<?php

namespace GlpiPlugin\Fssync;

use CommonDBTM;
use DBmysql;

/**
 * Vínculo entre um computador do GLPI e um asset do Freshservice, por ambiente.
 */
class Link extends CommonDBTM
{
    public static $rightname = Rights::NAME;

    public static function getTypeName($nb = 0)
    {
        return _n('Freshservice link', 'Freshservice links', $nb, 'fssync');
    }

    /**
     * @return ?array{id: int, fs_asset_id: int, fs_display_id: int, payload_hash: ?string, last_fs_user_id: ?int}
     */
    public static function forComputer(int $computerId, string $env): ?array
    {
        /** @var DBmysql $DB */
        global $DB;

        $row = $DB->request([
            'FROM'  => self::getTable(),
            'WHERE' => ['computers_id' => $computerId, 'fs_env' => $env],
            'LIMIT' => 1,
        ])->current();
        if (!$row) {
            return null;
        }

        return [
            'id'              => (int) $row['id'],
            'fs_asset_id'     => (int) $row['fs_asset_id'],
            'fs_display_id'   => (int) $row['fs_display_id'],
            'payload_hash'    => $row['payload_hash'],
            'last_fs_user_id' => $row['last_fs_user_id'] === null ? null : (int) $row['last_fs_user_id'],
        ];
    }

    /**
     * Cria ou atualiza o vínculo depois de um envio bem-sucedido.
     * Com $hash nulo, o próximo evento reenvia o computador mesmo sem mudanças.
     */
    public static function store(int $computerId, string $env, int $assetId, int $displayId, ?string $hash, ?int $fsUserId): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->updateOrInsert(
            self::getTable(),
            [
                'fs_asset_id'     => $assetId,
                'fs_display_id'   => $displayId,
                'payload_hash'    => $hash,
                'last_fs_user_id' => $fsUserId,
                'last_sync_at'    => $_SESSION['glpi_currenttime'] ?? date('Y-m-d H:i:s'),
            ],
            ['computers_id' => $computerId, 'fs_env' => $env]
        );
    }

    public static function forget(int $computerId, string $env): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->delete(self::getTable(), ['computers_id' => $computerId, 'fs_env' => $env]);
    }
}
