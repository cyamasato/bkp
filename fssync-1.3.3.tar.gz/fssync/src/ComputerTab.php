<?php

namespace GlpiPlugin\Fssync;

use CommonGLPI;
use Computer;
use DBmysql;
use Glpi\Application\View\TemplateRenderer;
use GlpiPlugin\Fssync\Api\ApiException;
use GlpiPlugin\Fssync\Sync\SyncService;
use GlpiPlugin\Fssync\Ui\Page;

/**
 * Aba "Freshservice" no computador: vínculo, último envio, fila e "Sincronizar agora".
 */
final class ComputerTab extends CommonGLPI
{
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if ($item instanceof Computer && $item->getID() > 0 && !$item->isTemplate() && Rights::canView()) {
            return self::createTabEntry(__('Freshservice', 'fssync'), 0, null, Menu::getIcon());
        }

        return '';
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        if (!$item instanceof Computer || !Rights::canView()) {
            return false;
        }

        /** @var DBmysql $DB */
        global $DB;

        $computerId = (int) $item->getID();
        $env        = Config::activeEnv();

        $link = $DB->request(['FROM' => Link::getTable(), 'WHERE' => ['computers_id' => $computerId, 'fs_env' => $env]])->current() ?: null;
        $queue = $DB->request(['FROM' => Queue::getTable(), 'WHERE' => ['computers_id' => $computerId]])->current() ?: null;
        $lastLog = $DB->request([
            'FROM'  => Log::getTable(),
            'WHERE' => ['computers_id' => $computerId, 'fs_env' => $env],
            'ORDER' => 'id DESC',
            'LIMIT' => 1,
        ])->current() ?: null;

        TemplateRenderer::getInstance()->display('@fssync/computer_tab.html.twig', [
            'computers_id' => $computerId,
            'env'          => $env,
            'dry_run'      => Config::isDryRun(),
            'synced'       => in_array((int) $item->fields['entities_id'], Config::entities(), true),
            'link'         => $link,
            'asset_url'    => $link === null ? '' : Config::assetUrl($env, (int) $link['fs_display_id']),
            'queue'        => $queue,
            'position'     => $queue === null ? null : Queue::position($queue),
            'last_log'     => $lastLog,
            'can_test'     => Rights::canTest(),
            'base'         => Page::baseUrl(),
        ]);

        return true;
    }

    /**
     * "Sincronizar agora": envia o computador na hora, sem esperar a fila.
     * A mensagem do resultado aparece ao voltar para a página do computador.
     */
    public static function syncNow(int $computerId): void
    {
        try {
            $result = SyncService::fromConfig(Log::SOURCE_MANUAL)->sync($computerId, force: true);
            Queue::forget($computerId);
            Page::success($result->message);
        } catch (BlockedException | ApiException $e) {
            Page::error($e->getMessage());
        }
    }
}
