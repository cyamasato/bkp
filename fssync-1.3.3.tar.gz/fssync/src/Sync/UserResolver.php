<?php

namespace GlpiPlugin\Fssync\Sync;

use Closure;
use GlpiPlugin\Fssync\Api\AuthException;
use GlpiPlugin\Fssync\Api\FreshserviceClient;
use GlpiPlugin\Fssync\Api\NotFoundException;
use GlpiPlugin\Fssync\Api\ValidationException;
use GlpiPlugin\Fssync\BlockedException;
use GlpiPlugin\Fssync\Mapping\ComputerUser;

/**
 * Descobre quem é, no Freshservice, o usuário de um computador do GLPI:
 * e-mail (ComputerUser) -> solicitante -> agente. O resultado fica em cache,
 * por e-mail.
 *
 * A política para "não encontrado" (bloquear ou usar um usuário padrão) é
 * aplicada por quem chama, não aqui.
 */
final class UserResolver
{
    /** Um "não encontrado" é reconsultado depois deste prazo: a pessoa pode ter sido cadastrada. */
    public const NOT_FOUND_TTL = 86400;
    /** Um "encontrado" também vence, para o caso de a pessoa ser removida do Freshservice. */
    public const FOUND_TTL = 7 * 86400;

    /** @var Closure(): int */
    private Closure $clock;

    /**
     * @param ?callable(): int $clock relógio em segundos; só os testes passam outro
     */
    public function __construct(
        private readonly FreshserviceClient $client,
        private readonly UserCacheStore $cache,
        private readonly string $env,
        ?callable $clock = null,
    ) {
        $this->clock = ($clock ?? time(...))(...);
    }

    /**
     * @throws BlockedException quando a API key não tem permissão para ler agentes
     */
    public function resolve(ComputerUser $who): UserResolution
    {
        if ($who->isNone()) {
            return UserResolution::noUser();
        }

        $email = $who->email;
        if ($email === '') {
            return UserResolution::notFound('');
        }

        $now    = ($this->clock)();
        $cached = $this->cache->recall($email, $this->env);
        if ($cached !== null) {
            $age = $now - $cached['checked_at'];
            if ($cached['fs_user_id'] !== null && $age < self::FOUND_TTL) {
                return UserResolution::found($cached['fs_user_id'], $cached['fs_kind'], $email, $cached['fs_name']);
            }
            if ($cached['fs_user_id'] === null && $age < self::NOT_FOUND_TTL) {
                return $cached['fs_kind'] === UserResolution::KIND_INVALID
                    ? UserResolution::invalidEmail($email)
                    : UserResolution::notFound($email);
            }
        }

        $resolution = $this->lookup($email);
        $this->cache->remember($email, $this->env, $resolution->fsUserId, $resolution->kind, $resolution->name, $now);

        return $resolution;
    }

    private function lookup(string $email): UserResolution
    {
        try {
            $requester = $this->client->findRequesterByEmail($email);
        } catch (ValidationException) {
            // O Freshservice recusa um e-mail fora do formato (uma conta local do
            // Windows, por exemplo): repetir não adianta, é usuário não resolvido (D-46).
            return UserResolution::invalidEmail($email);
        }
        if ($requester !== null) {
            return UserResolution::found((int) $requester['id'], UserResolution::KIND_REQUESTER, $email, self::fullName($requester));
        }

        try {
            $agent = $this->client->findAgentByEmail($email);
        } catch (AuthException $e) {
            // Não é "usuário não encontrado": sem essa leitura, um agente seria
            // tratado como inexistente e o computador iria para a pessoa errada.
            throw new BlockedException(
                __('The Freshservice API key cannot read agents, so the computer user cannot be resolved. Grant the permission to the API key role.', 'fssync'),
                0,
                $e
            );
        }
        if ($agent !== null) {
            return UserResolution::found((int) $agent['id'], UserResolution::KIND_AGENT, $email, self::fullName($agent));
        }

        return UserResolution::notFound($email);
    }

    /**
     * Departamentos de uma pessoa do Freshservice, solicitante ou agente. O
     * Freshservice só aceita como "Usado por" quem pertence ao departamento do
     * asset (D-41).
     *
     * @return list<int>
     *
     * @throws BlockedException quando a API key não tem permissão para ler agentes
     */
    public function departmentsOf(int $fsUserId): array
    {
        try {
            $person = $this->client->getRequester($fsUserId);
        } catch (NotFoundException) {
            try {
                $person = $this->client->getAgent($fsUserId);
            } catch (AuthException $e) {
                throw new BlockedException(
                    __('The Freshservice API key cannot read agents, so the computer user cannot be resolved. Grant the permission to the API key role.', 'fssync'),
                    0,
                    $e
                );
            }
        }

        return array_values(array_map(intval(...), (array) ($person['department_ids'] ?? [])));
    }

    /**
     * @param array<string, mixed> $person
     */
    private static function fullName(array $person): string
    {
        return trim(($person['first_name'] ?? '') . ' ' . ($person['last_name'] ?? ''));
    }
}
