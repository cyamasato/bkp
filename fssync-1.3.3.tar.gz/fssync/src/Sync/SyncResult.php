<?php

namespace GlpiPlugin\Fssync\Sync;

/**
 * O que aconteceu ao sincronizar um computador.
 */
final readonly class SyncResult
{
    /**
     * @param string $operation uma das constantes Log::OP_*
     * @param ?int   $displayId número do asset no Freshservice, quando há um
     * @param bool   $wrote     true se algo foi gravado no Freshservice
     */
    public function __construct(
        public string $operation,
        public string $message,
        public ?int $displayId = null,
        public bool $wrote = false,
    ) {}
}
