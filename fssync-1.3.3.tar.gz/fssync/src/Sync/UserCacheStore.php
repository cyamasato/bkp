<?php

namespace GlpiPlugin\Fssync\Sync;

/**
 * Onde o UserResolver guarda o que já descobriu, por e-mail e ambiente. A
 * implementação real é a tabela do plugin (UserCache); os testes usam uma em memória.
 */
interface UserCacheStore
{
    /**
     * @return ?array{fs_user_id: ?int, fs_kind: string, fs_name: string, checked_at: int}
     *         `checked_at` em segundos desde a época Unix
     */
    public function recall(string $email, string $env): ?array;

    public function remember(string $email, string $env, ?int $fsUserId, string $kind, string $name, int $checkedAt): void;
}
