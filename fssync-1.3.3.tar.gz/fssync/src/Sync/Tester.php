<?php

namespace GlpiPlugin\Fssync\Sync;

use DBmysql;
use GlpiPlugin\Fssync\Api\ApiException;
use GlpiPlugin\Fssync\Api\Catalog;
use GlpiPlugin\Fssync\Api\ClientFactory;
use GlpiPlugin\Fssync\Api\FreshserviceClient;
use GlpiPlugin\Fssync\Api\NotFoundException;
use GlpiPlugin\Fssync\BlockedException;
use GlpiPlugin\Fssync\Config;
use GlpiPlugin\Fssync\Link;
use GlpiPlugin\Fssync\Log;
use GlpiPlugin\Fssync\Mapping;
use GlpiPlugin\Fssync\Mapping\AssetDiff;
use GlpiPlugin\Fssync\Mapping\ComputerSnapshot;
use GlpiPlugin\Fssync\Mapping\Field;
use GlpiPlugin\Fssync\Mapping\MappingCheck;
use GlpiPlugin\Fssync\Mapping\MappingException;
use GlpiPlugin\Fssync\Mapping\PayloadBuilder;
use GlpiPlugin\Fssync\Mapping\Settings;
use GlpiPlugin\Fssync\Mapping\UpdatePlan;
use GlpiPlugin\Fssync\Mapping\UserIdRule;
use GlpiPlugin\Fssync\UserCache;

/**
 * O que a página "Testar sincronização" faz além do envio normal: validar sem
 * gravar e enviar um computador fictício (que não existe no GLPI).
 *
 * O envio de um computador real passa pelo SyncService, como na fila.
 */
final class Tester
{
    public const STATUS_OK      = 'ok';
    public const STATUS_WARNING = 'warning';
    public const STATUS_ERROR   = 'error';

    public const TARGET_CREATE = 'create';
    public const TARGET_UPDATE = 'update';
    /** Modo "só atualizar": nenhum asset com o número de série; nada será feito. */
    public const TARGET_NONE = 'none';
    /** Modo "só atualizar": o asset já tem os valores; nada será enviado. */
    public const TARGET_UP_TO_DATE = 'up_to_date';

    public function __construct(
        private readonly FreshserviceClient $client,
        private readonly UserResolver $users,
        private readonly Catalog $catalog,
        private readonly Settings $settings,
        private readonly string $env,
    ) {}

    /**
     * @throws BlockedException quando o ambiente ativo não tem domínio ou API key
     */
    public static function fromConfig(): self
    {
        /** @var \Psr\SimpleCache\CacheInterface $GLPI_CACHE */
        global $GLPI_CACHE;

        $env    = Config::activeEnv();
        $client = ClientFactory::forEnv($env);

        return new self(
            $client,
            new UserResolver($client, new UserCache(), $env),
            new Catalog($client, $GLPI_CACHE, $env),
            Mapping::settings(),
            $env,
        );
    }

    /**
     * Confere tudo o que pode dar errado no envio, só com leituras.
     *
     * @return array{
     *     checks: list<array{check: string, status: string, detail: string}>,
     *     target: ?string,
     *     display_id: ?int,
     *     body: ?array<string, mixed>,
     *     diff: list<array{field: string, current: mixed, new: mixed, changed: bool}>
     * }
     */
    public function validate(ComputerSnapshot $computer): array
    {
        $checks = [];
        $add    = static function (string $check, string $status, string $detail = '') use (&$checks): void {
            $checks[] = ['check' => $check, 'status' => $status, 'detail' => $detail];
        };
        $result = ['checks' => &$checks, 'target' => null, 'display_id' => null, 'body' => null, 'diff' => []];

        // O de-para efetivo: o do tipo do computador ou o padrão (D-43). Sem padrão, um tipo ou
        // produto que não existe é a causa de qualquer outro erro do de-para (D-35).
        try {
            [$settings, $defaulted, $missing] = $this->effectiveSettings($computer);
        } catch (BlockedException $e) {
            $add('mapping', self::STATUS_ERROR, $e->getMessage());

            return $result;
        }
        if ($missing !== []) {
            $add('mapping', self::STATUS_ERROR, MappingCheck::message($computer->typeId, $missing));

            return $result;
        }
        if ($defaulted !== null) {
            $add('default_type', self::STATUS_WARNING, $defaulted);
        }

        $explained = PayloadBuilder::explain($computer, $settings);
        if ($explained['payload'] === null) {
            $add('mapping', self::STATUS_ERROR, (string) $explained['error']);

            return $result;
        }
        $payload = $explained['payload'];
        $add('mapping', self::STATUS_OK);

        $typeExists = true;
        try {
            $type = $this->client->getAssetType($payload['asset_type_id']);
            $add('asset_type', self::STATUS_OK, sprintf('#%d %s', $payload['asset_type_id'], $type['name'] ?? ''));
        } catch (NotFoundException) {
            $typeExists = false;
            $add('asset_type', self::STATUS_ERROR, MappingCheck::message($computer->typeId, [MappingCheck::ASSET_TYPE => $payload['asset_type_id']]));
        } catch (ApiException $e) {
            $add('asset_type', self::STATUS_ERROR, $e->getMessage());

            return $result;
        }

        $productId = (int) $settings->types[$computer->typeId]['product_id'];
        try {
            $product = $this->client->getProduct($productId);
            $add('product', self::STATUS_OK, sprintf('#%d %s', $productId, $product['name'] ?? ''));
        } catch (NotFoundException) {
            $add('product', self::STATUS_ERROR, MappingCheck::message($computer->typeId, [MappingCheck::PRODUCT => $productId]));
        } catch (ApiException $e) {
            $add('product', self::STATUS_ERROR, $e->getMessage());
        }

        $fsUserId = $this->checkUser($computer, $add);

        // ---- criar ou atualizar
        try {
            [$displayId, $asset, $lastUser, $firstSync] = $this->findTarget($computer);
        } catch (BlockedException | ApiException $e) {
            $add('target', self::STATUS_ERROR, $e->getMessage());

            return $result;
        }

        $body = $payload + (UserIdRule::mustSend($fsUserId, $lastUser, $firstSync) ? ['user_id' => $fsUserId] : []);
        if ($asset !== null) {
            if ($defaulted !== null) {
                // O padrão vale só para criar: o asset existente mantém o tipo e o produto dele (D-43).
                unset($body['asset_type_id'], $body['type_fields'][$settings->fields[$payload['asset_type_id']][Field::PRODUCT]['name'] ?? '']);
            }
            if (isset($body['user_id']) && UpdatePlan::needsDepartments($asset, $body['user_id'])) {
                try {
                    $body += UpdatePlan::departmentFor($asset, $body['user_id'], $this->users->departmentsOf((int) $body['user_id']));
                } catch (BlockedException | ApiException $e) {
                    $add('department', self::STATUS_ERROR, $e->getMessage());
                }
            }
        }
        $result['body']       = $body;
        $result['display_id'] = $displayId;
        $result['target']     = $asset === null ? self::TARGET_CREATE : self::TARGET_UPDATE;
        if ($asset !== null) {
            $result['diff'] = AssetDiff::compare($body, $asset);
        }

        // ---- obrigatórios do tipo no Freshservice
        if (!$typeExists) {
            $add('required', self::STATUS_ERROR, __('Not checked: the asset type does not exist.', 'fssync'));

            return $result;
        }
        try {
            $missing = [];
            foreach ($this->catalog->typeFields($payload['asset_type_id']) as $name => $field) {
                $filled = isset($body['type_fields'][$name]) || ($asset['type_fields'][$name] ?? null) !== null;
                if ($field['required'] && !$filled) {
                    $missing[] = $field['label'] . ' (' . $name . ')';
                }
            }
            $add('required', $missing === [] ? self::STATUS_OK : self::STATUS_ERROR, implode(', ', $missing));
        } catch (ApiException $e) {
            $add('required', self::STATUS_ERROR, $e->getMessage());
        }

        return $result;
    }

    /**
     * Modo "só atualizar": confere, só com leituras, qual asset seria
     * atualizado e com quais valores.
     *
     * @param list<string> $fields campos escolhidos (UpdatePlan::FIELDS)
     *
     * @return array{
     *     checks: list<array{check: string, status: string, detail: string}>,
     *     target: ?string,
     *     display_id: ?int,
     *     body: ?array<string, mixed>,
     *     diff: list<array{field: string, current: mixed, new: mixed, changed: bool}>
     * }
     */
    public function validateUpdate(ComputerSnapshot $computer, array $fields): array
    {
        $checks = [];
        $add    = static function (string $check, string $status, string $detail = '') use (&$checks): void {
            $checks[] = ['check' => $check, 'status' => $status, 'detail' => $detail];
        };
        $result = ['checks' => &$checks, 'target' => null, 'display_id' => null, 'body' => null, 'diff' => []];

        if ($fields === []) {
            $add('fields', self::STATUS_ERROR, __('No field is selected for update. Choose them in Configuration > Synchronization.', 'fssync'));

            return $result;
        }

        // ---- asset que seria atualizado
        if (trim($computer->serial) === '') {
            $add('asset', self::STATUS_WARNING, __('The computer has no serial number, so no Freshservice asset can be found; nothing was updated.', 'fssync'));
            $result['target'] = self::TARGET_NONE;

            return $result;
        }
        try {
            [$displayId, $asset, $lastUser] = $this->findTarget($computer);
        } catch (BlockedException | ApiException $e) {
            $add('asset', self::STATUS_ERROR, $e->getMessage());

            return $result;
        }
        if ($asset === null) {
            $add('asset', self::STATUS_WARNING, sprintf(__('No Freshservice asset has serial number "%s"; nothing will be updated.', 'fssync'), $computer->serial));
            $result['target'] = self::TARGET_NONE;

            return $result;
        }
        $add('asset', self::STATUS_OK, sprintf('#%d %s', $displayId, $asset['name'] ?? ''));

        // ---- campos escolhidos
        $fsUserId = in_array(UpdatePlan::USER, $fields, true) ? $this->checkUser($computer, $add) : null;
        $stateField = null;
        if (in_array(UpdatePlan::STATE, $fields, true)) {
            try {
                $stateField = $this->catalog->stateField((int) ($asset['asset_type_id'] ?? 0), $this->settings);
                if ($stateField !== null) {
                    $add('state_field', self::STATUS_OK, $stateField['name']);
                }
            } catch (ApiException $e) {
                $add('state_field', self::STATUS_ERROR, $e->getMessage());
            }
        }

        $departments = null;
        if (in_array(UpdatePlan::USER, $fields, true) && UpdatePlan::needsDepartments($asset, $fsUserId)) {
            try {
                $departments = $this->users->departmentsOf((int) $fsUserId);
            } catch (BlockedException | ApiException $e) {
                $add('department', self::STATUS_ERROR, $e->getMessage());

                return $result;
            }
        }

        $plan = UpdatePlan::build($computer, $this->settings, $fields, $asset, $stateField, $fsUserId, $lastUser, $departments);
        foreach ($plan['warnings'] as $warning) {
            $add('update_warning', self::STATUS_WARNING, $warning);
        }
        $result['display_id'] = (int) $displayId;
        $result['diff']       = $plan['diff'];
        $result['body']       = $plan['body'] === [] ? null : $plan['body'];
        $result['target']     = $plan['body'] === [] ? self::TARGET_UP_TO_DATE : self::TARGET_UPDATE;

        return $result;
    }

    /**
     * Resolve o usuário do computador como o envio faria, registrando o resultado.
     *
     * @param callable(string, string, string=): void $add
     *
     * @return ?int o usuário que seria enviado (null = nenhum)
     */
    private function checkUser(ComputerSnapshot $computer, callable $add): ?int
    {
        try {
            $user       = SyncService::computerUser($computer, $this->settings);
            $resolution = $this->users->resolve($user);
            if (!$resolution->hasUser) {
                $add('no_user', self::STATUS_WARNING);

                return null;
            }
            if ($resolution->isFound()) {
                $add('user', self::STATUS_OK, sprintf('%s → %s #%d (%s)', $resolution->email, $resolution->kind, $resolution->fsUserId, $resolution->name));

                return $resolution->fsUserId;
            }
            $who = $resolution->reason($user->problem);
            switch (Config::userPolicy()) {
                case Config::USER_POLICY_DEFAULT:
                    $add('user_default', self::STATUS_WARNING, sprintf('%s → #%d', $who, Config::defaultFsUserId()));

                    return Config::defaultFsUserId();
                case Config::USER_POLICY_SKIP:
                    $add('user_skipped', self::STATUS_WARNING, $who);

                    return null;
            }
            $add('user_not_found', self::STATUS_ERROR, $who);
        } catch (BlockedException | ApiException $e) {
            $add('user_not_found', self::STATUS_ERROR, $e->getMessage());
        }

        return null;
    }

    /**
     * Envia um computador fictício: cria o asset, ou atualiza o que já tiver o mesmo número de série.
     *
     * @return array{operation: string, display_id: int, message: string}
     *
     * @throws BlockedException|ApiException
     */
    public function executeFictitious(ComputerSnapshot $computer): array
    {
        try {
            [$settings, $defaulted, $missing] = $this->effectiveSettings($computer);
            if ($missing !== []) {
                throw new MappingException(MappingCheck::message($computer->typeId, $missing));
            }
            $payload = PayloadBuilder::build($computer, $settings);

            $fsUserId   = null;
            $user       = SyncService::computerUser($computer, $this->settings);
            $resolution = $this->users->resolve($user);
            if ($resolution->isFound()) {
                $fsUserId = $resolution->fsUserId;
            } elseif ($resolution->hasUser) {
                $fsUserId = match (Config::userPolicy()) {
                    Config::USER_POLICY_DEFAULT => Config::defaultFsUserId(),
                    Config::USER_POLICY_SKIP    => null,
                    default                     => throw new BlockedException(sprintf(
                        __('Computer user cannot be resolved: %s.', 'fssync'),
                        $resolution->reason($user->problem)
                    )),
                };
            }

            [$displayId, $asset] = $this->findTarget($computer);
            $body = $payload + ($fsUserId === null ? [] : ['user_id' => $fsUserId]);

            if ($asset === null) {
                if (Config::workspaceId() !== null) {
                    $body['workspace_id'] = Config::workspaceId();
                }
                $created   = $this->client->createAsset($body);
                $displayId = (int) $created['display_id'];
                $operation = Log::OP_CREATE;
                $message   = sprintf(__('Asset #%d created.', 'fssync'), $displayId);
            } else {
                if ($defaulted !== null) {
                    // O padrão vale só para criar (D-43).
                    unset($body['asset_type_id'], $body['type_fields'][$settings->fields[$payload['asset_type_id']][Field::PRODUCT]['name'] ?? '']);
                }
                if ($fsUserId !== null && UpdatePlan::needsDepartments($asset, $fsUserId)) {
                    $body += UpdatePlan::departmentFor($asset, $fsUserId, $this->users->departmentsOf($fsUserId));
                }
                $this->client->updateAsset((int) $displayId, $body);
                $operation = Log::OP_UPDATE;
                $message   = sprintf(__('Asset #%d updated.', 'fssync'), $displayId);
            }
            $message .= $defaulted === null ? '' : ' ' . $defaulted;
        } catch (BlockedException $e) {
            Log::write(Log::OP_BLOCKED, 0, $this->env, Log::SOURCE_MANUAL, $e->getMessage());
            throw $e;
        } catch (ApiException $e) {
            Log::write(Log::OP_ERROR, 0, $this->env, Log::SOURCE_MANUAL, $e->getMessage(), $this->client->lastExchange());
            throw $e;
        }

        Log::write($operation, 0, $this->env, Log::SOURCE_MANUAL, $message . ' ' . __('(fictitious computer)', 'fssync'), $this->client->lastExchange());

        return ['operation' => $operation, 'display_id' => (int) $displayId, 'message' => $message];
    }

    /**
     * Exclui o asset criado por um teste com computador fictício. Só aceita
     * assets que esta página criou: um número de série digitado no formulário
     * pode coincidir com o de um asset de verdade.
     *
     * @return array{display_id: int, message: string}
     *
     * @throws BlockedException|ApiException
     */
    public function deleteTestAsset(string $serial): array
    {
        $found = $this->client->findAssetsBySerial(trim($serial));
        if (count($found) !== 1) {
            throw new BlockedException(sprintf(
                __('Expected exactly one asset with serial number "%1$s", found %2$d.', 'fssync'),
                $serial,
                count($found)
            ));
        }
        $displayId = (int) $found[0]['display_id'];
        if (!$this->wasCreatedByTestPage($displayId)) {
            throw new BlockedException(sprintf(
                __('Asset #%d was not created by this test page, so it will not be deleted here.', 'fssync'),
                $displayId
            ));
        }

        try {
            $this->client->deleteAsset($displayId);
        } catch (ApiException $e) {
            Log::write(Log::OP_ERROR, 0, $this->env, Log::SOURCE_MANUAL, $e->getMessage(), $this->client->lastExchange());
            throw $e;
        }
        $message = sprintf(__('Asset #%d deleted.', 'fssync'), $displayId);
        Log::write(Log::OP_DELETE, 0, $this->env, Log::SOURCE_MANUAL, $message . ' ' . __('(fictitious computer)', 'fssync'), $this->client->lastExchange());

        return ['display_id' => $displayId, 'message' => $message];
    }

    /**
     * @return ?array{method: string, url: string, request: ?array, status: int, response: mixed, duration_ms: int}
     */
    public function lastExchange(): ?array
    {
        return $this->client->lastExchange();
    }

    public function rateLimitRemaining(): ?int
    {
        return $this->client->rateLimitRemaining();
    }

    /**
     * O de-para efetivo do computador: o do tipo dele ou o padrão (D-43). Se as
     * listas do Freshservice não carregarem, só o caso "sem de-para" usa o padrão,
     * e as verificações seguintes apontam o problema.
     *
     * @return array{Settings, ?string, array<string, int>} o Settings efetivo, o aviso do padrão
     *         e, sem padrão configurado, o tipo e/ou produto do de-para que não existem
     *
     * @throws MappingException quando o próprio padrão não existe no Freshservice
     */
    private function effectiveSettings(ComputerSnapshot $computer): array
    {
        try {
            $assetTypes = $this->catalog->assetTypes();
            $products   = $this->catalog->products();
        } catch (ApiException) {
            $assetTypes = $products = null;
        }
        $resolved = MappingCheck::resolve($this->settings, $computer->typeId, $assetTypes, $products);
        $missing  = $resolved['defaulted'] === null && $assetTypes !== null && $products !== null && isset($this->settings->types[$computer->typeId])
            ? MappingCheck::missing($this->settings, $computer->typeId, $assetTypes, $products)
            : [];

        return [$resolved['settings'], $resolved['defaulted'], $missing];
    }

    /**
     * Descobre o asset que o envio atingiria: o vinculado (computador real) ou o de mesmo número de série.
     *
     * @return array{?int, ?array<string, mixed>, ?int, bool} display_id, asset atual, último user_id enviado, primeiro envio?
     *
     * @throws BlockedException quando há mais de um asset com o mesmo número de série
     */
    private function findTarget(ComputerSnapshot $computer): array
    {
        $link = $computer->id > 0 ? Link::forComputer($computer->id, $this->env) : null;
        if ($link !== null) {
            try {
                return [$link['fs_display_id'], $this->client->getAsset($link['fs_display_id']), $link['last_fs_user_id'], false];
            } catch (NotFoundException) {
                // O asset vinculado sumiu: vale a busca por número de série, como no envio.
            }
        }

        $found = $this->client->findAssetsBySerial($computer->serial);
        if (count($found) > 1) {
            throw new BlockedException(sprintf(
                __('Serial number "%1$s" is on more than one Freshservice asset (%2$s). Link the right one manually.', 'fssync'),
                $computer->serial,
                implode(', ', array_map(static fn(array $asset): string => '#' . $asset['display_id'], $found))
            ));
        }

        return [$found[0]['display_id'] ?? null, $found[0] ?? null, null, true];
    }

    private function wasCreatedByTestPage(int $displayId): bool
    {
        /** @var DBmysql $DB */
        global $DB;

        $rows = $DB->request([
            'SELECT' => 'response',
            'FROM'   => Log::getTable(),
            'WHERE'  => [
                'computers_id' => 0,
                'fs_env'       => $this->env,
                'source'       => Log::SOURCE_MANUAL,
                'operation'    => Log::OP_CREATE,
            ],
        ]);
        foreach ($rows as $row) {
            $response = json_decode((string) $row['response'], true);
            if ((int) ($response['asset']['display_id'] ?? 0) === $displayId) {
                return true;
            }
        }

        return false;
    }
}
