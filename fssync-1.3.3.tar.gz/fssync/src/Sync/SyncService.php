<?php

namespace GlpiPlugin\Fssync\Sync;

use GlpiPlugin\Fssync\Api\ApiException;
use GlpiPlugin\Fssync\Api\Catalog;
use GlpiPlugin\Fssync\Api\ClientFactory;
use GlpiPlugin\Fssync\Api\FreshserviceClient;
use GlpiPlugin\Fssync\Api\NotFoundException;
use GlpiPlugin\Fssync\Api\ValidationException;
use GlpiPlugin\Fssync\BlockedException;
use GlpiPlugin\Fssync\Config;
use GlpiPlugin\Fssync\Link;
use GlpiPlugin\Fssync\Log;
use GlpiPlugin\Fssync\Mapping;
use GlpiPlugin\Fssync\Mapping\ComputerSnapshot;
use GlpiPlugin\Fssync\Mapping\ComputerUser;
use GlpiPlugin\Fssync\Mapping\Field;
use GlpiPlugin\Fssync\Mapping\MappingCheck;
use GlpiPlugin\Fssync\Mapping\MappingException;
use GlpiPlugin\Fssync\Mapping\PayloadBuilder;
use GlpiPlugin\Fssync\Mapping\PayloadHasher;
use GlpiPlugin\Fssync\Mapping\Settings;
use GlpiPlugin\Fssync\Mapping\SnapshotLoader;
use GlpiPlugin\Fssync\Mapping\UpdatePlan;
use GlpiPlugin\Fssync\Mapping\UserIdRule;
use GlpiPlugin\Fssync\UserCache;
use UserEmail;

/**
 * Sincroniza UM computador com o Freshservice. Usado pela fila (cron) e, na
 * Fase 4, pelas telas ("Sincronizar agora" e página de teste).
 *
 * Erros saem como exceção, e quem chama decide o que fazer:
 *  - BlockedException / AuthException: precisa de ação humana;
 *  - RateLimitException: esperar o Retry-After;
 *  - demais ApiException: tentar de novo mais tarde.
 */
final class SyncService
{
    public function __construct(
        private readonly FreshserviceClient $client,
        private readonly UserResolver $users,
        private readonly Catalog $catalog,
        private readonly Settings $settings,
        private readonly string $env,
        private readonly bool $dryRun,
        private readonly string $source,
        /** Campos do modo "só atualizar" (UpdatePlan::FIELDS); null no modo completo. */
        private readonly ?array $updateFields = null,
    ) {}

    /**
     * Monta o serviço com a configuração atual do plugin.
     *
     * @throws BlockedException quando o ambiente ativo não tem domínio ou API key
     */
    public static function fromConfig(string $source): self
    {
        /** @var \Psr\SimpleCache\CacheInterface $GLPI_CACHE */
        global $GLPI_CACHE;

        $env    = Config::activeEnv();
        $client = ClientFactory::forEnv($env);

        return new self(
            $client,
            new UserResolver($client, new UserCache(), $env),
            new Catalog($client, $GLPI_CACHE, $env),
            Mapping::settings(),
            $env,
            Config::isDryRun(),
            $source,
            Config::isUpdateOnly() ? Config::updateFields() : null,
        );
    }

    /**
     * Cria ou atualiza o asset do computador. Um computador na lixeira ou
     * purgado é tratado como aposentadoria. No modo "só atualizar", só
     * atualiza um asset que já existe, e a lixeira não muda nada.
     *
     * @param bool $force envia mesmo que nada tenha mudado desde o último envio (ações manuais)
     */
    public function sync(int $computerId, bool $force = false): SyncResult
    {
        return $this->logged($computerId, function () use ($computerId, $force): SyncResult {
            $computer = SnapshotLoader::load($computerId);
            if ($this->updateFields !== null) {
                return $computer === null || $computer->isDeleted
                    ? self::removedInUpdateMode()
                    : $this->doUpdate($computer, allowRelink: true, force: $force);
            }
            if ($computer === null || $computer->isDeleted) {
                return $this->doRetire($computerId, purged: $computer === null);
            }

            return $this->doSync($computer, allowRelink: true, force: $force);
        });
    }

    /**
     * O usuário do computador e o e-mail com que ele é procurado: o nome
     * alternativo pelo de-para de domínio ou, sem ele, o Usuário do GLPI (D-45).
     */
    public static function computerUser(ComputerSnapshot $computer, Settings $settings): ComputerUser
    {
        return ComputerUser::of($computer, $settings->userDomains, static fn(int $usersId): string => (string) UserEmail::getDefaultForUser($usersId));
    }

    /**
     * A última chamada HTTP feita, para exibir na página de teste. Nunca contém a API key.
     *
     * @return ?array{method: string, url: string, request: ?array, status: int, response: mixed, duration_ms: int}
     */
    public function lastExchange(): ?array
    {
        return $this->client->lastExchange();
    }

    public function rateLimitRemaining(): ?int
    {
        return $this->client->rateLimitRemaining();
    }

    /**
     * O computador saiu do inventário (lixeira ou purge): muda o estado do
     * asset ou, se a política for exclusão real, exclui.
     */
    public function retire(int $computerId): SyncResult
    {
        return $this->logged($computerId, function () use ($computerId): SyncResult {
            $computer = SnapshotLoader::load($computerId);
            if ($this->updateFields !== null) {
                // Item enfileirado antes da troca de modo, ou computador já restaurado.
                return $computer === null || $computer->isDeleted
                    ? self::removedInUpdateMode()
                    : $this->doUpdate($computer, allowRelink: true, force: false);
            }
            if ($computer !== null && !$computer->isDeleted) {
                // Foi restaurado antes de a fila processar a remoção.
                return $this->doSync($computer, allowRelink: true, force: false);
            }

            return $this->doRetire($computerId, purged: $computer === null);
        });
    }

    // ----------------------------------------------------------------- sync

    /**
     * @param bool $allowRestore false depois de restaurar um asset da lixeira, para não repetir (D-47)
     */
    private function doSync(ComputerSnapshot $computer, bool $allowRelink, bool $force, bool $allowRestore = true): SyncResult
    {
        [$settings, $defaulted] = $this->effectiveSettings($computer);
        $payload = PayloadBuilder::build($computer, $settings);
        $hash    = PayloadHasher::hash($payload, $settings->revision);
        [$fsUserId, $userNote, $keepUser] = $this->resolveUser($computer);
        $userNote .= $defaulted === null ? '' : ' ' . $defaulted;

        $link = Link::forComputer($computer->id, $this->env);
        if ($keepUser) {
            // Usuário não resolvido: o "Usado por" fica como está, e o asset novo vai sem ele (D-46).
            $fsUserId = $link['last_fs_user_id'] ?? null;
        }
        if (!$force && $link !== null && $link['payload_hash'] === $hash && !UserIdRule::mustSend($fsUserId, $link['last_fs_user_id'], false)) {
            return new SyncResult(Log::OP_SKIP, __('Nothing changed since the last sync.', 'fssync'), $link['fs_display_id']);
        }

        $operation = Log::OP_UPDATE;
        $displayId = $link['fs_display_id'] ?? null;
        $assetId   = $link['fs_asset_id'] ?? null;
        $asset     = null;
        if ($link === null) {
            $found = $this->client->findAssetsBySerial($computer->serial);
            if (count($found) > 1) {
                throw self::duplicateSerial($computer->serial, $found);
            }
            $operation = $found === [] ? Log::OP_CREATE : Log::OP_LINK;
            $displayId = $found[0]['display_id'] ?? null;
            $assetId   = $found[0]['id'] ?? null;
            $asset     = $found[0] ?? null;
        }

        $firstSync = $link === null;
        $sendUser  = !$keepUser && UserIdRule::mustSend($fsUserId, $link['last_fs_user_id'] ?? null, $firstSync);
        $body      = $payload + ($sendUser ? ['user_id' => $fsUserId] : []);
        if ($operation === Log::OP_CREATE && Config::workspaceId() !== null) {
            $body['workspace_id'] = Config::workspaceId();
        }
        if ($operation !== Log::OP_CREATE) {
            if ($defaulted !== null) {
                // O padrão vale só para criar: um asset que já existe mantém o tipo e o produto dele (D-43).
                unset($body['asset_type_id'], $body['type_fields'][$settings->fields[$payload['asset_type_id']][Field::PRODUCT]['name'] ?? '']);
            }
            if ($sendUser) {
                // O "Usado por" precisa pertencer ao departamento do asset (D-41, D-44).
                try {
                    $asset ??= $this->client->getAsset((int) $displayId);
                } catch (NotFoundException) {
                    // O asset vinculado sumiu: o PUT abaixo recebe o 404 e refaz o vínculo pelo serial.
                    $asset = null;
                }
                if ($asset !== null && UpdatePlan::needsDepartments($asset, $fsUserId)) {
                    $body += UpdatePlan::departmentFor($asset, $fsUserId, $this->users->departmentsOf((int) $fsUserId));
                }
            }
        }

        if ($this->dryRun) {
            $this->log(Log::OP_DRY_RUN, $computer->id, self::dryRunMessage($operation, $displayId) . $userNote, payload: $body);

            return new SyncResult(Log::OP_DRY_RUN, self::dryRunMessage($operation, $displayId), $displayId);
        }

        if ($operation === Log::OP_CREATE) {
            try {
                $asset = $this->client->createAsset($body);
            } catch (ValidationException $e) {
                if (!$allowRestore || !$e->isNotUnique('serial_number')) {
                    throw $e;
                }

                return $this->restoreFromTrash($computer, $e, $force);
            }
            $displayId = (int) $asset['display_id'];
            $assetId   = (int) $asset['id'];
            $message   = sprintf(__('Asset #%d created.', 'fssync'), $displayId);
        } else {
            try {
                $this->client->updateAsset((int) $displayId, $body);
            } catch (NotFoundException $e) {
                if ($link === null || !$allowRelink) {
                    throw $e;
                }
                // O asset vinculado sumiu do Freshservice: desfaz o vínculo e procura de novo pelo serial.
                $this->log(Log::OP_ERROR, $computer->id, sprintf(__('Linked asset #%d no longer exists; searching again by serial number.', 'fssync'), $displayId), true);
                Link::forget($computer->id, $this->env);

                return $this->doSync($computer, allowRelink: false, force: $force);
            }
            $message = $operation === Log::OP_LINK
                ? sprintf(__('Existing asset #%d found by serial number, linked and updated.', 'fssync'), $displayId)
                : sprintf(__('Asset #%d updated.', 'fssync'), $displayId);
        }

        Link::store(
            $computer->id,
            $this->env,
            (int) $assetId,
            (int) $displayId,
            $hash,
            $sendUser ? $fsUserId : ($link['last_fs_user_id'] ?? null)
        );
        $this->log($operation, $computer->id, $message . $userNote, true);

        return new SyncResult($operation, $message, (int) $displayId, wrote: true);
    }

    /**
     * O de-para efetivo do computador, antes de montar o corpo: o do tipo dele,
     * ou o tipo e produto padrão (D-43). Sem padrão, um tipo ou produto que não
     * existe no Freshservice bloqueia, porque é a causa de qualquer outro erro do
     * de-para (os campos são por tipo, D-35).
     *
     * @return array{Settings, ?string} o Settings efetivo e, se o padrão foi usado, o aviso
     *
     * @throws MappingException
     */
    private function effectiveSettings(ComputerSnapshot $computer): array
    {
        $assetTypes = $this->catalog->assetTypes();
        $products   = $this->catalog->products();
        $resolved   = MappingCheck::resolve($this->settings, $computer->typeId, $assetTypes, $products);
        if ($resolved['defaulted'] === null && isset($this->settings->types[$computer->typeId])) {
            $missing = MappingCheck::missing($this->settings, $computer->typeId, $assetTypes, $products);
            if ($missing !== []) {
                throw new MappingException(MappingCheck::message($computer->typeId, $missing));
            }
        }

        return [$resolved['settings'], $resolved['defaulted']];
    }

    /**
     * @return array{?int, string, bool} ID do usuário no Freshservice (null = sem usuário), observação
     *                                   para o log e se o "Usado por" do asset deve ficar como está (D-46)
     */
    private function resolveUser(ComputerSnapshot $computer): array
    {
        $user       = self::computerUser($computer, $this->settings);
        $resolution = $this->users->resolve($user);
        if (!$resolution->hasUser) {
            return [null, '', false];
        }
        if ($resolution->isFound()) {
            return [$resolution->fsUserId, '', false];
        }

        $who = $resolution->reason($user->problem);

        return match (Config::userPolicy()) {
            Config::USER_POLICY_DEFAULT => [
                Config::defaultFsUserId(),
                ' ' . sprintf(__('Warning: %1$s; default user #%2$d used instead.', 'fssync'), $who, Config::defaultFsUserId()),
                false,
            ],
            Config::USER_POLICY_SKIP => [null, ' ' . sprintf(__('Warning: %s; "Used by" was not changed.', 'fssync'), $who), true],
            default                  => throw new BlockedException(sprintf(__('Computer user cannot be resolved: %s.', 'fssync'), $who)),
        };
    }

    private static function dryRunMessage(string $operation, ?int $displayId): string
    {
        return match ($operation) {
            Log::OP_CREATE => __('Dry-run: would create a new asset.', 'fssync'),
            Log::OP_LINK   => sprintf(__('Dry-run: would link and update existing asset #%d.', 'fssync'), $displayId),
            Log::OP_RETIRE => sprintf(__('Dry-run: would retire asset #%d.', 'fssync'), $displayId),
            Log::OP_DELETE => sprintf(__('Dry-run: would delete asset #%d.', 'fssync'), $displayId),
            default        => sprintf(__('Dry-run: would update asset #%d.', 'fssync'), $displayId),
        };
    }

    // -------------------------------------------------------- só atualizar

    /**
     * Modo "só atualizar" (D-36): atualiza os campos escolhidos de um asset
     * que já existe. Sem asset, registra e segue (D-39); nunca cria.
     */
    private function doUpdate(ComputerSnapshot $computer, bool $allowRelink, bool $force): SyncResult
    {
        $fields = $this->updateFields ?? [];
        if ($fields === []) {
            return new SyncResult(Log::OP_SKIP, __('No field is selected for update.', 'fssync'));
        }

        $hash = UpdatePlan::hash($fields, UpdatePlan::stateValue($computer, $this->settings), self::computerUser($computer, $this->settings)->key(), $this->settings->revision);

        $link = Link::forComputer($computer->id, $this->env);
        if (!$force && $link !== null && $link['payload_hash'] === $hash) {
            return new SyncResult(Log::OP_SKIP, __('Nothing changed since the last sync.', 'fssync'), $link['fs_display_id']);
        }

        $asset = null;
        if ($link !== null) {
            try {
                $asset = $this->client->getAsset((int) $link['fs_display_id']);
            } catch (NotFoundException $e) {
                if (!$allowRelink) {
                    throw $e;
                }
                // O asset vinculado sumiu do Freshservice: desfaz o vínculo e procura de novo pelo serial.
                $this->log(Log::OP_ERROR, $computer->id, sprintf(__('Linked asset #%d no longer exists; searching again by serial number.', 'fssync'), $link['fs_display_id']), true);
                Link::forget($computer->id, $this->env);
                $link = null;
            }
        }
        if ($asset === null) {
            $found = trim($computer->serial) === '' ? [] : $this->client->findAssetsBySerial($computer->serial);
            if (count($found) > 1) {
                throw self::duplicateSerial($computer->serial, $found);
            }
            if ($found === []) {
                return $this->noAsset($computer);
            }
            $asset = $found[0];
        }
        $displayId = (int) $asset['display_id'];

        // Depois de achar o asset: um computador sem asset não deve ficar bloqueado por causa do usuário.
        [$fsUserId, $userNote, $keepUser] = in_array(UpdatePlan::USER, $fields, true) ? $this->resolveUser($computer) : [null, '', false];
        if ($keepUser) {
            // Usuário não resolvido: o "Usado por" fica como está (D-46). Sem
            // hash, o próximo inventário tenta de novo, para o caso de a pessoa
            // ser cadastrada no Freshservice.
            $fields = array_values(array_diff($fields, [UpdatePlan::USER]));
            $hash   = null;
        }
        $stateField = in_array(UpdatePlan::STATE, $fields, true)
            ? $this->catalog->stateField((int) ($asset['asset_type_id'] ?? 0), $this->settings)
            : null;
        $departments = in_array(UpdatePlan::USER, $fields, true) && UpdatePlan::needsDepartments($asset, $fsUserId) ? $this->users->departmentsOf((int) $fsUserId) : null;
        $plan        = UpdatePlan::build($computer, $this->settings, $fields, $asset, $stateField, $fsUserId, $link['last_fs_user_id'] ?? null, $departments);
        $warnings    = $plan['warnings'] === [] ? '' : ' ' . implode(' ', $plan['warnings']);
        // O "Usado por" que o asset terá depois deste envio; serve para saber, no futuro, se o plugin pode limpá-lo.
        $lastUser    = in_array(UpdatePlan::USER, $fields, true) ? $fsUserId : ($link['last_fs_user_id'] ?? null);

        if ($plan['body'] === []) {
            if ($plan['warnings'] !== []) {
                // Nada a enviar e algo a corrigir (um de-para, por exemplo): precisa de ação humana.
                throw new BlockedException(implode(' ', $plan['warnings']));
            }
            Link::store($computer->id, $this->env, (int) $asset['id'], $displayId, $hash, $lastUser);

            return new SyncResult(Log::OP_SKIP, sprintf(__('Asset #%d is already up to date.', 'fssync'), $displayId) . $userNote, $displayId);
        }

        $changed = self::changedFields($plan['body']);
        if ($this->dryRun) {
            $message = sprintf(__('Dry-run: would update %1$s on asset #%2$d.', 'fssync'), $changed, $displayId) . $userNote . $warnings;
            $this->log(Log::OP_DRY_RUN, $computer->id, $message, payload: $plan['body']);

            return new SyncResult(Log::OP_DRY_RUN, $message, $displayId);
        }

        $this->client->updateAsset($displayId, $plan['body']);
        Link::store($computer->id, $this->env, (int) $asset['id'], $displayId, $hash, $lastUser);
        $message = sprintf(__('%1$s updated on asset #%2$d.', 'fssync'), $changed, $displayId) . $userNote . $warnings;
        $this->log(Log::OP_UPDATE, $computer->id, $message, true);

        return new SyncResult(Log::OP_UPDATE, $message, $displayId, wrote: true);
    }

    /** Sem asset para atualizar: registra uma vez e segue, sem erro (D-39). */
    private function noAsset(ComputerSnapshot $computer): SyncResult
    {
        $message = trim($computer->serial) === ''
            ? __('The computer has no serial number, so no Freshservice asset can be found; nothing was updated.', 'fssync')
            : sprintf(__('No Freshservice asset has serial number "%s"; nothing was updated.', 'fssync'), $computer->serial);
        // Cada inventário reenfileira o computador: sem isto, o log teria a mesma linha todo dia.
        if (Log::lastOperation($computer->id, $this->env) !== Log::OP_NO_ASSET) {
            $this->log(Log::OP_NO_ASSET, $computer->id, $message, true);
        }

        return new SyncResult(Log::OP_NO_ASSET, $message);
    }

    /** No modo "só atualizar", a lixeira e o purge não mudam nada no Freshservice (D-40). */
    private static function removedInUpdateMode(): SyncResult
    {
        return new SyncResult(Log::OP_SKIP, __('Update-only mode: removing a computer in GLPI does not change Freshservice.', 'fssync'));
    }

    /**
     * @param array<string, mixed> $body
     */
    private static function changedFields(array $body): string
    {
        $names = [];
        if (array_key_exists('user_id', $body)) {
            $names[] = __('Used by', 'fssync');
        }
        if (array_key_exists('department_id', $body)) {
            $names[] = __('Department', 'fssync');
        }
        if (isset($body['type_fields'])) {
            $names[] = __('State', 'fssync');
        }

        return implode(', ', $names);
    }

    /**
     * @param list<array<string, mixed>> $found
     */
    /**
     * O Freshservice recusou criar porque o serial já está num asset que a busca
     * não vê. Se ele estiver na lixeira, é restaurado, e a sincronização segue
     * como vínculo pelo serial: o asset é atualizado com os dados do GLPI (D-47).
     */
    private function restoreFromTrash(ComputerSnapshot $computer, ValidationException $refused, bool $force): SyncResult
    {
        $trashed = $this->client->findTrashedAssetsBySerial($computer->serial);
        if (count($trashed) > 1) {
            throw self::duplicateSerial($computer->serial, $trashed);
        }
        if ($trashed === []) {
            throw new BlockedException(sprintf(
                __('Freshservice already has an asset with serial number "%s", but the API key cannot find it, not even in the trash (it may be in another workspace). Fix it in Freshservice and reprocess the computer.', 'fssync'),
                $computer->serial
            ), 0, $refused);
        }

        $displayId = (int) $trashed[0]['display_id'];
        $this->client->restoreAsset($displayId);
        $this->log(Log::OP_LINK, $computer->id, sprintf(__('Asset #%d with the same serial number was in the Freshservice trash and was restored.', 'fssync'), $displayId), true);

        return $this->doSync($computer, allowRelink: false, force: $force, allowRestore: false);
    }

    private static function duplicateSerial(string $serial, array $found): BlockedException
    {
        return new BlockedException(sprintf(
            __('Serial number "%1$s" is on more than one Freshservice asset (%2$s). Link the right one manually.', 'fssync'),
            $serial,
            implode(', ', array_map(static fn(array $asset): string => '#' . $asset['display_id'], $found))
        ));
    }

    // --------------------------------------------------------------- retire

    private function doRetire(int $computerId, bool $purged): SyncResult
    {
        $link = Link::forComputer($computerId, $this->env);
        if ($link === null) {
            return new SyncResult(Log::OP_SKIP, __('The computer has no linked asset; nothing to retire.', 'fssync'));
        }
        $displayId = $link['fs_display_id'];
        $delete    = Config::get('delete_policy') === Config::DELETE_POLICY_DELETE;

        if ($this->dryRun) {
            $message = self::dryRunMessage($delete ? Log::OP_DELETE : Log::OP_RETIRE, $displayId);
            $this->log(Log::OP_DRY_RUN, $computerId, $message);

            return new SyncResult(Log::OP_DRY_RUN, $message, $displayId);
        }

        try {
            if ($delete) {
                $this->client->deleteAsset($displayId);
                $operation = Log::OP_DELETE;
                $message   = sprintf(__('Asset #%d deleted.', 'fssync'), $displayId);
            } else {
                $state     = Config::get('retired_state');
                $asset     = $this->client->getAsset($displayId);
                $field     = $this->settings->fields[(int) ($asset['asset_type_id'] ?? 0)][Field::STATE]['name'] ?? null;
                if ($field === null) {
                    throw new BlockedException(sprintf(
                        __('The asset state field is not mapped for Freshservice asset type #%d, so asset #%d cannot be retired.', 'fssync'),
                        $asset['asset_type_id'] ?? 0,
                        $displayId
                    ));
                }
                $this->client->updateAsset($displayId, ['type_fields' => [$field => $state]]);
                $operation = Log::OP_RETIRE;
                $message   = sprintf(__('Asset #%1$d state changed to "%2$s".', 'fssync'), $displayId, $state);
            }
        } catch (NotFoundException) {
            Link::forget($computerId, $this->env);
            $message = sprintf(__('Linked asset #%d no longer exists in Freshservice; link removed.', 'fssync'), $displayId);
            $this->log(Log::OP_SKIP, $computerId, $message, true);

            return new SyncResult(Log::OP_SKIP, $message);
        }

        if ($purged || $delete) {
            Link::forget($computerId, $this->env);
        } else {
            // Na lixeira o computador pode ser restaurado: mantém o vínculo, mas zera
            // o hash para a restauração reenviar tudo (inclusive o estado).
            Link::store($computerId, $this->env, $link['fs_asset_id'], $displayId, null, $link['last_fs_user_id']);
        }
        $this->log($operation, $computerId, $message, true);

        return new SyncResult($operation, $message, $displayId, wrote: true);
    }

    // ------------------------------------------------------------------ log

    /**
     * Registra a falha no log antes de repassá-la a quem chamou.
     *
     * @param callable(): SyncResult $work
     */
    private function logged(int $computerId, callable $work): SyncResult
    {
        try {
            return $work();
        } catch (BlockedException $e) {
            $this->log(Log::OP_BLOCKED, $computerId, $e->getMessage(), $e->getPrevious() instanceof ApiException);
            throw $e;
        } catch (ApiException $e) {
            $this->log(Log::OP_ERROR, $computerId, $e->getMessage(), true);
            throw $e;
        }
    }

    /**
     * @param bool   $withExchange anexa a última chamada HTTP (método, URL, corpo e resposta)
     * @param ?array $payload      corpo montado, quando nenhuma chamada foi feita (dry-run)
     */
    private function log(string $operation, int $computerId, string $message, bool $withExchange = false, ?array $payload = null): void
    {
        Log::write($operation, $computerId, $this->env, $this->source, $message, $withExchange ? $this->client->lastExchange() : null, $payload);
    }
}
