<?php

namespace GlpiPlugin\Fssync\Sync;

/**
 * Resultado da busca do usuário de um computador no Freshservice.
 */
final readonly class UserResolution
{
    public const KIND_REQUESTER = 'requester';
    public const KIND_AGENT     = 'agent';
    public const KIND_NONE      = 'none';
    /** Não encontrado porque o Freshservice recusou o e-mail como inválido (D-46). */
    public const KIND_INVALID   = 'invalid';

    /**
     * @param bool   $hasUser   false quando o computador não tem usuário no GLPI
     * @param ?int   $fsUserId  ID no Freshservice; null quando não foi encontrado
     * @param string $kind      KIND_*: onde foi encontrado, ou por que não foi
     * @param string $email     e-mail usado na busca (vazio se o usuário não tem e-mail)
     * @param string $name      nome no Freshservice, para exibir
     */
    private function __construct(
        public bool $hasUser,
        public ?int $fsUserId,
        public string $kind,
        public string $email,
        public string $name,
    ) {}

    public static function noUser(): self
    {
        return new self(false, null, self::KIND_NONE, '', '');
    }

    public static function found(int $fsUserId, string $kind, string $email, string $name): self
    {
        return new self(true, $fsUserId, $kind, $email, $name);
    }

    public static function notFound(string $email): self
    {
        return new self(true, null, self::KIND_NONE, $email, '');
    }

    public static function invalidEmail(string $email): self
    {
        return new self(true, null, self::KIND_INVALID, $email, '');
    }

    public function isFound(): bool
    {
        return $this->fsUserId !== null;
    }

    /**
     * Por que o usuário não foi resolvido, para o log e a página de teste.
     *
     * @param string $problem o motivo dado pelo ComputerUser quando não há e-mail
     */
    public function reason(string $problem): string
    {
        return match (true) {
            $this->email === ''                  => $problem,
            $this->kind === self::KIND_INVALID   => sprintf(__('the e-mail "%s" was refused by Freshservice as invalid', 'fssync'), $this->email),
            default                              => sprintf(__('user "%s" was not found in Freshservice (requesters or agents)', 'fssync'), $this->email),
        };
    }
}
