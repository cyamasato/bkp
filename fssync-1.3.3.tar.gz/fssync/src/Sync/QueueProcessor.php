<?php

namespace GlpiPlugin\Fssync\Sync;

use GlpiPlugin\Fssync\Api\AuthException;
use GlpiPlugin\Fssync\Api\RateLimitException;
use GlpiPlugin\Fssync\BlockedException;
use GlpiPlugin\Fssync\Config;
use GlpiPlugin\Fssync\Log;
use GlpiPlugin\Fssync\Queue;
use Throwable;
use Toolbox;

/**
 * Processa um lote da fila de sincronização.
 */
final class QueueProcessor
{
    /**
     * @return array{processed: int, wrote: int, blocked: int, failed: int, note: string}
     *         `processed` conta os itens tirados da fila com sucesso; `note` explica um lote vazio ou interrompido
     */
    public static function run(?int $limit = null): array
    {
        $summary = ['processed' => 0, 'wrote' => 0, 'blocked' => 0, 'failed' => 0, 'note' => ''];

        $pausedUntil = Config::get('paused_until');
        if ($pausedUntil !== '' && strtotime($pausedUntil) > time()) {
            $summary['note'] = sprintf(__('Queue paused until %s after a rate limit response.', 'fssync'), $pausedUntil);

            return $summary;
        }

        Queue::releaseStale();

        $service     = null;
        $maxAttempts = max(1, Config::int('max_attempts'));
        $limit     ??= max(1, Config::int('batch_size'));

        for ($i = 0; $i < $limit; $i++) {
            $item = Queue::claimNext();
            if ($item === null) {
                break;
            }

            if ($service === null) {
                try {
                    // Só monta o serviço (e lê a API key) quando há algo a processar.
                    $service = SyncService::fromConfig(Log::SOURCE_CRON);
                } catch (BlockedException $e) {
                    // Falta domínio ou API key: o problema é da configuração, não deste item.
                    Queue::release($item['id'], 0);
                    $summary['note'] = $e->getMessage();
                    break;
                }
            }

            try {
                $result = $item['action'] === Queue::ACTION_RETIRE
                    ? $service->retire($item['computers_id'])
                    : $service->sync($item['computers_id']);

                Queue::complete($item['id']);
                $summary['processed']++;
                $summary['wrote'] += $result->wrote ? 1 : 0;
            } catch (RateLimitException $e) {
                // Não é culpa do item: volta para a fila sem contar tentativa, e o lote para aqui.
                Queue::release($item['id'], $e->retryAfter);
                $until = date('Y-m-d H:i:s', time() + $e->retryAfter);
                Config::set(['paused_until' => $until]);
                $summary['note'] = sprintf(__('Rate limit reached; queue paused until %s.', 'fssync'), $until);
                break;
            } catch (BlockedException | AuthException $e) {
                Queue::block($item['id'], $e->getMessage());
                $summary['blocked']++;
            } catch (Throwable $e) {
                Queue::retry($item['id'], $item['attempts'], $e->getMessage(), $maxAttempts);
                $summary['failed']++;
                Toolbox::logInFile('fssync', sprintf("Computador #%d: %s\n", $item['computers_id'], $e->getMessage()));
            }
        }

        return $summary;
    }
}
