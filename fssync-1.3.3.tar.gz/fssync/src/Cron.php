<?php

namespace GlpiPlugin\Fssync;

use CronTask;
use GlpiPlugin\Fssync\Sync\QueueProcessor;

/**
 * Ação automática que processa a fila de sincronização.
 */
final class Cron
{
    public const TASK      = 'ProcessQueue';
    public const FREQUENCY = 5 * MINUTE_TIMESTAMP;

    /**
     * @return array{description: string}
     */
    public static function cronInfo(string $name): array
    {
        return ['description' => __('Send queued computers to Freshservice', 'fssync')];
    }

    /**
     * @return int 0 = nada a fazer; > 0 = processou; < 0 = processou em parte
     */
    public static function cronProcessQueue(CronTask $task): int
    {
        $summary = QueueProcessor::run();

        $task->addVolume($summary['processed']);
        $task->log(self::describe($summary));

        if ($summary['blocked'] + $summary['failed'] > 0 || ($summary['note'] !== '' && $summary['processed'] > 0)) {
            return -1;
        }

        return $summary['processed'] > 0 ? 1 : 0;
    }

    /**
     * @param array{processed: int, wrote: int, blocked: int, failed: int, note: string} $summary
     */
    public static function describe(array $summary): string
    {
        $text = sprintf(
            __('%1$d processed (%2$d sent to Freshservice), %3$d blocked, %4$d with error.', 'fssync'),
            $summary['processed'],
            $summary['wrote'],
            $summary['blocked'],
            $summary['failed']
        );

        return trim($text . ' ' . $summary['note']);
    }
}
