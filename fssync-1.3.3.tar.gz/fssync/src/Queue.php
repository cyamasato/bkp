<?php

namespace GlpiPlugin\Fssync;

use CommonDBTM;
use DBmysql;

/**
 * Fila de sincronização: no máximo uma linha por computador.
 *
 * Um evento novo sempre devolve a linha ao estado "pendente". É isso que impede
 * perder um evento que chega enquanto o computador está sendo processado: o
 * processador só conclui a linha se ela ainda estiver "em processamento".
 */
class Queue extends CommonDBTM
{
    public const ACTION_SYNC   = 'sync';
    /** O computador foi para a lixeira ou foi purgado. */
    public const ACTION_RETIRE = 'retire';

    public const STATUS_PENDING    = 'pending';
    public const STATUS_PROCESSING = 'processing';
    /** Precisa de ação humana; não é tentado de novo sozinho. */
    public const STATUS_BLOCKED    = 'blocked';
    /** Esgotou as tentativas. */
    public const STATUS_FAILED     = 'failed';

    /** Primeira espera do backoff; dobra a cada tentativa, até o teto. */
    public const BACKOFF_BASE_SECONDS = 300;
    public const BACKOFF_MAX_SECONDS  = 6 * 3600;

    /** Uma linha "em processamento" há mais tempo que isto ficou órfã (o processo morreu). */
    private const STALE_PROCESSING_SECONDS = 900;

    public static $rightname = Rights::NAME;

    public static function getTypeName($nb = 0)
    {
        return _n('Queue item', 'Queue items', $nb, 'fssync');
    }

    /**
     * Coloca o computador na fila ou, se ele já está nela, reinicia a linha.
     */
    public static function enqueue(int $computerId, string $action = self::ACTION_SYNC): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $now = self::now();
        // Uma única instrução atômica: dois eventos simultâneos do mesmo computador
        // não podem gerar erro de chave duplicada. Só entram inteiros e constantes.
        $DB->doQuery(sprintf(
            'INSERT INTO %1$s (computers_id, action, status, attempts, next_attempt_at, last_error, date_creation, date_mod)
             VALUES (%2$d, %3$s, %4$s, 0, NULL, NULL, %5$s, %5$s)
             ON DUPLICATE KEY UPDATE action = VALUES(action), status = VALUES(status), attempts = 0,
                                     next_attempt_at = NULL, last_error = NULL, date_mod = VALUES(date_mod)',
            $DB::quoteName(self::getTable()),
            $computerId,
            $DB::quoteValue($action === self::ACTION_RETIRE ? self::ACTION_RETIRE : self::ACTION_SYNC),
            $DB::quoteValue(self::STATUS_PENDING),
            $DB::quoteValue($now)
        ));
    }

    /**
     * Reserva o próximo item pronto para processar, do mais antigo para o mais novo.
     *
     * @return ?array{id: int, computers_id: int, action: string, attempts: int}
     */
    public static function claimNext(): ?array
    {
        /** @var DBmysql $DB */
        global $DB;

        $now  = self::now();
        $rows = $DB->request([
            'FROM'  => self::getTable(),
            'WHERE' => [
                'status' => self::STATUS_PENDING,
                'OR'     => [['next_attempt_at' => null], ['next_attempt_at' => ['<=', $now]]],
            ],
            'ORDER' => ['date_mod', 'id'],
            'LIMIT' => 5,
        ]);
        foreach ($rows as $row) {
            // Só reserva se ninguém mexeu na linha desde a leitura.
            $DB->update(
                self::getTable(),
                ['status' => self::STATUS_PROCESSING, 'date_mod' => $now],
                ['id' => $row['id'], 'status' => self::STATUS_PENDING]
            );
            if ($DB->affectedRows() === 1) {
                return [
                    'id'           => (int) $row['id'],
                    'computers_id' => (int) $row['computers_id'],
                    'action'       => (string) $row['action'],
                    'attempts'     => (int) $row['attempts'],
                ];
            }
        }

        return null;
    }

    /** Sucesso: sai da fila, a não ser que um evento novo tenha chegado durante o processamento. */
    public static function complete(int $id): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->delete(self::getTable(), ['id' => $id, 'status' => self::STATUS_PROCESSING]);
    }

    /** Devolve o item à fila sem contar tentativa (usado quando o lote é interrompido por 429). */
    public static function release(int $id, int $retryInSeconds): void
    {
        self::finish($id, ['status' => self::STATUS_PENDING, 'next_attempt_at' => self::now($retryInSeconds)]);
    }

    public static function block(int $id, string $error): void
    {
        self::finish($id, ['status' => self::STATUS_BLOCKED, 'last_error' => $error, 'next_attempt_at' => null]);
    }

    /**
     * Conta a tentativa e reagenda com backoff exponencial; esgotadas as tentativas, vira "falhou".
     */
    public static function retry(int $id, int $previousAttempts, string $error, int $maxAttempts): void
    {
        $attempts = $previousAttempts + 1;
        if ($attempts >= $maxAttempts) {
            self::finish($id, ['status' => self::STATUS_FAILED, 'attempts' => $attempts, 'last_error' => $error, 'next_attempt_at' => null]);

            return;
        }

        self::finish($id, [
            'status'          => self::STATUS_PENDING,
            'attempts'        => $attempts,
            'last_error'      => $error,
            'next_attempt_at' => self::now(self::backoffSeconds($attempts)),
        ]);
    }

    /** 5 min, 10 min, 20 min... até 6 horas. */
    public static function backoffSeconds(int $attempts): int
    {
        return (int) min(self::BACKOFF_BASE_SECONDS * 2 ** max(0, $attempts - 1), self::BACKOFF_MAX_SECONDS);
    }

    /** Itens bloqueados ou com falha voltam a ser processados (ex.: depois de corrigir a configuração). */
    public static function reopen(?int $computerId = null): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->update(
            self::getTable(),
            ['status' => self::STATUS_PENDING, 'attempts' => 0, 'next_attempt_at' => null, 'date_mod' => self::now()],
            ['status' => [self::STATUS_BLOCKED, self::STATUS_FAILED]] + ($computerId === null ? [] : ['computers_id' => $computerId])
        );
    }

    /** Tira o computador da fila (usado quando uma sincronização manual acabou de dar certo). */
    public static function forget(int $computerId): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->delete(self::getTable(), ['computers_id' => $computerId, 'status' => ['<>', self::STATUS_PROCESSING]]);
    }

    /**
     * Esvazia a fila, qualquer que seja o status (D-42). Se a ação automática
     * estiver no meio de um item, concluir ou reagendar só não encontra a linha.
     *
     * @return int quantos itens foram removidos
     */
    public static function clear(): int
    {
        /** @var DBmysql $DB */
        global $DB;

        $count = countElementsInTable(self::getTable());
        $DB->delete(self::getTable(), [1]);

        return $count;
    }

    /**
     * Carga inicial: enfileira todos os computadores das entidades sincronizadas.
     * O envio continua sendo feito aos poucos, no tamanho de lote da fila.
     *
     * @param list<int> $entities
     *
     * @return int quantos computadores foram enfileirados
     */
    public static function enqueueAll(array $entities): int
    {
        /** @var DBmysql $DB */
        global $DB;

        if ($entities === []) {
            return 0;
        }
        $count = 0;
        $rows  = $DB->request([
            'SELECT' => 'id',
            'FROM'   => 'glpi_computers',
            'WHERE'  => ['entities_id' => $entities, 'is_template' => 0, 'is_deleted' => 0],
        ]);
        foreach ($rows as $row) {
            self::enqueue((int) $row['id']);
            $count++;
        }

        return $count;
    }

    /**
     * Quantos itens pendentes serão processados antes deste (1 = o próximo).
     *
     * @param array{status: string, date_mod: string, id: int|string} $row linha da fila
     */
    public static function position(array $row): ?int
    {
        /** @var DBmysql $DB */
        global $DB;

        if ($row['status'] !== self::STATUS_PENDING) {
            return null;
        }

        return 1 + countElementsInTable(self::getTable(), [
            'status' => self::STATUS_PENDING,
            'OR'     => [
                ['date_mod' => ['<', $row['date_mod']]],
                ['date_mod' => $row['date_mod'], 'id' => ['<', $row['id']]],
            ],
        ]);
    }

    /** Recupera itens que ficaram "em processamento" porque o processo anterior morreu. */
    public static function releaseStale(): void
    {
        /** @var DBmysql $DB */
        global $DB;

        $DB->update(
            self::getTable(),
            ['status' => self::STATUS_PENDING],
            ['status' => self::STATUS_PROCESSING, 'date_mod' => ['<', self::now(-self::STALE_PROCESSING_SECONDS)]]
        );
    }

    /**
     * @param array<string, mixed> $values
     */
    private static function finish(int $id, array $values): void
    {
        /** @var DBmysql $DB */
        global $DB;

        // Se um evento novo já devolveu a linha a "pendente", ele prevalece.
        $DB->update(self::getTable(), $values + ['date_mod' => self::now()], ['id' => $id, 'status' => self::STATUS_PROCESSING]);
    }

    private static function now(int $offsetSeconds = 0): string
    {
        return date('Y-m-d H:i:s', time() + $offsetSeconds);
    }
}
