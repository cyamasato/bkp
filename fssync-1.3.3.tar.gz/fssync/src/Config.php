<?php

namespace GlpiPlugin\Fssync;

use GlpiPlugin\Fssync\Mapping\UpdatePlan;
use GLPIKey;

/**
 * Configuração escalar do plugin, guardada no Config do GLPI (contexto plugin:fssync).
 * Os de-paras ficam na tabela de Mapping.
 */
final class Config
{
    public const CONTEXT = 'plugin:fssync';

    public const ENV_PROD = 'prod';
    public const ENV_TEST = 'test';

    public const USER_POLICY_BLOCK   = 'block';
    public const USER_POLICY_DEFAULT = 'default_user';
    /** Envia o computador sem "Usado por"; um "Usado por" que o asset já tenha é mantido (D-46). */
    public const USER_POLICY_SKIP    = 'skip_user';

    public const DELETE_POLICY_STATE  = 'state';
    public const DELETE_POLICY_DELETE = 'delete';

    /** Só atualiza assets que já existem, e só os campos escolhidos (D-36). */
    public const MODE_UPDATE = 'update';
    /** Cria e atualiza o asset com todos os campos do mapeamento (o padrão). */
    public const MODE_FULL = 'full';

    /** Chaves que o GLPI criptografa com GLPIKey. */
    public const SECURED_KEYS = ['prod_api_key', 'test_api_key'];

    /**
     * Valores gravados na instalação para as chaves que ainda não existem.
     * Os padrões são os mais seguros: nada é sincronizado nem enviado até
     * alguém escolher as entidades e desligar o dry-run.
     */
    public const DEFAULTS = [
        'sync_mode'             => self::MODE_FULL,
        'update_fields'         => '["user","state"]',
        'default_asset_type_id' => '',
        'default_product_id'    => '',
        'active_env'            => self::ENV_TEST,
        'prod_domain'           => '',
        'prod_api_key'          => '',
        'test_domain'           => '',
        'test_api_key'          => '',
        'workspace_id'          => '',
        'dry_run'               => '1',
        'entities'              => '[]',
        'user_not_found_policy' => self::USER_POLICY_SKIP,
        'default_fs_user_id'    => '',
        'delete_policy'         => self::DELETE_POLICY_STATE,
        'retired_state'         => 'Retired',
        'description_template'  => '{modelo_comercial} {cpu} {memoria}GB {disco}GB SSD',
        'disk_round_commercial' => '1',
        'cpu_unit'              => 'mhz',
        'max_attempts'          => '8',
        'batch_size'            => '20',
        'paused_until'          => '',
        'config_revision'       => '1',
    ];

    /** Chaves que mudam o payload: alterá-las invalida os hashes já gravados. */
    private const PAYLOAD_KEYS = [
        'description_template', 'disk_round_commercial', 'cpu_unit', 'sync_mode', 'update_fields',
        'default_asset_type_id', 'default_product_id',
    ];

    /** @var ?array<string, string> leitura única por requisição (os hooks consultam a cada evento) */
    private static ?array $cache = null;

    public static function get(string $name): string
    {
        self::$cache ??= \Config::getConfigurationValues(self::CONTEXT);

        return (string) (self::$cache[$name] ?? self::DEFAULTS[$name]);
    }

    public static function int(string $name): int
    {
        return (int) self::get($name);
    }

    /**
     * @param array<string, string|int> $values
     */
    public static function set(array $values): void
    {
        $values = array_map(strval(...), $values);
        if (array_intersect(array_keys($values), self::PAYLOAD_KEYS) !== [] && !isset($values['config_revision'])) {
            $values['config_revision'] = (string) (self::int('config_revision') + 1);
        }
        \Config::setConfigurationValues(self::CONTEXT, $values);
        self::$cache = null;
    }

    /** Chamado quando um de-para muda, para os computadores serem reenviados. */
    public static function bumpRevision(): void
    {
        self::set(['config_revision' => self::int('config_revision') + 1]);
    }

    public static function activeEnv(): string
    {
        return self::get('active_env') === self::ENV_PROD ? self::ENV_PROD : self::ENV_TEST;
    }

    public static function isDryRun(): bool
    {
        return self::get('dry_run') !== '0';
    }

    public static function isUpdateOnly(): bool
    {
        return self::get('sync_mode') !== self::MODE_FULL;
    }

    /**
     * @return list<string> campos que o modo "só atualizar" envia, na ordem de UpdatePlan::FIELDS
     */
    public static function updateFields(): array
    {
        $decoded = json_decode(self::get('update_fields'), true);

        return array_values(array_intersect(UpdatePlan::FIELDS, is_array($decoded) ? $decoded : []));
    }

    public static function domain(string $env): string
    {
        return trim(self::get($env . '_domain'));
    }

    /** A API key decifrada. Nunca escreva o retorno em log ou em tela. */
    public static function apiKey(string $env): string
    {
        $stored = self::get($env . '_api_key');

        return $stored === '' ? '' : (string) (new GLPIKey())->decrypt($stored);
    }

    /**
     * @return list<int> entidades cujos computadores são sincronizados
     */
    public static function entities(): array
    {
        $decoded = json_decode(self::get('entities'), true);

        return is_array($decoded) ? array_values(array_map(intval(...), $decoded)) : [];
    }

    /** Endereço do asset na interface do Freshservice. */
    public static function assetUrl(string $env, int $displayId): string
    {
        $domain = self::domain($env);
        if ($domain === '') {
            return '';
        }
        $base = preg_match('#^https?://#i', $domain) ? $domain : 'https://' . $domain;
        $base = preg_replace('#/api/v2/?$#i', '', rtrim($base, '/'));

        return rtrim($base, '/') . '/cmdb/items/' . $displayId;
    }

    public static function hasApiKey(string $env): bool
    {
        return self::get($env . '_api_key') !== '';
    }

    public static function workspaceId(): ?int
    {
        return self::get('workspace_id') === '' ? null : self::int('workspace_id');
    }

    public static function defaultFsUserId(): ?int
    {
        return self::get('default_fs_user_id') === '' ? null : self::int('default_fs_user_id');
    }

    /**
     * A política para usuário não encontrado que vale de fato: "usuário padrão"
     * sem o ID do usuário padrão bloqueia.
     *
     * @return string USER_POLICY_*
     */
    public static function userPolicy(): string
    {
        $policy = self::get('user_not_found_policy');
        if ($policy === self::USER_POLICY_DEFAULT) {
            return self::defaultFsUserId() === null ? self::USER_POLICY_BLOCK : $policy;
        }

        return $policy === self::USER_POLICY_BLOCK ? $policy : self::USER_POLICY_SKIP;
    }
}
