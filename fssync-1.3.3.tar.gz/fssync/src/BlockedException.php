<?php

namespace GlpiPlugin\Fssync;

use RuntimeException;

/**
 * A sincronização não pode prosseguir sem ação humana (falta de de-para,
 * usuário não encontrado, permissão da API key...). Tentar de novo sozinho
 * não resolve: o item da fila fica bloqueado com esta mensagem.
 */
class BlockedException extends RuntimeException {}
