<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Converte um computador do GLPI no corpo que vai para o Freshservice.
 * PHP puro: não acessa banco nem rede.
 *
 * O `user_id` ("Usado por") não é montado aqui: depende de consulta ao
 * Freshservice e tem regra própria de envio (ver UserIdRule).
 */
final class PayloadBuilder
{
    public const STATUS_OK      = 'ok';
    /** O campo não será enviado (vazio ou não mapeado) ou o valor foi ajustado por uma regra. */
    public const STATUS_WARNING = 'warning';
    /** Impede a sincronização. */
    public const STATUS_ERROR   = 'error';

    /**
     * Um valor vazio no GLPI não é enviado: assim o plugin nunca apaga, no
     * Freshservice, um dado que o inventário simplesmente não trouxe.
     *
     * @return array{name: string, asset_type_id: int, description: string, type_fields: array<string, int|float|string>}
     *
     * @throws MappingException quando falta um dado ou de-para obrigatório
     */
    public static function build(ComputerSnapshot $computer, Settings $settings): array
    {
        $result = self::evaluate($computer, $settings);
        if ($result['error'] !== null) {
            throw new MappingException($result['error']);
        }

        return $result['payload'];
    }

    /**
     * O mesmo cálculo de build(), campo a campo, para a pré-visualização: de
     * onde veio cada valor e o que impede (ou não) o envio.
     *
     * @return array{
     *     rows: list<array{field: string, fs_name: string, value: int|float|string|null, origin: string, status: string, note: string}>,
     *     payload: ?array{name: string, asset_type_id: int, description: string, type_fields: array<string, int|float|string>},
     *     error: ?string
     * }
     */
    public static function explain(ComputerSnapshot $computer, Settings $settings): array
    {
        return self::evaluate($computer, $settings);
    }

    /**
     * @return array{rows: list<array<string, mixed>>, payload: ?array<string, mixed>, error: ?string}
     */
    private static function evaluate(ComputerSnapshot $computer, Settings $settings): array
    {
        $errors = [];
        $rows   = [];
        $add    = static function (string $field, string $fsName, mixed $value, string $origin, string $status = self::STATUS_OK, string $note = '') use (&$rows): void {
            $rows[] = ['field' => $field, 'fs_name' => $fsName, 'value' => $value, 'origin' => $origin, 'status' => $status, 'note' => $note];
        };

        $name   = trim($computer->name);
        $serial = trim($computer->serial);
        if ($name === '') {
            $errors['name'] = __('The computer has no name.', 'fssync');
        }
        if ($serial === '') {
            $errors['serial'] = __('The computer has no serial number, which is the deduplication key.', 'fssync');
        }

        $type = $settings->types[$computer->typeId] ?? null;
        if ($type === null) {
            $errors['type'] = sprintf(__('Computer type #%d has no Freshservice asset type mapping.', 'fssync'), $computer->typeId);
        }
        $assetTypeId = $type['asset_type_id'] ?? 0;
        $fields      = $settings->fields[$assetTypeId] ?? [];
        if ($type !== null && $type['product_id'] <= 0) {
            $errors[Field::PRODUCT] = sprintf(__('Computer type #%d has no Freshservice product mapping.', 'fssync'), $computer->typeId);
        }
        if ($type !== null) {
            foreach (Field::REQUIRED as $required) {
                if (!isset($fields[$required])) {
                    $errors['field_' . $required] = sprintf(
                        __('Field "%1$s" is not mapped for Freshservice asset type #%2$d.', 'fssync'),
                        $required,
                        $assetTypeId
                    );
                }
            }
        }

        $state = $settings->states[$computer->stateId] ?? null;
        if ($state === null) {
            $errors['state'] = sprintf(__('GLPI status #%d has no Freshservice asset state mapping.', 'fssync'), $computer->stateId);
        }

        $model    = $settings->models[$computer->model] ?? null;
        $alias    = $model['alias'] ?? $computer->model;
        $memoryGb = round($computer->memoryMb / 1024, 1);
        $rawDisk  = DiskRounding::totalGb($computer->diskMbs, false);
        $diskGb   = DiskRounding::totalGb($computer->diskMbs, $settings->roundDisk);

        $osChoices = $fields[Field::OS]['choices'] ?? null;
        $os        = $computer->os === '' ? '' : ($settings->os[$computer->os] ?? $computer->os);
        if ($os !== '' && isset($fields[Field::OS]) && $osChoices !== null && !in_array($os, $osChoices, true)) {
            $errors['os'] = sprintf(
                __('Operating system "%s" is not in the Freshservice list. Add an operating system mapping.', 'fssync'),
                $computer->os
            );
        }

        $description = DescriptionTemplate::render($settings->descriptionTemplate, [
            'nome'             => $computer->name,
            'serial'           => $computer->serial,
            'fabricante'       => $computer->manufacturer,
            'modelo'           => $alias,
            'modelo_comercial' => $model['commercial'] ?? $alias,
            'cpu'              => CpuName::short($computer->cpuName),
            'memoria'          => $memoryGb > 0 ? self::trimDecimal($memoryGb) : null,
            'disco'            => $diskGb > 0 ? $diskGb : null,
            'so'               => $os,
        ]);

        // ---- linhas da pré-visualização, na ordem em que aparecem no Freshservice
        $add('name', 'name', $name, 'Computer.name', isset($errors['name']) ? self::STATUS_ERROR : self::STATUS_OK, $errors['name'] ?? '');
        $add(
            'asset_type',
            'asset_type_id',
            $type === null ? null : $assetTypeId,
            sprintf('ComputerType #%d', $computer->typeId),
            $type === null ? self::STATUS_ERROR : self::STATUS_OK,
            $errors['type'] ?? ''
        );
        // A tag do ativo é o número de série, que é obrigatório e já identifica o computador (D-48).
        $add('asset_tag', 'asset_tag', $serial === '' ? null : $serial, 'Computer.serial', isset($errors['serial']) ? self::STATUS_ERROR : self::STATUS_OK, $errors['serial'] ?? '');
        $add('description', 'description', $description, $settings->descriptionTemplate);

        /** @var array<string, array{mixed, string, string}> $typeValues campo lógico => [valor, origem, nota] */
        $typeValues = [
            Field::PRODUCT      => [$type['product_id'] ?? null, sprintf('ComputerType #%d', $computer->typeId), ''],
            Field::STATE        => [$state, sprintf('State #%d', $computer->stateId), $errors['state'] ?? ''],
            Field::SERIAL       => [$serial, 'Computer.serial', $errors['serial'] ?? ''],
            Field::MANUFACTURER => [$computer->manufacturer, 'Manufacturer', ''],
            Field::MODEL        => [$alias, 'ComputerModel', $model === null ? '' : sprintf(__('Alias of "%s".', 'fssync'), $computer->model)],
            Field::OS           => [$os, 'Item_OperatingSystem', $errors['os'] ?? ($os !== $computer->os ? sprintf(__('Mapped from "%s".', 'fssync'), $computer->os) : '')],
            Field::MEMORY       => [$memoryGb, 'Item_DeviceMemory', ''],
            Field::DISK         => [$diskGb, 'Item_DeviceHardDrive', $diskGb !== $rawDisk ? sprintf(__('Rounded up from %d GB.', 'fssync'), $rawDisk) : ''],
            Field::CPU_SPEED    => [self::cpuSpeed($computer->cpuMhz, $settings->cpuUnit), 'Item_DeviceProcessor.frequency', ''],
            Field::CPU_CORES    => [$computer->cpuCores, 'Item_DeviceProcessor.nbcores', ''],
        ];

        $typeFields = [];
        foreach ($typeValues as $logical => [$value, $origin, $note]) {
            $mapped = isset($fields[$logical]);
            $empty  = $value === null || $value === '' || $value === 0 || $value === 0.0;
            $failed = isset($errors[$logical]) || isset($errors['field_' . $logical])
                || ($logical === Field::PRODUCT && $type === null);

            if ($failed) {
                $status = self::STATUS_ERROR;
                $note   = $errors['field_' . $logical] ?? $errors[$logical] ?? $errors['type'] ?? $note;
            } elseif (!$mapped) {
                $status = self::STATUS_WARNING;
                $note   = __('Field not mapped for this asset type; it will not be sent.', 'fssync');
            } elseif ($empty) {
                $status = self::STATUS_WARNING;
                $note   = __('Empty in GLPI; it will not be sent.', 'fssync');
            } else {
                $status = $note === '' ? self::STATUS_OK : self::STATUS_WARNING;
                $typeFields[$fields[$logical]['name']] = $value;
            }
            $add($logical, $fields[$logical]['name'] ?? '', $empty ? null : $value, $origin, $status, $note);
        }

        if ($errors !== []) {
            // A ordem das chaves é a ordem de prioridade: nome, série, tipo, campos, status, SO.
            return ['rows' => $rows, 'payload' => null, 'error' => reset($errors)];
        }

        return [
            'rows'    => $rows,
            'payload' => ['name' => $name, 'asset_type_id' => $assetTypeId, 'asset_tag' => $serial, 'description' => $description, 'type_fields' => $typeFields],
            'error'   => null,
        ];
    }

    private static function cpuSpeed(int $mhz, string $unit): int|float
    {
        return $unit === Settings::CPU_GHZ ? round($mhz / 1000, 2) : $mhz;
    }

    /** 16.0 -> "16"; 15.6 -> "15.6" */
    private static function trimDecimal(float $number): string
    {
        return rtrim(rtrim(number_format($number, 1, '.', ''), '0'), '.');
    }
}
