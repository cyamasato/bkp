<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Regra do "Usado por": o `user_id` só é enviado quando muda, para não poluir
 * o histórico de atribuição do asset no Freshservice.
 */
final class UserIdRule
{
    /**
     * @param ?int $resolved  usuário resolvido agora no Freshservice (null = computador sem usuário)
     * @param ?int $lastSent  último `user_id` enviado para este asset (null = nenhum ou vazio)
     * @param bool $firstSync true quando o asset acabou de ser criado ou vinculado
     */
    public static function mustSend(?int $resolved, ?int $lastSent, bool $firstSync): bool
    {
        if ($firstSync) {
            // Num asset novo, não há o que limpar: só envia se houver usuário.
            return $resolved !== null;
        }

        return $resolved !== $lastSent;
    }
}
