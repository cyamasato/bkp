<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Tudo da configuração que influencia o payload: de-paras e opções de mapeamento.
 * Objeto simples, para o PayloadBuilder não depender do banco.
 */
final readonly class Settings
{
    public const CPU_MHZ = 'mhz';
    public const CPU_GHZ = 'ghz';

    /** Chave usada no de-para de status para computadores sem status no GLPI. */
    public const NO_STATE = 0;

    /**
     * @param array<int, array{asset_type_id: int, product_id: int}> $types  ComputerType => tipo de ativo e produto
     * @param array<int, string>                                    $states State do GLPI => estado do asset
     * @param array<string, array{alias: string, commercial: string}> $models modelo do GLPI => apelido e nome comercial
     * @param array<string, string>                                 $os     SO do GLPI => opção da lista do Freshservice
     * @param array<int, array<string, array{name: string, choices: ?list<string>}>> $fields
     *        tipo de ativo => campo lógico (Field::*) => nome real e, se for lista fechada, as opções
     * @param int $revision contador que muda quando a configuração muda; entra no hash
     * @param ?array{asset_type_id: int, product_id: int} $defaultType tipo e produto usados quando o
     *        tipo do computador não tem de-para ou o de-para não existe no Freshservice (D-43)
     * @param array<string, string> $userDomains domínio do nome alternativo (maiúsculas) => domínio de e-mail (D-45)
     */
    public function __construct(
        public array $types,
        public array $states,
        public array $models,
        public array $os,
        public array $fields,
        public string $descriptionTemplate,
        public bool $roundDisk,
        public string $cpuUnit,
        public int $revision,
        public ?array $defaultType = null,
        public array $userDomains = [],
    ) {}

    /**
     * Cópia com o de-para de um tipo de computador trocado (o original não muda).
     *
     * @param array{asset_type_id: int, product_id: int} $type
     */
    public function withType(int $computerTypeId, array $type): self
    {
        $values = get_object_vars($this);
        $values['types'][$computerTypeId] = $type;

        return new self(...$values);
    }
}
