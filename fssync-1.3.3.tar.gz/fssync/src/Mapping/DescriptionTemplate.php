<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Template configurável da descrição do asset, com variáveis entre chaves.
 */
final class DescriptionTemplate
{
    /** Variáveis aceitas; a tela de configuração lista estas. */
    public const VARIABLES = [
        'nome', 'serial', 'fabricante', 'modelo', 'modelo_comercial', 'cpu', 'memoria', 'disco', 'so',
    ];

    /**
     * Variáveis sem valor somem, e os espaços que sobram são unidos. Uma variável
     * desconhecida fica como está, para o erro de digitação aparecer na descrição.
     *
     * @param array<string, string|int|float|null> $values
     */
    public static function render(string $template, array $values): string
    {
        $text = preg_replace_callback(
            '/\{([a-z_]+)\}/',
            static function (array $match) use ($values): string {
                if (!in_array($match[1], self::VARIABLES, true)) {
                    return $match[0];
                }

                return (string) ($values[$match[1]] ?? '');
            },
            $template
        );

        return trim(preg_replace('/\s+/', ' ', $text));
    }
}
