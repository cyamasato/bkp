<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Estado de um computador do GLPI já lido do banco, pronto para o mapeamento.
 * Montado pelo SnapshotLoader (computador real) ou por um formulário (computador fictício).
 */
final readonly class ComputerSnapshot
{
    /**
     * @param string    $os      nome do sistema operacional, com a edição quando houver
     * @param int       $userId  usuário do GLPI (0 = sem usuário)
     * @param string    $contact "Nome alternativo do usuário", como `login@DOMINIO` (D-45)
     * @param list<int> $diskMbs capacidade de cada disco físico, em MB
     * @param int       $cpuMhz  frequência do processador mais rápido
     * @param int       $cpuCores soma dos núcleos de todos os processadores
     */
    public function __construct(
        public int $id,
        public string $name,
        public string $serial,
        public int $entityId,
        public bool $isDeleted,
        public int $typeId,
        public int $stateId,
        public string $manufacturer,
        public string $model,
        public string $os,
        public int $userId,
        public int $memoryMb,
        public array $diskMbs,
        public string $cpuName,
        public int $cpuMhz,
        public int $cpuCores,
        public string $contact = '',
    ) {}
}
