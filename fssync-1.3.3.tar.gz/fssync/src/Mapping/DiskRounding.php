<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Converte a capacidade dos discos físicos (MB, como o inventário informa) em GB.
 */
final class DiskRounding
{
    /** Capacidades de prateleira, em GB. */
    public const COMMERCIAL_SIZES = [128, 256, 512, 1024, 2048];

    /** Folga para um disco que reporta um pouco acima do nominal. */
    private const TOLERANCE = 1.02;

    /**
     * Soma dos discos em GB. Com $commercial, cada disco é arredondado antes de
     * somar: um SSD de 256 GB e um HD de 1 TB dão 1280, não 2048.
     *
     * @param list<int> $diskMbs
     */
    public static function totalGb(array $diskMbs, bool $commercial): int
    {
        if (!$commercial) {
            return (int) round(array_sum($diskMbs) / 1024);
        }

        return array_sum(array_map(self::commercialGb(...), $diskMbs));
    }

    /**
     * Um disco "de 512 GB" aparece no inventário com cerca de 477 GB: sobe para
     * a menor capacidade comercial que o comporta. Acima da maior, só arredonda.
     */
    public static function commercialGb(int $mb): int
    {
        $gb = $mb / 1024;
        if ($gb <= 0) {
            return 0;
        }
        foreach (self::COMMERCIAL_SIZES as $size) {
            if ($gb <= $size * self::TOLERANCE) {
                return $size;
            }
        }

        return (int) round($gb);
    }
}
