<?php

namespace GlpiPlugin\Fssync\Mapping;

use GlpiPlugin\Fssync\BlockedException;

/**
 * O computador não pode ser convertido em asset com a configuração atual.
 */
final class MappingException extends BlockedException {}
