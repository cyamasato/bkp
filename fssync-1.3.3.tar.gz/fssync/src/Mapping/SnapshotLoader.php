<?php

namespace GlpiPlugin\Fssync\Mapping;

use DBmysql;

/**
 * Lê o estado atual de um computador no banco do GLPI.
 */
final class SnapshotLoader
{
    /**
     * @return ?ComputerSnapshot null quando o computador não existe mais (foi purgado) ou é um modelo
     */
    public static function load(int $computerId): ?ComputerSnapshot
    {
        /** @var DBmysql $DB */
        global $DB;

        $computer = $DB->request([
            'SELECT'    => [
                'c.id', 'c.name', 'c.serial', 'c.entities_id', 'c.is_deleted', 'c.computertypes_id', 'c.states_id', 'c.users_id', 'c.contact',
                'manufacturer.name AS manufacturer',
                'model.name AS model',
            ],
            'FROM'      => 'glpi_computers AS c',
            'LEFT JOIN' => [
                'glpi_manufacturers AS manufacturer' => ['ON' => ['manufacturer' => 'id', 'c' => 'manufacturers_id']],
                'glpi_computermodels AS model'       => ['ON' => ['model' => 'id', 'c' => 'computermodels_id']],
            ],
            'WHERE'     => ['c.id' => $computerId, 'c.is_template' => 0],
        ])->current();
        if (!$computer) {
            return null;
        }

        $components = ['itemtype' => 'Computer', 'items_id' => $computerId, 'is_deleted' => 0];

        $memoryMb = 0;
        foreach ($DB->request(['SELECT' => 'size', 'FROM' => 'glpi_items_devicememories', 'WHERE' => $components]) as $memory) {
            $memoryMb += (int) $memory['size'];
        }

        // Discos físicos (Item_DeviceHardDrive). Partições e volumes (Item_Disk) não entram.
        $diskMbs = [];
        $disks   = $DB->request([
            'SELECT'    => ['item.capacity', 'device.capacity_default'],
            'FROM'      => 'glpi_items_deviceharddrives AS item',
            'LEFT JOIN' => ['glpi_deviceharddrives AS device' => ['ON' => ['device' => 'id', 'item' => 'deviceharddrives_id']]],
            'WHERE'     => ['item.itemtype' => 'Computer', 'item.items_id' => $computerId, 'item.is_deleted' => 0],
            'ORDER'     => 'item.id',
        ]);
        foreach ($disks as $disk) {
            $capacity = (int) $disk['capacity'] ?: (int) $disk['capacity_default'];
            if ($capacity > 0) {
                $diskMbs[] = $capacity;
            }
        }

        $cpuName = '';
        $cpuMhz  = 0;
        $cores   = 0;
        $cpus    = $DB->request([
            'SELECT'    => ['item.frequency', 'item.nbcores', 'device.designation', 'device.frequency_default', 'device.nbcores_default'],
            'FROM'      => 'glpi_items_deviceprocessors AS item',
            'LEFT JOIN' => ['glpi_deviceprocessors AS device' => ['ON' => ['device' => 'id', 'item' => 'deviceprocessors_id']]],
            'WHERE'     => ['item.itemtype' => 'Computer', 'item.items_id' => $computerId, 'item.is_deleted' => 0],
            'ORDER'     => 'item.id',
        ]);
        foreach ($cpus as $cpu) {
            $cpuName = $cpuName === '' ? (string) $cpu['designation'] : $cpuName;
            $cpuMhz  = max($cpuMhz, (int) $cpu['frequency'] ?: (int) $cpu['frequency_default']);
            $cores  += (int) $cpu['nbcores'] ?: (int) $cpu['nbcores_default'];
        }

        return new ComputerSnapshot(
            id: (int) $computer['id'],
            name: (string) $computer['name'],
            serial: (string) $computer['serial'],
            entityId: (int) $computer['entities_id'],
            isDeleted: (bool) $computer['is_deleted'],
            typeId: (int) $computer['computertypes_id'],
            stateId: (int) $computer['states_id'],
            manufacturer: (string) $computer['manufacturer'],
            model: (string) $computer['model'],
            os: self::operatingSystem($computerId),
            userId: (int) $computer['users_id'],
            memoryMb: $memoryMb,
            diskMbs: $diskMbs,
            cpuName: $cpuName,
            cpuMhz: $cpuMhz,
            cpuCores: $cores,
            contact: (string) $computer['contact'],
        );
    }

    /** Nome do sistema operacional, seguido da edição quando ela existe. */
    private static function operatingSystem(int $computerId): string
    {
        /** @var DBmysql $DB */
        global $DB;

        $row = $DB->request([
            'SELECT'    => ['os.name AS name', 'edition.name AS edition'],
            'FROM'      => 'glpi_items_operatingsystems AS item',
            'LEFT JOIN' => [
                'glpi_operatingsystems AS os'             => ['ON' => ['os' => 'id', 'item' => 'operatingsystems_id']],
                'glpi_operatingsystemeditions AS edition' => ['ON' => ['edition' => 'id', 'item' => 'operatingsystemeditions_id']],
            ],
            'WHERE'     => ['item.itemtype' => 'Computer', 'item.items_id' => $computerId, 'item.is_deleted' => 0],
            'ORDER'     => 'item.id',
            'LIMIT'     => 1,
        ])->current();

        return $row ? trim(($row['name'] ?? '') . ' ' . ($row['edition'] ?? '')) : '';
    }
}
