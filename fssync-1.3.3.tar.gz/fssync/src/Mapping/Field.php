<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Campos lógicos que o plugin envia em `type_fields`. O nome real de cada um
 * no Freshservice é descoberto pela API e guardado no de-para de campos.
 */
final class Field
{
    public const PRODUCT      = 'product';
    public const STATE        = 'state';
    public const SERIAL       = 'serial';
    public const MANUFACTURER = 'manufacturer';
    public const MODEL        = 'model';
    public const OS           = 'os';
    public const MEMORY       = 'memory';
    public const DISK         = 'disk';
    public const CPU_SPEED    = 'cpu_speed';
    public const CPU_CORES    = 'cpu_cores';

    /** Sem estes o Freshservice recusa o asset ou a deduplicação não funciona. */
    public const REQUIRED = [self::PRODUCT, self::STATE, self::SERIAL];

    /**
     * Nome-base usual de cada campo no Freshservice (sem o sufixo _<id do tipo>).
     * Serve só como sugestão ao montar o de-para; o que vale é o de-para salvo.
     */
    public const USUAL_BASE_NAMES = [
        self::PRODUCT      => 'product',
        self::STATE        => 'asset_state',
        self::SERIAL       => 'serial_number',
        self::MANUFACTURER => 'fabricante',
        self::MODEL        => 'modelo',
        self::OS           => 'os',
        self::MEMORY       => 'memory',
        self::DISK         => 'disk_space',
        self::CPU_SPEED    => 'cpu_speed',
        self::CPU_CORES    => 'cpu_core_count',
    ];
}
