<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Impressão digital do payload, para não reenviar o que já está no Freshservice.
 */
final class PayloadHasher
{
    /**
     * O hash cobre o payload sem `user_id` (que tem regra própria de envio) e a
     * revisão da configuração: mudar um de-para invalida os hashes antigos.
     *
     * @param array<string, mixed> $payload
     */
    public static function hash(array $payload, int $configRevision): string
    {
        unset($payload['user_id']);
        self::sortRecursively($payload);

        return hash('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . '|' . $configRevision);
    }

    /**
     * @param array<string, mixed> $data
     */
    private static function sortRecursively(array &$data): void
    {
        ksort($data);
        foreach ($data as &$value) {
            if (is_array($value)) {
                self::sortRecursively($value);
            }
        }
    }
}
