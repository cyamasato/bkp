<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Computador fictício da página de teste: converte o formulário em um
 * ComputerSnapshot, para passar pelo mesmo mapeamento de um computador real.
 */
final class SnapshotForm
{
    /**
     * O computador de referência do projeto. `type_id` e `user_id` dependem do
     * GLPI em uso e são preenchidos pela tela.
     *
     * @return array<string, string|int>
     */
    public static function defaults(): array
    {
        return [
            'name'         => 'TCN-GUJ-LT26025',
            'serial'       => 'PE0GBDH0',
            'type_id'      => 0,
            'state_id'     => 0,
            'manufacturer' => 'Lenovo',
            'model'        => 'E14 G7',
            'os'           => 'Microsoft Windows 11 Pro',
            'user_id'      => 0,
            'contact'      => '',
            'memory_gb'    => '16',
            'disks_gb'     => '512',
            'cpu_name'     => 'AMD Ryzen 7 250',
            'cpu_mhz'      => 3000,
            'cpu_cores'    => 4,
        ];
    }

    /**
     * @param array<string, mixed> $input campos do formulário; o que faltar vem de defaults()
     */
    public static function toSnapshot(array $input): ComputerSnapshot
    {
        $input += self::defaults();

        $diskMbs = [];
        foreach (preg_split('/[\s,;+]+/', (string) $input['disks_gb'], -1, PREG_SPLIT_NO_EMPTY) as $gb) {
            $mb = (int) round(self::number($gb) * 1024);
            if ($mb > 0) {
                $diskMbs[] = $mb;
            }
        }

        return new ComputerSnapshot(
            id: 0,
            name: trim((string) $input['name']),
            serial: trim((string) $input['serial']),
            entityId: 0,
            isDeleted: false,
            typeId: (int) $input['type_id'],
            stateId: (int) $input['state_id'],
            manufacturer: trim((string) $input['manufacturer']),
            model: trim((string) $input['model']),
            os: trim((string) $input['os']),
            userId: (int) $input['user_id'],
            memoryMb: (int) round(self::number($input['memory_gb']) * 1024),
            diskMbs: $diskMbs,
            cpuName: trim((string) $input['cpu_name']),
            cpuMhz: max(0, (int) $input['cpu_mhz']),
            cpuCores: max(0, (int) $input['cpu_cores']),
            contact: trim((string) $input['contact']),
        );
    }

    /** Aceita vírgula ou ponto como separador decimal. */
    private static function number(mixed $value): float
    {
        return max(0.0, (float) str_replace(',', '.', trim((string) $value)));
    }
}
