<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Compara o corpo que seria enviado com o asset que já existe no Freshservice.
 */
final class AssetDiff
{
    /**
     * Só entram os campos que o corpo traz: o que o plugin não envia não muda.
     *
     * @param array<string, mixed> $body  corpo a enviar (name, description, user_id, type_fields...)
     * @param array<string, mixed> $asset asset atual, com `type_fields`
     *
     * @return list<array{field: string, current: mixed, new: mixed, changed: bool}>
     */
    public static function compare(array $body, array $asset): array
    {
        $rows = [];
        foreach ($body as $field => $new) {
            if ($field === 'type_fields') {
                foreach ($new as $name => $value) {
                    $rows[] = self::row($name, $asset['type_fields'][$name] ?? null, $value);
                }
            } else {
                $rows[] = self::row($field, $asset[$field] ?? null, $new);
            }
        }

        return $rows;
    }

    /**
     * @return array{field: string, current: mixed, new: mixed, changed: bool}
     */
    private static function row(string $field, mixed $current, mixed $new): array
    {
        return ['field' => $field, 'current' => $current, 'new' => $new, 'changed' => !self::same($current, $new)];
    }

    /** 16 e 16.0 são o mesmo valor; "512" e 512 também. Texto é comparado sem espaços nas pontas. */
    private static function same(mixed $a, mixed $b): bool
    {
        if (is_numeric($a) && is_numeric($b)) {
            return abs((float) $a - (float) $b) < 0.0001;
        }
        if (is_string($a) && is_string($b)) {
            return trim($a) === trim($b);
        }

        return $a === $b;
    }
}
