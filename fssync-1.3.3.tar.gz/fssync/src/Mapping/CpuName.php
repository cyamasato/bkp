<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Reduz o nome do processador informado pelo inventário ao que se usa numa descrição.
 */
final class CpuName
{
    /**
     * "AMD Ryzen 7 250 w/ Radeon 780M Graphics"   -> "Ryzen 7 250"
     * "Intel(R) Core(TM) i7-10700T CPU @ 2.00GHz" -> "Core i7-10700T"
     * "13th Gen Intel(R) Core(TM) i5-13500"       -> "Core i5-13500"
     */
    public static function short(string $name): string
    {
        $name = preg_replace('/\((R|TM|C)\)/i', ' ', $name);
        $name = preg_replace('/\s+(w\/|with)\s.*$/i', '', $name);
        $name = preg_replace('/\s*@.*$/', '', $name);
        $name = preg_replace('/\b\d+(st|nd|rd|th) Gen\b/i', ' ', $name);
        $name = preg_replace('/\b(Intel|AMD|CPU|Processor)\b/i', ' ', $name);
        $name = preg_replace('/\b\d+-Core\b/i', ' ', $name);

        return trim(preg_replace('/\s+/', ' ', $name));
    }
}
