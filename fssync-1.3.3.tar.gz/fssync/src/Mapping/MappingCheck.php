<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Confere se o tipo de ativo e o produto do de-para existem no Freshservice
 * ativo. Um ID salvo com outro perfil (o mock, por exemplo) continua no
 * de-para depois da troca de perfil, e o Freshservice só responderia com um
 * erro genérico. Também decide quando usar o tipo e produto padrão (D-43).
 *
 * Não acessa banco nem API: recebe as listas do catálogo já carregadas.
 */
final class MappingCheck
{
    public const ASSET_TYPE = 'asset_type';
    public const PRODUCT    = 'product';

    /**
     * IDs do de-para de um tipo de computador que não existem no Freshservice.
     * Um tipo sem de-para, ou sem produto, fica de fora: o PayloadBuilder já aponta.
     *
     * @param array<int, mixed> $assetTypes tipos de ativo existentes, por ID
     * @param array<int, mixed> $products   produtos existentes, por ID
     *
     * @return array<string, int> ASSET_TYPE e/ou PRODUCT => ID que não existe
     */
    public static function missing(Settings $settings, int $computerTypeId, array $assetTypes, array $products): array
    {
        $type = $settings->types[$computerTypeId] ?? null;
        if ($type === null) {
            return [];
        }

        $missing = [];
        if (!isset($assetTypes[$type['asset_type_id']])) {
            $missing[self::ASSET_TYPE] = $type['asset_type_id'];
        }
        if ($type['product_id'] > 0 && !isset($products[$type['product_id']])) {
            $missing[self::PRODUCT] = $type['product_id'];
        }

        return $missing;
    }

    /**
     * O de-para efetivo de um computador (D-43): o do tipo dele ou, se o tipo não
     * tiver de-para ou o de-para apontar para tipo ou produto que não existe no
     * Freshservice, o tipo e produto padrão. Sem padrão configurado, nada muda e
     * quem chama bloqueia como antes.
     *
     * @param ?array<int, mixed> $assetTypes tipos de ativo existentes, por ID; null quando o catálogo não foi consultado
     * @param ?array<int, mixed> $products   produtos existentes, por ID; null quando o catálogo não foi consultado
     *
     * @return array{settings: Settings, defaulted: ?string} defaulted: por que o padrão foi usado (aviso para o log)
     *
     * @throws MappingException quando o próprio padrão não existe no Freshservice
     */
    public static function resolve(Settings $settings, int $computerTypeId, ?array $assetTypes, ?array $products): array
    {
        $mapped = isset($settings->types[$computerTypeId]);
        if ($mapped && ($assetTypes === null || $products === null || self::missing($settings, $computerTypeId, $assetTypes, $products) === [])) {
            return ['settings' => $settings, 'defaulted' => null];
        }

        $default = $settings->defaultType;
        if ($default === null) {
            return ['settings' => $settings, 'defaulted' => null];
        }
        if ($assetTypes !== null && $products !== null && (!isset($assetTypes[$default['asset_type_id']]) || !isset($products[$default['product_id']]))) {
            throw new MappingException(sprintf(
                __('The default asset type #%1$d or product #%2$d does not exist in the active Freshservice. Review it in Configuration > Types and fields.', 'fssync'),
                $default['asset_type_id'],
                $default['product_id']
            ));
        }

        return [
            'settings'  => $settings->withType($computerTypeId, $default),
            'defaulted' => $mapped
                ? sprintf(__('The mapping of computer type #%d points to an ID that does not exist in the active Freshservice; the default asset type and product were used.', 'fssync'), $computerTypeId)
                : sprintf(__('Computer type #%d has no Freshservice mapping; the default asset type and product were used.', 'fssync'), $computerTypeId),
        ];
    }

    /**
     * O que não existe e onde corrigir, para a fila, o log e a página de teste.
     *
     * @param array<string, int> $missing resultado de missing(), não vazio
     */
    public static function message(int $computerTypeId, array $missing): string
    {
        $parts = [];
        if (isset($missing[self::ASSET_TYPE])) {
            $parts[] = sprintf(
                __('Computer type #%1$d is mapped to Freshservice asset type #%2$d, which does not exist in the active Freshservice.', 'fssync'),
                $computerTypeId,
                $missing[self::ASSET_TYPE]
            );
        }
        if (isset($missing[self::PRODUCT])) {
            $parts[] = sprintf(
                __('Computer type #%1$d is mapped to Freshservice product #%2$d, which does not exist in the active Freshservice.', 'fssync'),
                $computerTypeId,
                $missing[self::PRODUCT]
            );
        }
        $parts[] = __('Review the mapping in Configuration > Types and fields, or refresh the Freshservice lists if it was just created.', 'fssync');

        return implode(' ', $parts);
    }
}
