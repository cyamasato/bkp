<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Quem usa o computador e com que e-mail ele é procurado no Freshservice (D-45).
 *
 * A origem principal é o "Nome alternativo do usuário" (`contact`), que o
 * inventário preenche como `login@DOMINIO` ou `DOMINIO\login`; o domínio do
 * AD vira domínio de e-mail pelo de-para. Sem ele, vale o e-mail padrão do
 * Usuário do GLPI (`users_id`).
 *
 * Não acessa banco nem API: quem chama passa o de-para e a busca do e-mail.
 */
final readonly class ComputerUser
{
    public const SOURCE_CONTACT = 'contact';
    public const SOURCE_USER    = 'user';
    public const SOURCE_NONE    = 'none';

    /**
     * @param string $source  SOURCE_*
     * @param string $label   o texto de onde o e-mail saiu: o nome alternativo, ou "#id" do usuário do GLPI
     * @param string $email   e-mail em minúsculas; vazio quando não foi possível montá-lo
     * @param string $problem por que o e-mail não foi montado (vazio quando foi)
     */
    private function __construct(
        public string $source,
        public string $label,
        public string $email,
        public string $problem,
    ) {}

    /**
     * @param array<string, string>  $domains domínio no GLPI (maiúsculas) => domínio de e-mail
     * @param callable(int): string  $emailOf e-mail padrão de um usuário do GLPI ('' se não tiver)
     */
    public static function of(ComputerSnapshot $computer, array $domains, callable $emailOf): self
    {
        $contact = trim($computer->contact);
        if ($contact !== '') {
            return self::fromContact($contact, $domains);
        }
        if ($computer->userId > 0) {
            $email = strtolower(trim($emailOf($computer->userId)));

            return new self(
                self::SOURCE_USER,
                '#' . $computer->userId,
                $email,
                $email === '' ? sprintf(__('GLPI user #%d has no e-mail address', 'fssync'), $computer->userId) : ''
            );
        }

        return new self(self::SOURCE_NONE, '', '', '');
    }

    /**
     * @param array<string, string> $domains
     */
    private static function fromContact(string $contact, array $domains): self
    {
        [$login, $domain] = self::split($contact);
        if ($login === '' || $domain === '') {
            return new self(self::SOURCE_CONTACT, $contact, '', sprintf(__('alternate username "%s" has no login or no domain', 'fssync'), $contact));
        }

        // O de-para vence; sem ele, um domínio com ponto já é um domínio de e-mail.
        $mailDomain = $domains[strtoupper($domain)] ?? (str_contains($domain, '.') ? $domain : '');
        if ($mailDomain === '') {
            return new self(
                self::SOURCE_CONTACT,
                $contact,
                '',
                sprintf(__('domain "%1$s" of alternate username "%2$s" has no e-mail domain mapping', 'fssync'), $domain, $contact)
            );
        }

        return new self(self::SOURCE_CONTACT, $contact, strtolower($login . '@' . $mailDomain), '');
    }

    /**
     * Separa `login@DOMINIO` ou `DOMINIO\login`.
     *
     * @return array{string, string} login e domínio; vazios quando faltam
     */
    public static function split(string $contact): array
    {
        $contact = trim($contact);
        if (str_contains($contact, '\\')) {
            [$domain, $login] = explode('\\', $contact, 2);
        } elseif (str_contains($contact, '@')) {
            $at     = (int) strrpos($contact, '@');
            $login  = substr($contact, 0, $at);
            $domain = substr($contact, $at + 1);
        } else {
            $login  = $contact;
            $domain = '';
        }

        return [trim($login), trim($domain)];
    }

    /** O computador não tem nome alternativo nem usuário. */
    public function isNone(): bool
    {
        return $this->source === self::SOURCE_NONE;
    }

    /**
     * Identifica o usuário no hash do modo "só atualizar": muda quando muda o
     * nome alternativo, o usuário ou o de-para de domínio.
     */
    public function key(): string
    {
        return $this->email !== '' ? $this->email : $this->source . ':' . $this->label;
    }

    /** Campo do GLPI de onde o usuário veio, para as telas. */
    public function origin(): string
    {
        return match ($this->source) {
            self::SOURCE_CONTACT => 'Computer.contact',
            self::SOURCE_USER    => 'Computer.users_id',
            default              => '',
        };
    }
}
