<?php

namespace GlpiPlugin\Fssync\Mapping;

/**
 * Modo "só atualizar" (D-36): o que muda num asset que já existe no
 * Freshservice. Só entram os campos escolhidos, e só quando diferem do valor
 * atual do asset.
 *
 * Não acessa banco nem API: quem chama passa o asset atual, o campo de estado
 * descoberto para o tipo dele e o usuário já resolvido.
 */
final class UpdatePlan
{
    public const USER  = 'user';
    public const STATE = 'state';

    /** Campos que este modo pode atualizar, na ordem em que aparecem nas telas. */
    public const FIELDS = [self::USER, self::STATE];

    /** Campos do corpo que ficam na raiz do asset; os demais vão em `type_fields`. */
    private const ROOT_FIELDS = ['user_id', 'department_id'];

    /** Estado pelo de-para de status; null quando o status do GLPI não tem de-para. */
    public static function stateValue(ComputerSnapshot $computer, Settings $settings): ?string
    {
        return $settings->states[$computer->stateId] ?? null;
    }

    /**
     * Identifica o que seria enviado: muda quando muda o valor de um campo
     * escolhido ou a própria escolha de campos. O usuário entra pelo e-mail
     * montado no GLPI (ComputerUser::key()), para a comparação não depender de
     * consultar o Freshservice.
     *
     * @param list<string> $fields
     */
    public static function hash(array $fields, ?string $state, string $userKey, int $configRevision): string
    {
        return PayloadHasher::hash([
            'fields' => $fields,
            'state'  => in_array(self::STATE, $fields, true) ? $state : null,
            'user'   => in_array(self::USER, $fields, true) ? $userKey : null,
        ], $configRevision);
    }

    /**
     * O "Usado por" vai mudar num asset que tem departamento: quem chama precisa
     * buscar os departamentos do usuário novo (D-41). Vale nos dois modos.
     *
     * @param array<string, mixed> $asset
     */
    public static function needsDepartments(array $asset, ?int $user): bool
    {
        return $user !== null
            && $user !== (isset($asset['user_id']) ? (int) $asset['user_id'] : null)
            && ($asset['department_id'] ?? null) !== null;
    }

    /**
     * O Freshservice recusa um "Usado por" fora do departamento do asset: o
     * departamento acompanha a troca, o primeiro do usuário ou vazio (D-41).
     *
     * @param array<string, mixed> $asset
     * @param ?list<int>           $userDepartments departamentos do usuário novo, quando needsDepartments()
     *
     * @return array{department_id?: ?int} o que acrescentar ao corpo
     */
    public static function departmentFor(array $asset, ?int $user, ?array $userDepartments): array
    {
        if ($userDepartments === null || !self::needsDepartments($asset, $user) || in_array((int) $asset['department_id'], $userDepartments, true)) {
            return [];
        }

        return ['department_id' => $userDepartments[0] ?? null];
    }

    /**
     * @param list<string>                                  $fields          campos escolhidos
     * @param array<string, mixed>                          $asset           asset atual, com `type_fields`, `user_id` e `department_id`
     * @param ?array{name: string, choices: ?list<string>}  $stateField      campo de estado do tipo do asset; null se o tipo não tiver
     * @param ?int                                          $user            usuário resolvido no Freshservice (null = computador sem usuário)
     * @param ?int                                          $lastSentUser    último `user_id` que o plugin enviou a este asset
     * @param ?list<int>                                    $userDepartments departamentos do usuário novo, quando needsDepartments()
     *
     * @return array{
     *     body: array<string, mixed>,
     *     diff: list<array{field: string, current: mixed, new: mixed, changed: bool}>,
     *     warnings: list<string>
     * }
     */
    public static function build(
        ComputerSnapshot $computer,
        Settings $settings,
        array $fields,
        array $asset,
        ?array $stateField,
        ?int $user,
        ?int $lastSentUser,
        ?array $userDepartments = null,
    ): array {
        $candidate = [];
        $warnings  = [];

        if (in_array(self::USER, $fields, true)) {
            $current = isset($asset['user_id']) ? (int) $asset['user_id'] : null;
            if ($user !== null) {
                $candidate = ['user_id' => $user] + self::departmentFor($asset, $user, $userDepartments);
            } elseif ($lastSentUser !== null && $current === $lastSentUser) {
                // O computador perdeu o usuário que o plugin tinha atribuído: limpa.
                // Um "Usado por" preenchido à mão no Freshservice não é apagado.
                $candidate['user_id'] = null;
            }
        }

        if (in_array(self::STATE, $fields, true)) {
            $state = self::stateValue($computer, $settings);
            if ($state === null) {
                $warnings[] = sprintf(__('GLPI status #%d has no Freshservice asset state mapping, so the state was not updated.', 'fssync'), $computer->stateId);
            } elseif ($stateField === null) {
                $warnings[] = sprintf(__('Freshservice asset type #%d has no asset state field, so the state was not updated.', 'fssync'), (int) ($asset['asset_type_id'] ?? 0));
            } elseif ($stateField['choices'] !== null && !in_array($state, $stateField['choices'], true)) {
                $warnings[] = sprintf(__('State "%s" is not in the Freshservice list, so the state was not updated.', 'fssync'), $state);
            } else {
                $candidate['type_fields'] = [$stateField['name'] => $state];
            }
        }

        $diff = AssetDiff::compare($candidate, $asset);
        $body = [];
        foreach ($diff as $row) {
            if (!$row['changed']) {
                continue;
            }
            if (in_array($row['field'], self::ROOT_FIELDS, true)) {
                $body[$row['field']] = $row['new'];
            } else {
                $body['type_fields'][$row['field']] = $row['new'];
            }
        }

        return ['body' => $body, 'diff' => $diff, 'warnings' => $warnings];
    }

    /**
     * Linhas da pré-visualização, sem consultar o Freshservice: o nome do campo
     * de estado e o ID do usuário só são conhecidos na validação.
     *
     * @param list<string> $fields
     * @param string       $userOrigin campo do GLPI de onde o usuário veio (ComputerUser::origin())
     *
     * @return list<array{field: string, fs_name: string, value: mixed, origin: string, status: string, note: string}>
     */
    public static function preview(ComputerSnapshot $computer, Settings $settings, array $fields, string $userLabel, string $userOrigin = 'Computer.contact'): array
    {
        $rows = [];
        if (in_array(self::USER, $fields, true)) {
            $rows[] = [
                'field'   => self::USER,
                'fs_name' => 'user_id',
                'value'   => $userLabel,
                'origin'  => $userOrigin,
                'status'  => PayloadBuilder::STATUS_OK,
                'note'    => __('The Freshservice user is looked up by e-mail when validating.', 'fssync'),
            ];
        }
        if (in_array(self::STATE, $fields, true)) {
            $state  = self::stateValue($computer, $settings);
            $rows[] = [
                'field'   => self::STATE,
                'fs_name' => '',
                'value'   => $state,
                'origin'  => sprintf('State #%d', $computer->stateId),
                'status'  => $state === null ? PayloadBuilder::STATUS_ERROR : PayloadBuilder::STATUS_OK,
                'note'    => $state === null
                    ? sprintf(__('GLPI status #%d has no Freshservice asset state mapping; the state will not be updated.', 'fssync'), $computer->stateId)
                    : __('The state field of the asset type is found when validating.', 'fssync'),
            ];
        }

        return $rows;
    }
}
