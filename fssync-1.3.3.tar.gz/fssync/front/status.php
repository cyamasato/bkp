<?php

use GlpiPlugin\Fssync\Rights;
use GlpiPlugin\Fssync\Status;
use GlpiPlugin\Fssync\Ui\Page;

Rights::checkView();

Page::render(Page::STATUS, 'status.html.twig', ['status' => Status::summary()]);
