<?php

use GlpiPlugin\Fssync\ComputerTab;
use GlpiPlugin\Fssync\Rights;

Rights::checkTest();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (int) ($_POST['computers_id'] ?? 0) > 0) {
    ComputerTab::syncNow((int) $_POST['computers_id']);
}

Html::back();
