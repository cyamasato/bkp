<?php

use GlpiPlugin\Fssync\Rights;
use GlpiPlugin\Fssync\Ui\ConfigPage;
use GlpiPlugin\Fssync\Ui\Page;

Rights::checkConfigure();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ConfigPage::handle($_POST);
}

Page::render(Page::CONFIG, 'config.html.twig', ConfigPage::view((string) ($_GET['tab'] ?? '')));
