<?php

use GlpiPlugin\Fssync\Rights;
use GlpiPlugin\Fssync\Ui\Page;
use GlpiPlugin\Fssync\Ui\TestPage;

Rights::checkTest();

// Um GET só pré-seleciona o computador (link vindo da aba dele); as ações chegam por POST.
Page::render(Page::TEST, 'test.html.twig', TestPage::view($_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : array_diff_key($_GET, ['step' => 1])));
