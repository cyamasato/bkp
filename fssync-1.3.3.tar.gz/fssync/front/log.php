<?php

use GlpiPlugin\Fssync\Rights;
use GlpiPlugin\Fssync\Ui\LogPage;
use GlpiPlugin\Fssync\Ui\Page;

Rights::checkView();

Page::render(Page::LOGS, 'logs.html.twig', LogPage::view($_GET));
