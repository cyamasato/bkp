<?php

use GlpiPlugin\Fssync\Rights;
use GlpiPlugin\Fssync\Ui\Page;
use GlpiPlugin\Fssync\Ui\QueuePage;

Rights::checkView();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Limpar descarta trabalho pendente: exige Configurar. Reprocessar exige Testar.
    if (($_POST['action'] ?? '') === 'clear') {
        Rights::checkConfigure();
    } else {
        Rights::checkTest();
    }
    QueuePage::handle($_POST);
}

Page::render(Page::QUEUE, 'queue.html.twig', QueuePage::view($_GET));
